import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";
import { ActivityIndicator, View } from "react-native";

import Stacknavigator from "./src/navigation/Stacknavigator";
import { persistor, store } from "./src/redux/store";
import LandingNavigation from "./src/navigation/LandingNavigation";
import { NavigationScreen } from "./src/navigation/NavigationScreen";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import Toast from "react-native-toast-message";

// ⭐⭐⭐ IMPORT THE INTERCEPTOR - This sets it up globally ⭐⭐⭐
// import "./hooks/axiosInterceptor"; //"./config/axiosInterceptor";
const queryClient = new QueryClient();

const LoadingScreen = () => (
  <View
    style={{
      flex: 1,
      justifyContent: "center",
      alignItems: "center",
      backgroundColor: "#fff",
    }}
  >
    <ActivityIndicator size="large" color="#1a1a2e" />
  </View>
);

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Provider store={store}>
        <PersistGate loading={<LoadingScreen />} persistor={persistor}>
          <SafeAreaProvider>
            <NavigationScreen />
          </SafeAreaProvider>
        </PersistGate>
      </Provider>
      <Toast />
    </QueryClientProvider>
  );
}
