import React, { useState, useCallback, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
  TextInput,
  FlatList,
  Keyboard,
  TouchableWithoutFeedback,
  Animated,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useFetchData_v2, useMutateData_v2 } from "../../hooks/Requestv2";
import { useNavigation } from "@react-navigation/native";

interface BankAccountsScreenProps {
  onBack: () => void;
}

interface BankRecord {
  _id: string;
  accountName: string;
  accountNumber: string;
  bankCode: string;
}

interface SupportedBank {
  name: string;
  bankCode: string;
}

const BankAccountsScreen = () => {
  const navigation = useNavigation();
  const [showAddCard, setShowAddCard] = useState(false);
  const [selectedBank, setSelectedBank] = useState<SupportedBank | null>(null);
  const [accountNumber, setAccountNumber] = useState("");
  const [bankSearch, setBankSearch] = useState("");
  const [showBankDropdown, setShowBankDropdown] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // ─── Fetch user's saved banks ──────────────────────────────────
  const {
    data: banksData,
    isLoading: banksLoading,
    isError: banksError,
    refetch: refetchBanks,
  } = useFetchData_v2("bank/list", "bankList");

  const bankRecords: BankRecord[] = banksData?.data ?? [];

  // ─── Fetch supported banks list (always enabled) ──────────────
  const { data: supportedBanksData, isLoading: supportedLoading } =
    useFetchData_v2("bank/banks", "supportedBanks", {
      enabled: true,
    });

  const supportedBanks: SupportedBank[] = supportedBanksData?.data?.data ?? [];

  const getBankName = (bankCode: string) =>
    supportedBanks.find((b) => b.bankCode === bankCode)?.name ?? bankCode;

  // Show max 3 matches from search
  const filteredBanks =
    bankSearch.trim().length > 0
      ? supportedBanks
          .filter((b) =>
            b.name.toLowerCase().includes(bankSearch.toLowerCase()),
          )
          .slice(0, 3)
      : [];

  // ─── Delete bank ──────────────────────────────────────────────
  const { mutate: deleteBank } = useMutateData_v2(
    "bank/delete",
    "DELETE",
    "bankList",
    {
      onSuccess: () => {
        setDeletingId(null);
        refetchBanks();
      },
      onError: (error: any) => {
        setDeletingId(null);
        Alert.alert("Error", error?.data?.message || "Failed to remove bank");
      },
    },
  );

  const confirmDelete = (record: BankRecord) => {
    Alert.alert(
      "Remove Bank",
      `Remove ${record.accountName} — ${record.accountNumber}?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Remove",
          style: "destructive",
          onPress: () => {
            setDeletingId(record._id);
            deleteBank({ id: record._id });
          },
        },
      ],
    );
  };

  // ─── Add bank ─────────────────────────────────────────────────
  const { mutate: addBank, isPending: addLoading } = useMutateData_v2(
    "bank/add",
    "POST",
    "bankList",
    {
      onSuccess: () => {
        Alert.alert("Success", "Bank account added!");
        resetAddForm();
        refetchBanks();
      },
      onError: (error: any) => {
        Alert.alert("Error", error?.data?.message || "Failed to add bank");
      },
    },
  );

  const resetAddForm = useCallback(() => {
    setShowAddCard(false);
    setSelectedBank(null);
    setAccountNumber("");
    setBankSearch("");
    setShowBankDropdown(false);
  }, []);

  const handleAddBank = () => {
    if (!selectedBank) {
      Alert.alert("Error", "Please select a bank");
      return;
    }
    if (accountNumber.trim().length < 10) {
      Alert.alert("Error", "Enter a valid 10-digit account number");
      return;
    }
    addBank({
      accountNumber: accountNumber.trim(),
      bankCode: selectedBank.bankCode,
    });
  };

  const handleBack = useCallback(() => {
    Keyboard.dismiss();
    // Small delay lets keyboard dismiss before navigation
    setTimeout(() => {
      navigation.goBack();
    }, 50);
  }, [navigation]);

  const handleBankSearchChange = (text: string) => {
    setBankSearch(text);
    setShowBankDropdown(text.trim().length > 0);
    if (selectedBank && text !== selectedBank.name) {
      setSelectedBank(null);
    }
  };

  const handleSelectBank = (bank: SupportedBank) => {
    setSelectedBank(bank);
    setBankSearch(bank.name);
    setShowBankDropdown(false);
    Keyboard.dismiss();
  };

  // ─── Loading ──────────────────────────────────────────────────
  if (banksLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <Header onBack={handleBack} onAdd={() => {}} showAdd={false} />
        <View style={styles.centeredState}>
          <ActivityIndicator size="large" color="#1a1a2e" />
          <Text style={styles.stateText}>Loading banks...</Text>
        </View>
      </SafeAreaView>
    );
  }

  // ─── Error ────────────────────────────────────────────────────
  if (banksError) {
    return (
      <SafeAreaView style={styles.container}>
        <Header onBack={handleBack} onAdd={() => {}} showAdd={false} />
        <View style={styles.centeredState}>
          <Ionicons name="alert-circle-outline" size={48} color="#ef4444" />
          <Text style={styles.stateText}>Failed to load banks</Text>
          <TouchableOpacity
            style={styles.retryButton}
            onPress={() => refetchBanks()}
          >
            <Text style={styles.retryText}>Try Again</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Header
        onBack={handleBack}
        onAdd={() => setShowAddCard(true)}
        showAdd={!showAddCard}
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        style={styles.content}
        keyboardShouldPersistTaps="handled"
      >
        {/* ── Empty State ─────────────────────────────────── */}
        {bankRecords.length === 0 && !showAddCard && (
          <View style={styles.emptyState}>
            <Ionicons name="wallet-outline" size={52} color="#ccc" />
            <Text style={styles.emptyTitle}>No banks added yet</Text>
            <Text style={styles.emptySubtitle}>
              Add a bank account to send and receive money
            </Text>
          </View>
        )}

        {/* ── Bank Cards ──────────────────────────────────── */}
        {bankRecords.map((record) => (
          <View key={record._id} style={styles.card}>
            <View style={styles.cardLeft}>
              <View style={styles.bankIconWrap}>
                <Ionicons name="business-outline" size={18} color="#1a1a2e" />
              </View>
              <View>
                <Text style={styles.cardAccountName}>{record.accountName}</Text>
                <Text style={styles.cardAccountNumber}>
                  {record.accountNumber}
                </Text>
                <Text style={styles.cardBankName}>
                  {getBankName(record.bankCode)}
                </Text>
              </View>
            </View>

            <TouchableOpacity
              style={styles.deleteButton}
              onPress={() => confirmDelete(record)}
              disabled={deletingId === record._id}
            >
              {deletingId === record._id ? (
                <ActivityIndicator size="small" color="#ef4444" />
              ) : (
                <Ionicons name="trash-outline" size={18} color="#ef4444" />
              )}
            </TouchableOpacity>
          </View>
        ))}

        {/* ── Add Bank Inline Card ─────────────────────────── */}
        {showAddCard ? (
          <View style={styles.addCard}>
            {/* Card Header */}
            <View style={styles.addCardHeader}>
              <Text style={styles.addCardTitle}>Add Bank Account</Text>
              <TouchableOpacity
                onPress={resetAddForm}
                style={styles.addCardClose}
              >
                <Ionicons name="close" size={20} color="#666" />
              </TouchableOpacity>
            </View>

            {/* Bank Search */}
            <Text style={styles.inputLabel}>Bank Name</Text>
            <View style={styles.searchContainer}>
              <View style={styles.searchInputWrap}>
                <Ionicons
                  name="search-outline"
                  size={16}
                  color="#999"
                  style={styles.searchIcon}
                />
                <TextInput
                  style={styles.searchInput}
                  placeholder="Search bank..."
                  placeholderTextColor="#bbb"
                  value={bankSearch}
                  onChangeText={handleBankSearchChange}
                  onFocus={() => {
                    if (bankSearch.trim().length > 0) setShowBankDropdown(true);
                  }}
                />
                {bankSearch.length > 0 && (
                  <TouchableOpacity
                    onPress={() => {
                      setBankSearch("");
                      setSelectedBank(null);
                      setShowBankDropdown(false);
                    }}
                  >
                    <Ionicons name="close-circle" size={16} color="#bbb" />
                  </TouchableOpacity>
                )}
              </View>

              {/* Dropdown — max 3 results */}
              {showBankDropdown && (
                <View style={styles.dropdown}>
                  {supportedLoading ? (
                    <View style={styles.dropdownLoading}>
                      <ActivityIndicator size="small" color="#1a1a2e" />
                    </View>
                  ) : filteredBanks.length === 0 ? (
                    <View style={styles.dropdownEmpty}>
                      <Text style={styles.dropdownEmptyText}>
                        No banks found
                      </Text>
                    </View>
                  ) : (
                    filteredBanks.map((bank, index) => (
                      <TouchableOpacity
                        key={bank.bankCode}
                        style={[
                          styles.dropdownItem,
                          index < filteredBanks.length - 1 &&
                            styles.dropdownItemBorder,
                          selectedBank?.bankCode === bank.bankCode &&
                            styles.dropdownItemSelected,
                        ]}
                        onPress={() => handleSelectBank(bank)}
                      >
                        <Text
                          style={[
                            styles.dropdownItemText,
                            selectedBank?.bankCode === bank.bankCode &&
                              styles.dropdownItemTextSelected,
                          ]}
                        >
                          {bank.name}
                        </Text>
                        {selectedBank?.bankCode === bank.bankCode && (
                          <Ionicons
                            name="checkmark-circle"
                            size={16}
                            color="#10b981"
                          />
                        )}
                      </TouchableOpacity>
                    ))
                  )}
                </View>
              )}
            </View>

            {/* Selected Bank Pill */}
            {selectedBank && (
              <View style={styles.selectedPill}>
                <Ionicons name="business" size={13} color="#10b981" />
                <Text style={styles.selectedPillText}>{selectedBank.name}</Text>
              </View>
            )}

            {/* Account Number */}
            <Text style={[styles.inputLabel, { marginTop: 16 }]}>
              Account Number
            </Text>
            <TextInput
              style={styles.accountInput}
              placeholder="0000000000"
              placeholderTextColor="#bbb"
              keyboardType="numeric"
              maxLength={10}
              value={accountNumber}
              onChangeText={setAccountNumber}
            />

            {/* Submit */}
            <TouchableOpacity
              style={[
                styles.submitButton,
                (!selectedBank || accountNumber.length < 10 || addLoading) &&
                  styles.submitButtonDisabled,
              ]}
              onPress={handleAddBank}
              disabled={
                !selectedBank || accountNumber.length < 10 || addLoading
              }
            >
              {addLoading ? (
                <ActivityIndicator color="#fff" size="small" />
              ) : (
                <>
                  <Ionicons name="add-circle-outline" size={18} color="#fff" />
                  <Text style={styles.submitButtonText}>Add Bank Account</Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        ) : (
          /* ── Add Button (dashed) ─────────────────────────── */
          <TouchableOpacity
            style={styles.addButton}
            onPress={() => setShowAddCard(true)}
          >
            <Ionicons name="add-circle-outline" size={20} color="#666" />
            <Text style={styles.addButtonText}>Add Bank Account</Text>
          </TouchableOpacity>
        )}

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
};

const Header = ({
  onBack,
  onAdd,
  showAdd,
}: {
  onBack: () => void;
  onAdd: () => void;
  showAdd: boolean;
}) => (
  <View style={styles.header}>
    <TouchableOpacity
      style={styles.backButton}
      onPress={onBack}
      hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
    >
      <Ionicons name="arrow-back" size={24} color="#1a1a2e" />
    </TouchableOpacity>
    <Text style={styles.headerTitle}>Bank Accounts</Text>
    {showAdd ? (
      <TouchableOpacity
        style={styles.addIconButton}
        onPress={onAdd}
        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      >
        <Ionicons name="add" size={24} color="#1a1a2e" />
      </TouchableOpacity>
    ) : (
      <View style={{ width: 40 }} />
    )}
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f5f5f5" },

  // ── Header ──────────────────────────────────────────────────
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e5e5",
    backgroundColor: "#fff",
  },
  headerTitle: { fontSize: 18, fontWeight: "700", color: "#1a1a2e" },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  addIconButton: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },

  // ── Layout ──────────────────────────────────────────────────
  content: { flex: 1, padding: 16 },
  centeredState: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    gap: 12,
    paddingHorizontal: 32,
  },
  stateText: { fontSize: 14, color: "#666", textAlign: "center" },
  retryButton: {
    backgroundColor: "#1a1a2e",
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 10,
  },
  retryText: { color: "#fff", fontWeight: "600", fontSize: 14 },

  // ── Empty State ─────────────────────────────────────────────
  emptyState: { alignItems: "center", paddingVertical: 56, gap: 8 },
  emptyTitle: { fontSize: 16, fontWeight: "600", color: "#333" },
  emptySubtitle: { fontSize: 13, color: "#999", textAlign: "center" },

  // ── Bank Record Card ────────────────────────────────────────
  card: {
    backgroundColor: "#fff",
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    padding: 16,
    marginBottom: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  cardLeft: { flexDirection: "row", alignItems: "center", gap: 12, flex: 1 },
  bankIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: "#f0f4f8",
    justifyContent: "center",
    alignItems: "center",
  },
  cardAccountName: {
    fontSize: 15,
    fontWeight: "600",
    color: "#1a1a2e",
    marginBottom: 2,
  },
  cardAccountNumber: {
    fontSize: 13,
    color: "#555",
    letterSpacing: 1,
    marginBottom: 2,
  },
  cardBankName: { fontSize: 12, color: "#999" },
  deleteButton: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: "#fff0f0",
    justifyContent: "center",
    alignItems: "center",
  },

  // ── Add Dashed Button ───────────────────────────────────────
  addButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    borderWidth: 2,
    borderColor: "#e5e5e5",
    borderStyle: "dashed",
    borderRadius: 14,
    paddingVertical: 20,
    marginTop: 4,
  },
  addButtonText: { fontSize: 15, fontWeight: "500", color: "#666" },

  // ── Add Bank Inline Card ────────────────────────────────────
  addCard: {
    backgroundColor: "#fff",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#e0e7ef",
    padding: 18,
    marginTop: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 3,
  },
  addCardHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 18,
  },
  addCardTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#1a1a2e",
  },
  addCardClose: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: "#f5f5f5",
    justifyContent: "center",
    alignItems: "center",
  },

  // ── Form Fields ─────────────────────────────────────────────
  inputLabel: {
    fontSize: 13,
    fontWeight: "600",
    color: "#555",
    marginBottom: 8,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },

  // ── Bank Search ─────────────────────────────────────────────
  searchContainer: {
    position: "relative",
    zIndex: 10,
  },
  searchInputWrap: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f5f7fa",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    paddingHorizontal: 12,
    paddingVertical: 12,
    gap: 8,
  },
  searchIcon: { marginRight: 2 },
  searchInput: {
    flex: 1,
    fontSize: 15,
    color: "#1a1a2e",
    padding: 0,
  },

  // ── Dropdown ────────────────────────────────────────────────
  dropdown: {
    position: "absolute",
    top: "100%",
    left: 0,
    right: 0,
    backgroundColor: "#fff",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    marginTop: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 8,
    overflow: "hidden",
    zIndex: 100,
  },
  dropdownLoading: {
    paddingVertical: 16,
    alignItems: "center",
  },
  dropdownEmpty: {
    paddingVertical: 16,
    alignItems: "center",
  },
  dropdownEmptyText: {
    fontSize: 13,
    color: "#999",
  },
  dropdownItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 14,
    paddingVertical: 14,
  },
  dropdownItemBorder: {
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  dropdownItemSelected: {
    backgroundColor: "#f0fdf7",
  },
  dropdownItemText: {
    fontSize: 14,
    color: "#1a1a2e",
    fontWeight: "500",
    flex: 1,
  },
  dropdownItemTextSelected: {
    color: "#10b981",
  },

  // ── Selected Bank Pill ──────────────────────────────────────
  selectedPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    alignSelf: "flex-start",
    backgroundColor: "#f0fdf7",
    borderRadius: 20,
    borderWidth: 1,
    borderColor: "#6ee7b7",
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginTop: 8,
  },
  selectedPillText: {
    fontSize: 12,
    color: "#059669",
    fontWeight: "600",
  },

  // ── Account Number Input ────────────────────────────────────
  accountInput: {
    backgroundColor: "#f5f7fa",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    paddingHorizontal: 14,
    paddingVertical: 14,
    fontSize: 18,
    color: "#1a1a2e",
    letterSpacing: 3,
    fontWeight: "600",
  },

  // ── Submit Button ───────────────────────────────────────────
  submitButton: {
    backgroundColor: "#1a1a2e",
    height: 52,
    borderRadius: 12,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 8,
    marginTop: 20,
  },
  submitButtonDisabled: {
    backgroundColor: "#9ca3af",
  },
  submitButtonText: { color: "#fff", fontSize: 15, fontWeight: "600" },
});

export default BankAccountsScreen;
