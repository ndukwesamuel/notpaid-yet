// import React, { useState } from "react";
// import {
//   View,
//   Text,
//   StyleSheet,
//   TextInput,
//   TouchableOpacity,
//   ScrollView,
//   Alert,
//   ActivityIndicator,
// } from "react-native";
// import { SafeAreaView } from "react-native-safe-area-context";
// import { Ionicons } from "@expo/vector-icons";
// import { useMutateData_v2 } from "../../hooks/Requestv2";
// // import { useMutateData_v2 } from "../../hooks/useApiHook"; // adjust path to your hook file

// type KycStep = "bvn" | "nin" | "done";

// interface KycScreenProps {
//   onComplete: () => void;
//   onSkip?: () => void;
// }

// const KycScreen = ({ onComplete, onSkip }: KycScreenProps) => {
//   const [step, setStep] = useState<KycStep>("bvn");
//   const [bvn, setBvn] = useState("");
//   const [nin, setNin] = useState("");

//   // ─── Hooks (always called at top level — never inside conditions) ──
//   const bvnMutation = useMutateData_v2("kyc/bvn", "POST", undefined, {
//     onSuccess: () => {
//       setStep("nin");
//     },
//     onError: (error: any) => {
//       const msg = error?.data?.message || "BVN verification failed. Try again.";
//       Alert.alert("BVN Error", msg);
//     },
//   });

//   const ninMutation = useMutateData_v2("kyc/nin", "POST", undefined, {
//     onSuccess: () => {
//       setStep("done");
//     },
//     onError: (error: any) => {
//       console.log({ kaka: error.data });

//       const msg = error?.data?.message || "NIN verification failed. Try again.";
//       Alert.alert("NIN Error", msg);
//     },
//   });

//   // Disable inputs while either request is in flight
//   const isLoading = bvnMutation.isPending || ninMutation.isPending;

//   // ─── BVN Submit ───────────────────────────────────────────────
//   const handleBvnSubmit = () => {
//     if (!bvn.trim()) {
//       Alert.alert("Error", "Please enter your BVN");
//       return;
//     }
//     if (bvn.trim().length !== 11) {
//       Alert.alert("Error", "BVN must be exactly 11 digits");
//       return;
//     }
//     bvnMutation.mutate({ number: bvn.trim() });
//   };

//   // ─── NIN Submit ───────────────────────────────────────────────
//   const handleNinSubmit = () => {
//     if (!nin.trim()) {
//       Alert.alert("Error", "Please enter your NIN");
//       return;
//     }
//     if (nin.trim().length !== 11) {
//       Alert.alert("Error", "NIN must be exactly 11 digits");
//       return;
//     }
//     ninMutation.mutate({ number_nin: nin.trim() });
//   };

//   // ─── Success Screen ───────────────────────────────────────────
//   if (step === "done") {
//     return (
//       <SafeAreaView style={styles.container}>
//         <View style={styles.successContainer}>
//           <View style={styles.successIconWrap}>
//             <Ionicons name="checkmark-circle" size={80} color="#10b981" />
//           </View>
//           <Text style={styles.successTitle}>Identity Verified!</Text>
//           <Text style={styles.successSubtitle}>
//             Your BVN and NIN have been successfully verified. Your account is
//             now fully activated.
//           </Text>
//           <TouchableOpacity style={styles.button} onPress={onComplete}>
//             <Text style={styles.buttonText}>Continue to Dashboard</Text>
//           </TouchableOpacity>
//         </View>
//       </SafeAreaView>
//     );
//   }

//   const isBvnStep = step === "bvn";

//   return (
//     <SafeAreaView style={styles.container}>
//       {/* Header */}
//       <View style={styles.header}>
//         {isBvnStep ? (
//           onSkip ? (
//             <TouchableOpacity
//               style={styles.backButton}
//               onPress={onSkip}
//               disabled={isLoading}
//             >
//               <Ionicons name="arrow-back" size={24} color="#1a1a2e" />
//             </TouchableOpacity>
//           ) : (
//             <View style={styles.backButton} />
//           )
//         ) : (
//           <TouchableOpacity
//             style={styles.backButton}
//             onPress={() => setStep("bvn")}
//             disabled={isLoading}
//           >
//             <Ionicons name="arrow-back" size={24} color="#1a1a2e" />
//           </TouchableOpacity>
//         )}
//       </View>

//       <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
//         {/* Logo */}
//         <View style={styles.logoContainer}>
//           <Ionicons name="shield-checkmark" size={32} color="#10b981" />
//           <Text style={styles.logoText}>Verify Identity</Text>
//         </View>

//         {/* Step Indicator */}
//         <View style={styles.stepRow}>
//           {/* Step 1 - BVN */}
//           <View style={styles.stepItem}>
//             <View
//               style={[
//                 styles.stepCircle,
//                 isBvnStep ? styles.stepActive : styles.stepDone,
//               ]}
//             >
//               {!isBvnStep ? (
//                 <Ionicons name="checkmark" size={14} color="#fff" />
//               ) : (
//                 <Text style={styles.stepNumber}>1</Text>
//               )}
//             </View>
//             <Text
//               style={[
//                 styles.stepLabel,
//                 isBvnStep ? styles.stepLabelActive : styles.stepLabelDone,
//               ]}
//             >
//               BVN
//             </Text>
//           </View>

//           {/* Connector line */}
//           <View style={[styles.stepLine, !isBvnStep && styles.stepLineDone]} />

//           {/* Step 2 - NIN */}
//           <View style={styles.stepItem}>
//             <View
//               style={[
//                 styles.stepCircle,
//                 !isBvnStep ? styles.stepActive : styles.stepInactive,
//               ]}
//             >
//               <Text
//                 style={[
//                   styles.stepNumber,
//                   !isBvnStep && styles.stepNumberActive,
//                 ]}
//               >
//                 2
//               </Text>
//             </View>
//             <Text
//               style={[
//                 styles.stepLabel,
//                 !isBvnStep ? styles.stepLabelActive : styles.stepLabelInactive,
//               ]}
//             >
//               NIN
//             </Text>
//           </View>
//         </View>

//         {/* ── BVN FORM ── */}
//         {isBvnStep && (
//           <View style={styles.form}>
//             <Text style={styles.title}>Verify your BVN</Text>
//             <Text style={styles.subtitle}>
//               Enter your 11-digit Bank Verification Number to confirm your
//               identity.
//             </Text>

//             <View style={styles.infoBox}>
//               <Ionicons
//                 name="information-circle-outline"
//                 size={18}
//                 color="#3b82f6"
//               />
//               <Text style={styles.infoText}>
//                 Your BVN is safe and only used for identity verification. It
//                 does not grant access to your bank account.
//               </Text>
//             </View>

//             <Text style={styles.label}>Bank Verification Number (BVN)</Text>
//             <TextInput
//               style={styles.input}
//               placeholder="Enter your 11-digit BVN"
//               placeholderTextColor="#999"
//               keyboardType="numeric"
//               maxLength={11}
//               value={bvn}
//               onChangeText={setBvn}
//               editable={!isLoading}
//             />

//             <TouchableOpacity
//               style={[styles.button, isLoading && styles.buttonDisabled]}
//               onPress={handleBvnSubmit}
//               disabled={isLoading}
//             >
//               {bvnMutation.isPending ? (
//                 <ActivityIndicator color="#fff" />
//               ) : (
//                 <Text style={styles.buttonText}>Verify BVN</Text>
//               )}
//             </TouchableOpacity>
//           </View>
//         )}

//         {/* ── NIN FORM ── */}
//         {!isBvnStep && (
//           <View style={styles.form}>
//             <Text style={styles.title}>Verify your NIN</Text>
//             <Text style={styles.subtitle}>
//               One last step! Enter your 11-digit National Identification Number.
//             </Text>

//             <View style={styles.successBadge}>
//               <Ionicons name="checkmark-circle" size={18} color="#10b981" />
//               <Text style={styles.successBadgeText}>
//                 BVN verified successfully
//               </Text>
//             </View>

//             <View style={styles.infoBox}>
//               <Ionicons
//                 name="information-circle-outline"
//                 size={18}
//                 color="#3b82f6"
//               />
//               <Text style={styles.infoText}>
//                 Your NIN is issued by NIMC. You can find it on your National ID
//                 card or NIMC slip.
//               </Text>
//             </View>

//             <Text style={styles.label}>
//               National Identification Number (NIN)
//             </Text>
//             <TextInput
//               style={styles.input}
//               placeholder="Enter your 11-digit NIN"
//               placeholderTextColor="#999"
//               keyboardType="numeric"
//               maxLength={11}
//               value={nin}
//               onChangeText={setNin}
//               editable={!isLoading}
//             />

//             <TouchableOpacity
//               style={[styles.button, isLoading && styles.buttonDisabled]}
//               onPress={handleNinSubmit}
//               disabled={isLoading}
//             >
//               {ninMutation.isPending ? (
//                 <ActivityIndicator color="#fff" />
//               ) : (
//                 <Text style={styles.buttonText}>Verify NIN</Text>
//               )}
//             </TouchableOpacity>
//           </View>
//         )}
//       </ScrollView>
//     </SafeAreaView>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#fff",
//   },
//   header: {
//     paddingHorizontal: 20,
//     paddingVertical: 12,
//   },
//   backButton: {
//     width: 44,
//     height: 44,
//     borderRadius: 22,
//     backgroundColor: "#f5f5f5",
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   content: {
//     flex: 1,
//     paddingHorizontal: 24,
//   },
//   logoContainer: {
//     flexDirection: "row",
//     alignItems: "center",
//     gap: 8,
//     marginBottom: 24,
//   },
//   logoText: {
//     fontSize: 22,
//     fontWeight: "700",
//     color: "#1a1a2e",
//   },
//   stepRow: {
//     flexDirection: "row",
//     alignItems: "center",
//     marginBottom: 32,
//   },
//   stepItem: {
//     alignItems: "center",
//     gap: 6,
//   },
//   stepCircle: {
//     width: 32,
//     height: 32,
//     borderRadius: 16,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   stepActive: {
//     backgroundColor: "#1a1a2e",
//   },
//   stepDone: {
//     backgroundColor: "#10b981",
//   },
//   stepInactive: {
//     backgroundColor: "#e5e7eb",
//   },
//   stepNumber: {
//     fontSize: 13,
//     fontWeight: "700",
//     color: "#999",
//   },
//   stepNumberActive: {
//     color: "#fff",
//   },
//   stepLabel: {
//     fontSize: 12,
//     fontWeight: "600",
//   },
//   stepLabelActive: {
//     color: "#1a1a2e",
//   },
//   stepLabelDone: {
//     color: "#10b981",
//   },
//   stepLabelInactive: {
//     color: "#aaa",
//   },
//   stepLine: {
//     flex: 1,
//     height: 2,
//     backgroundColor: "#e5e7eb",
//     marginHorizontal: 8,
//     marginBottom: 18,
//   },
//   stepLineDone: {
//     backgroundColor: "#10b981",
//   },
//   form: {
//     paddingBottom: 40,
//   },
//   title: {
//     fontSize: 26,
//     fontWeight: "700",
//     color: "#1a1a2e",
//     marginBottom: 8,
//   },
//   subtitle: {
//     fontSize: 14,
//     color: "#666",
//     lineHeight: 20,
//     marginBottom: 20,
//   },
//   infoBox: {
//     flexDirection: "row",
//     alignItems: "flex-start",
//     gap: 10,
//     backgroundColor: "#eff6ff",
//     borderRadius: 10,
//     padding: 14,
//     marginBottom: 24,
//   },
//   infoText: {
//     flex: 1,
//     fontSize: 13,
//     color: "#3b82f6",
//     lineHeight: 18,
//   },
//   successBadge: {
//     flexDirection: "row",
//     alignItems: "center",
//     gap: 8,
//     backgroundColor: "#f0fdf4",
//     borderRadius: 10,
//     padding: 12,
//     marginBottom: 16,
//   },
//   successBadgeText: {
//     fontSize: 13,
//     fontWeight: "600",
//     color: "#10b981",
//   },
//   label: {
//     fontSize: 14,
//     fontWeight: "500",
//     color: "#1a1a2e",
//     marginBottom: 8,
//   },
//   input: {
//     backgroundColor: "#f0f4f8",
//     borderRadius: 12,
//     paddingHorizontal: 16,
//     paddingVertical: 16,
//     fontSize: 16,
//     color: "#1a1a2e",
//     marginBottom: 24,
//     letterSpacing: 2,
//   },
//   button: {
//     backgroundColor: "#1a1a2e",
//     height: 56,
//     borderRadius: 12,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   buttonDisabled: {
//     opacity: 0.7,
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 16,
//     fontWeight: "600",
//   },
//   successContainer: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     paddingHorizontal: 32,
//   },
//   successIconWrap: {
//     marginBottom: 24,
//   },
//   successTitle: {
//     fontSize: 28,
//     fontWeight: "700",
//     color: "#1a1a2e",
//     marginBottom: 12,
//     textAlign: "center",
//   },
//   successSubtitle: {
//     fontSize: 15,
//     color: "#666",
//     textAlign: "center",
//     lineHeight: 22,
//     marginBottom: 40,
//   },
// });

// export default KycScreen;

import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { useSelector } from "react-redux";
import { useMutateData_v2 } from "../../hooks/Requestv2";

type KycStep = "bvn" | "nin" | "done";

// ─── Determine the starting step based on what's already verified ──
const getInitialStep = (
  bvnVerified: boolean,
  ninVerified: boolean,
): KycStep => {
  if (bvnVerified && ninVerified) return "done"; // both done
  if (bvnVerified && !ninVerified) return "nin"; // only NIN left
  return "bvn"; // BVN not done (do it first regardless)
};

const KycScreen = () => {
  const navigation = useNavigation();

  // ─── Read verification status from Redux ──────────────────────
  const userDetails = useSelector((state: any) => state.authSlice.userDetails);
  const bvnVerified = userDetails?.bvnKycStatus === true;
  const ninVerified = userDetails?.ninKycStatus === true;

  const [step, setStep] = useState<KycStep>(
    getInitialStep(bvnVerified, ninVerified),
  );
  const [bvn, setBvn] = useState("");
  const [nin, setNin] = useState("");

  // ─── Hooks (always at top level) ─────────────────────────────
  const bvnMutation = useMutateData_v2("kyc/bvn", "POST", undefined, {
    onSuccess: () => {
      // After BVN, go to NIN only if NIN not already verified
      if (ninVerified) {
        setStep("done");
      } else {
        setStep("nin");
      }
    },
    onError: (error: any) => {
      const msg = error?.data?.message || "BVN verification failed. Try again.";
      Alert.alert("BVN Error", msg);
    },
  });

  const ninMutation = useMutateData_v2("kyc/nin", "POST", undefined, {
    onSuccess: () => {
      setStep("done");
    },
    onError: (error: any) => {
      const msg = error?.data?.message || "NIN verification failed. Try again.";
      Alert.alert("NIN Error", msg);
    },
  });

  const isLoading = bvnMutation.isPending || ninMutation.isPending;

  // ─── BVN Submit ───────────────────────────────────────────────
  const handleBvnSubmit = () => {
    if (!bvn.trim()) return Alert.alert("Error", "Please enter your BVN");
    if (bvn.trim().length !== 11)
      return Alert.alert("Error", "BVN must be exactly 11 digits");
    bvnMutation.mutate({ number: bvn.trim() });
  };

  // ─── NIN Submit ───────────────────────────────────────────────
  const handleNinSubmit = () => {
    if (!nin.trim()) return Alert.alert("Error", "Please enter your NIN");
    if (nin.trim().length !== 11)
      return Alert.alert("Error", "NIN must be exactly 11 digits");
    ninMutation.mutate({ number_nin: nin.trim() });
  };

  // ─── Handle back press ────────────────────────────────────────
  const handleBack = () => {
    if (step === "nin" && !bvnVerified) {
      // If we got here by completing BVN in this session, go back to BVN
      setStep("bvn");
    } else {
      // Otherwise go back to the previous screen
      navigation.goBack();
    }
  };

  // ─── Step indicator helpers ───────────────────────────────────
  const isBvnStep = step === "bvn";
  const isNinStep = step === "nin";

  // ─── Success Screen ───────────────────────────────────────────
  if (step === "done") {
    return (
      <SafeAreaView style={styles.container}>
        {/* Back button on success too */}
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <Ionicons name="arrow-back" size={24} color="#1a1a2e" />
          </TouchableOpacity>
        </View>
        <View style={styles.successContainer}>
          <View style={styles.successIconWrap}>
            <Ionicons name="checkmark-circle" size={80} color="#10b981" />
          </View>
          <Text style={styles.successTitle}>Identity Verified!</Text>
          <Text style={styles.successSubtitle}>
            Your BVN and NIN have been successfully verified. Your account is
            now fully activated.
          </Text>
          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.buttonText}>Continue to Dashboard</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* ─── Header with back button ─── */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={handleBack}
          disabled={isLoading}
        >
          <Ionicons name="arrow-back" size={24} color="#1a1a2e" />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
        {/* Logo */}
        <View style={styles.logoContainer}>
          <Ionicons name="shield-checkmark" size={32} color="#10b981" />
          <Text style={styles.logoText}>Verify Identity</Text>
        </View>

        {/* ─── Step Indicator ───
            Only show the steps that are not yet verified.
            If only BVN needed  → single step shown
            If only NIN needed  → single step shown
            If both needed      → two steps shown
        */}
        {!bvnVerified && !ninVerified ? (
          // Both needed — show 2-step indicator
          <View style={styles.stepRow}>
            <View style={styles.stepItem}>
              <View
                style={[
                  styles.stepCircle,
                  isBvnStep ? styles.stepActive : styles.stepDone,
                ]}
              >
                {isNinStep ? (
                  <Ionicons name="checkmark" size={14} color="#fff" />
                ) : (
                  <Text
                    style={[
                      styles.stepNumber,
                      isBvnStep && styles.stepNumberActive,
                    ]}
                  >
                    1
                  </Text>
                )}
              </View>
              <Text
                style={[
                  styles.stepLabel,
                  isBvnStep ? styles.stepLabelActive : styles.stepLabelDone,
                ]}
              >
                BVN
              </Text>
            </View>

            <View style={[styles.stepLine, isNinStep && styles.stepLineDone]} />

            <View style={styles.stepItem}>
              <View
                style={[
                  styles.stepCircle,
                  isNinStep ? styles.stepActive : styles.stepInactive,
                ]}
              >
                <Text
                  style={[
                    styles.stepNumber,
                    isNinStep && styles.stepNumberActive,
                  ]}
                >
                  2
                </Text>
              </View>
              <Text
                style={[
                  styles.stepLabel,
                  isNinStep ? styles.stepLabelActive : styles.stepLabelInactive,
                ]}
              >
                NIN
              </Text>
            </View>
          </View>
        ) : (
          // Only one step needed — show single pill
          <View style={styles.singleStepRow}>
            <View style={styles.singleStepPill}>
              <Ionicons
                name="shield-outline"
                size={14}
                color="#fff"
                style={{ marginRight: 6 }}
              />
              <Text style={styles.singleStepText}>
                {bvnVerified ? "NIN Verification" : "BVN Verification"}
              </Text>
            </View>
          </View>
        )}

        {/* ── BVN FORM ── */}
        {isBvnStep && (
          <View style={styles.form}>
            <Text style={styles.title}>Verify your BVN</Text>
            <Text style={styles.subtitle}>
              Enter your 11-digit Bank Verification Number to confirm your
              identity.
            </Text>

            <View style={styles.infoBox}>
              <Ionicons
                name="information-circle-outline"
                size={18}
                color="#3b82f6"
              />
              <Text style={styles.infoText}>
                Your BVN is safe and only used for identity verification. It
                does not grant access to your bank account.
              </Text>
            </View>

            <Text style={styles.label}>Bank Verification Number (BVN)</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter your 11-digit BVN"
              placeholderTextColor="#999"
              keyboardType="numeric"
              maxLength={11}
              value={bvn}
              onChangeText={setBvn}
              editable={!isLoading}
            />

            <TouchableOpacity
              style={[styles.button, isLoading && styles.buttonDisabled]}
              onPress={handleBvnSubmit}
              disabled={isLoading}
            >
              {bvnMutation.isPending ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.buttonText}>Verify BVN</Text>
              )}
            </TouchableOpacity>
          </View>
        )}

        {/* ── NIN FORM ── */}
        {isNinStep && (
          <View style={styles.form}>
            <Text style={styles.title}>Verify your NIN</Text>
            <Text style={styles.subtitle}>
              {bvnVerified
                ? "Enter your 11-digit National Identification Number."
                : "One last step! Enter your 11-digit National Identification Number."}
            </Text>

            {/* Only show BVN success badge if BVN was just done this session */}
            {bvnVerified && (
              <View style={styles.successBadge}>
                <Ionicons name="checkmark-circle" size={18} color="#10b981" />
                <Text style={styles.successBadgeText}>
                  BVN already verified ✓
                </Text>
              </View>
            )}
            {!bvnVerified && (
              <View style={styles.successBadge}>
                <Ionicons name="checkmark-circle" size={18} color="#10b981" />
                <Text style={styles.successBadgeText}>
                  BVN verified successfully
                </Text>
              </View>
            )}

            <View style={styles.infoBox}>
              <Ionicons
                name="information-circle-outline"
                size={18}
                color="#3b82f6"
              />
              <Text style={styles.infoText}>
                Your NIN is issued by NIMC. You can find it on your National ID
                card or NIMC slip.
              </Text>
            </View>

            <Text style={styles.label}>
              National Identification Number (NIN)
            </Text>
            <TextInput
              style={styles.input}
              placeholder="Enter your 11-digit NIN"
              placeholderTextColor="#999"
              keyboardType="numeric"
              maxLength={11}
              value={nin}
              onChangeText={setNin}
              editable={!isLoading}
            />

            <TouchableOpacity
              style={[styles.button, isLoading && styles.buttonDisabled]}
              onPress={handleNinSubmit}
              disabled={isLoading}
            >
              {ninMutation.isPending ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.buttonText}>Verify NIN</Text>
              )}
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: "#f5f5f5",
    justifyContent: "center",
    alignItems: "center",
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
  },
  logoContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginBottom: 24,
  },
  logoText: {
    fontSize: 22,
    fontWeight: "700",
    color: "#1a1a2e",
  },
  // Two-step indicator
  stepRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 32,
  },
  stepItem: {
    alignItems: "center",
    gap: 6,
  },
  stepCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: "center",
    alignItems: "center",
  },
  stepActive: {
    backgroundColor: "#1a1a2e",
  },
  stepDone: {
    backgroundColor: "#10b981",
  },
  stepInactive: {
    backgroundColor: "#e5e7eb",
  },
  stepNumber: {
    fontSize: 13,
    fontWeight: "700",
    color: "#999",
  },
  stepNumberActive: {
    color: "#fff",
  },
  stepLabel: {
    fontSize: 12,
    fontWeight: "600",
  },
  stepLabelActive: {
    color: "#1a1a2e",
  },
  stepLabelDone: {
    color: "#10b981",
  },
  stepLabelInactive: {
    color: "#aaa",
  },
  stepLine: {
    flex: 1,
    height: 2,
    backgroundColor: "#e5e7eb",
    marginHorizontal: 8,
    marginBottom: 18,
  },
  stepLineDone: {
    backgroundColor: "#10b981",
  },
  // Single-step pill (when only one verification remains)
  singleStepRow: {
    marginBottom: 32,
  },
  singleStepPill: {
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "flex-start",
    backgroundColor: "#1a1a2e",
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  singleStepText: {
    color: "#fff",
    fontSize: 13,
    fontWeight: "600",
  },
  form: {
    paddingBottom: 40,
  },
  title: {
    fontSize: 26,
    fontWeight: "700",
    color: "#1a1a2e",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: "#666",
    lineHeight: 20,
    marginBottom: 20,
  },
  infoBox: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    backgroundColor: "#eff6ff",
    borderRadius: 10,
    padding: 14,
    marginBottom: 24,
  },
  infoText: {
    flex: 1,
    fontSize: 13,
    color: "#3b82f6",
    lineHeight: 18,
  },
  successBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "#f0fdf4",
    borderRadius: 10,
    padding: 12,
    marginBottom: 16,
  },
  successBadgeText: {
    fontSize: 13,
    fontWeight: "600",
    color: "#10b981",
  },
  label: {
    fontSize: 14,
    fontWeight: "500",
    color: "#1a1a2e",
    marginBottom: 8,
  },
  input: {
    backgroundColor: "#f0f4f8",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 16,
    fontSize: 16,
    color: "#1a1a2e",
    marginBottom: 24,
    letterSpacing: 2,
  },
  button: {
    backgroundColor: "#1a1a2e",
    height: 56,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
  },
  buttonDisabled: {
    opacity: 0.7,
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  successContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 32,
  },
  successIconWrap: {
    marginBottom: 24,
  },
  successTitle: {
    fontSize: 28,
    fontWeight: "700",
    color: "#1a1a2e",
    marginBottom: 12,
    textAlign: "center",
  },
  successSubtitle: {
    fontSize: 15,
    color: "#666",
    textAlign: "center",
    lineHeight: 22,
    marginBottom: 40,
  },
});

export default KycScreen;
