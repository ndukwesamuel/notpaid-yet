import React from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Linking,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons, Feather } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";

const FAQ_DATA = [
  {
    question: "How do I fund my wallet?",
    answer:
      "You can fund your wallet by clicking the 'Add Money' button on the home screen. You can use your bank account or card to add funds.",
  },
  {
    question: "How do I buy data?",
    answer:
      "Go to the Recommended section and tap on 'Bills & Airtime'. Enter your phone number, select your network, and choose a data plan.",
  },
  {
    question: "How do I transfer money?",
    answer:
      "Click the 'Send' button on the home screen, enter the recipient's email and the amount you want to send.",
  },
  {
    question: "What should I do if a transaction fails?",
    answer:
      "If a transaction fails, the funds will be automatically refunded to your wallet within 24 hours. Contact support if you don't receive the refund.",
  },
];

const HelpSupportScreen = () => {
  const navigation = useNavigation();

  const handleEmailSupport = () => {
    Linking.openURL("mailto:support@pay-la.com");
  };

  const handlePhoneSupport = () => {
    Linking.openURL("tel:+2341234567890");
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Help & Support</Text>
        <TouchableOpacity
          style={styles.closeButton}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="close" size={24} color="#1a1a2e" />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
        {/* FAQ Section */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Frequently Asked Questions</Text>

          {FAQ_DATA.map((faq, index) => (
            <View key={index}>
              <View style={styles.faqItem}>
                <Text style={styles.faqQuestion}>{faq.question}</Text>
                <Text style={styles.faqAnswer}>{faq.answer}</Text>
              </View>
              {index < FAQ_DATA.length - 1 && <View style={styles.divider} />}
            </View>
          ))}
        </View>

        {/* Contact Support Section */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Contact Support</Text>

          <TouchableOpacity
            style={styles.contactItem}
            onPress={handleEmailSupport}
          >
            <View style={styles.contactIconContainer}>
              <Feather name="mail" size={20} color="#666" />
            </View>
            <Text style={styles.contactText}>Email Support</Text>
            <Ionicons name="chevron-forward" size={20} color="#999" />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.contactItem}
            onPress={handlePhoneSupport}
          >
            <View style={styles.contactIconContainer}>
              <Feather name="phone" size={20} color="#666" />
            </View>
            <Text style={styles.contactText}>Phone Support</Text>
            <Ionicons name="chevron-forward" size={20} color="#999" />
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e5e5",
    backgroundColor: "#fff",
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: "#1a1a2e",
  },
  closeButton: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  content: {
    flex: 1,
    padding: 16,
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    padding: 20,
    marginBottom: 16,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: "#1a1a2e",
    marginBottom: 16,
  },
  faqItem: {
    paddingVertical: 12,
  },
  faqQuestion: {
    fontSize: 15,
    fontWeight: "600",
    color: "#1a1a2e",
    marginBottom: 8,
  },
  faqAnswer: {
    fontSize: 14,
    color: "#666",
    lineHeight: 20,
  },
  divider: {
    height: 1,
    backgroundColor: "#f0f0f0",
  },
  contactItem: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f9f9f9",
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  contactIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: "#fff",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },
  contactText: {
    flex: 1,
    fontSize: 15,
    fontWeight: "500",
    color: "#1a1a2e",
  },
});

export default HelpSupportScreen;
