import React from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";

const FEATURES = [
  "Secure wallet management",
  "Instant money transfers",
  "Mobile data purchases",
  "Transaction history",
  "Bank account integration",
];

const AboutScreen = () => {
  const navigation = useNavigation();

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>About</Text>
        <TouchableOpacity
          style={styles.closeButton}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="close" size={24} color="#1a1a2e" />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
        {/* Logo & Version */}
        <View style={styles.logoSection}>
          <View style={styles.logoContainer}>
            <View style={styles.logoIcon}>
              <Ionicons name="swap-horizontal" size={24} color="#10b981" />
            </View>
            <Text style={styles.logoText}>Pay-la</Text>
          </View>
          <Text style={styles.appName}>Pay-la</Text>
          <Text style={styles.version}>Version 1.0.0</Text>
        </View>

        {/* About Card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>About Pay-la</Text>
          <Text style={styles.cardText}>
            Pay-la is a mobile-first wallet application that allows you to send
            money, buy data, and manage your finances all in one place.
          </Text>

          <Text style={styles.sectionTitle}>Features</Text>
          {FEATURES.map((feature, index) => (
            <View key={index} style={styles.featureItem}>
              <View style={styles.bullet} />
              <Text style={styles.featureText}>{feature}</Text>
            </View>
          ))}

          <Text style={styles.sectionTitle}>Privacy & Security</Text>
          <Text style={styles.cardText}>
            Your financial data is encrypted and secure. We use
            industry-standard security measures to protect your information.
          </Text>
        </View>

        {/* Copyright */}
        <Text style={styles.copyright}>
          © 2024 Pay-la. All rights reserved.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e5e5",
    backgroundColor: "#fff",
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: "#1a1a2e",
  },
  closeButton: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  content: {
    flex: 1,
  },
  logoSection: {
    alignItems: "center",
    paddingVertical: 32,
  },
  logoContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  logoIcon: {
    marginRight: 8,
  },
  logoText: {
    fontSize: 20,
    fontWeight: "700",
    color: "#1a1a2e",
  },
  appName: {
    fontSize: 24,
    fontWeight: "700",
    color: "#1a1a2e",
    marginBottom: 4,
  },
  version: {
    fontSize: 14,
    color: "#666",
  },
  card: {
    backgroundColor: "#fff",
    marginHorizontal: 16,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    padding: 20,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: "#1a1a2e",
    marginBottom: 12,
  },
  cardText: {
    fontSize: 14,
    color: "#666",
    lineHeight: 22,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#1a1a2e",
    marginTop: 20,
    marginBottom: 12,
  },
  featureItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  bullet: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: "#1a1a2e",
    marginRight: 12,
  },
  featureText: {
    fontSize: 14,
    color: "#666",
  },
  copyright: {
    fontSize: 13,
    color: "#999",
    textAlign: "center",
    marginVertical: 24,
  },
});

export default AboutScreen;
