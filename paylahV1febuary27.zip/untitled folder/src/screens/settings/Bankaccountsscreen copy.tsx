// // // import React from "react";
// // // import {
// // //   View,
// // //   Text,
// // //   StyleSheet,
// // //   TouchableOpacity,
// // //   ScrollView,
// // //   Alert,
// // // } from "react-native";
// // // import { SafeAreaView } from "react-native-safe-area-context";
// // // import { Ionicons } from "@expo/vector-icons";
// // // import { useNavigation } from "@react-navigation/native";

// // // const DUMMY_ACCOUNTS = [
// // //   {
// // //     id: "1",
// // //     bankName: "Access Bank",
// // //     accountName: "John Doe",
// // //     accountNumber: "****1234",
// // //     isDefault: true,
// // //   },
// // //   {
// // //     id: "2",
// // //     bankName: "GTBank",
// // //     accountName: "John Doe",
// // //     accountNumber: "****5678",
// // //     isDefault: false,
// // //   },
// // // ];

// // // const BankAccountsScreen = () => {
// // //   const navigation = useNavigation();

// // //   const handleEdit = (accountId: string) => {
// // //     Alert.alert("Edit Account", `Edit account ${accountId}`);
// // //   };

// // //   const handleAddAccount = () => {
// // //     Alert.alert("Add Account", "Add new bank account functionality");
// // //   };

// // //   return (
// // //     <SafeAreaView style={styles.container}>
// // //       {/* Header */}
// // //       <View style={styles.header}>
// // //         <Text style={styles.headerTitle}>Bank Accounts</Text>
// // //         <TouchableOpacity
// // //           style={styles.closeButton}
// // //           onPress={() => navigation.goBack()}
// // //         >
// // //           <Ionicons name="close" size={24} color="#1a1a2e" />
// // //         </TouchableOpacity>
// // //       </View>

// // //       <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
// // //         {/* Bank Account Cards */}
// // //         {DUMMY_ACCOUNTS.map((account) => (
// // //           <View key={account.id} style={styles.accountCard}>
// // //             <View style={styles.accountHeader}>
// // //               <Text style={styles.bankName}>{account.bankName}</Text>
// // //               {account.isDefault && (
// // //                 <View style={styles.defaultBadge}>
// // //                   <Text style={styles.defaultBadgeText}>Default</Text>
// // //                 </View>
// // //               )}
// // //             </View>
// // //             <Text style={styles.accountName}>{account.accountName}</Text>
// // //             <View style={styles.accountFooter}>
// // //               <Text style={styles.accountNumber}>{account.accountNumber}</Text>
// // //               <TouchableOpacity onPress={() => handleEdit(account.id)}>
// // //                 <Text style={styles.editText}>Edit</Text>
// // //               </TouchableOpacity>
// // //             </View>
// // //           </View>
// // //         ))}

// // //         {/* Add Bank Account Button */}
// // //         <TouchableOpacity
// // //           style={styles.addAccountButton}
// // //           onPress={handleAddAccount}
// // //         >
// // //           <Text style={styles.addAccountText}>+ Add Bank Account</Text>
// // //         </TouchableOpacity>
// // //       </ScrollView>
// // //     </SafeAreaView>
// // //   );
// // // };

// // // const styles = StyleSheet.create({
// // //   container: {
// // //     flex: 1,
// // //     backgroundColor: "#f5f5f5",
// // //   },
// // //   header: {
// // //     flexDirection: "row",
// // //     justifyContent: "space-between",
// // //     alignItems: "center",
// // //     paddingHorizontal: 20,
// // //     paddingVertical: 16,
// // //     borderBottomWidth: 1,
// // //     borderBottomColor: "#e5e5e5",
// // //     backgroundColor: "#fff",
// // //   },
// // //   headerTitle: {
// // //     fontSize: 24,
// // //     fontWeight: "700",
// // //     color: "#1a1a2e",
// // //   },
// // //   closeButton: {
// // //     width: 40,
// // //     height: 40,
// // //     justifyContent: "center",
// // //     alignItems: "center",
// // //   },
// // //   content: {
// // //     flex: 1,
// // //     padding: 16,
// // //   },
// // //   accountCard: {
// // //     backgroundColor: "#fff",
// // //     borderRadius: 16,
// // //     borderWidth: 1,
// // //     borderColor: "#e5e5e5",
// // //     padding: 20,
// // //     marginBottom: 12,
// // //   },
// // //   accountHeader: {
// // //     flexDirection: "row",
// // //     justifyContent: "space-between",
// // //     alignItems: "center",
// // //     marginBottom: 4,
// // //   },
// // //   bankName: {
// // //     fontSize: 18,
// // //     fontWeight: "600",
// // //     color: "#1a1a2e",
// // //   },
// // //   defaultBadge: {
// // //     backgroundColor: "#fef3c7",
// // //     paddingHorizontal: 12,
// // //     paddingVertical: 4,
// // //     borderRadius: 12,
// // //   },
// // //   defaultBadgeText: {
// // //     fontSize: 12,
// // //     fontWeight: "500",
// // //     color: "#92400e",
// // //   },
// // //   accountName: {
// // //     fontSize: 14,
// // //     color: "#666",
// // //     marginBottom: 12,
// // //   },
// // //   accountFooter: {
// // //     flexDirection: "row",
// // //     justifyContent: "space-between",
// // //     alignItems: "center",
// // //   },
// // //   accountNumber: {
// // //     fontSize: 16,
// // //     fontWeight: "600",
// // //     color: "#1a1a2e",
// // //   },
// // //   editText: {
// // //     fontSize: 14,
// // //     fontWeight: "500",
// // //     color: "#1a1a2e",
// // //   },
// // //   addAccountButton: {
// // //     borderWidth: 2,
// // //     borderColor: "#e5e5e5",
// // //     borderStyle: "dashed",
// // //     borderRadius: 16,
// // //     paddingVertical: 20,
// // //     alignItems: "center",
// // //     marginTop: 4,
// // //   },
// // //   addAccountText: {
// // //     fontSize: 15,
// // //     fontWeight: "500",
// // //     color: "#666",
// // //   },
// // // });

// // // export default BankAccountsScreen;

// // import React from "react";
// // import {
// //   View,
// //   Text,
// //   StyleSheet,
// //   TouchableOpacity,
// //   ScrollView,
// //   Alert,
// //   ActivityIndicator,
// // } from "react-native";
// // import { SafeAreaView } from "react-native-safe-area-context";
// // import { Ionicons } from "@expo/vector-icons";
// // import { useFetchData_v2 } from "../../hooks/Requestv2";
// // // import { useFetchData_v2 } from "../../hooks/useApiHook"; // adjust path to your hook file

// // // useFetchData_v2
// // // ─── Types ────────────────────────────────────────────────────
// // interface VirtualAccount {
// //   _id: string;
// //   bankName: string;
// //   accountName: string;
// //   accountNumber: string;
// //   isDefault?: boolean;
// // }

// // interface BankAccountsScreenProps {
// //   onBack: () => void;
// //   onAddAccount?: () => void;
// // }

// // const BankAccountsScreen = ({
// //   onBack,
// //   onAddAccount,
// // }: BankAccountsScreenProps) => {
// //   // ─── Fetch Virtual Account ────────────────────────────────────
// //   const { data, isLoading, isError, error, refetch } = useFetchData_v2(
// //     "account/getVirtualAccount",
// //     "virtualAccount",
// //   );

// //   console.log({ tttt: data?.data?.data });

// //   // The API may return a single object or an array — handle both
// //   const accounts: VirtualAccount[] = data
// //     ? Array.isArray(data.data)
// //       ? data.data
// //       : [data.data]
// //     : [];

// //   const handleAddAccount = () => {
// //     if (onAddAccount) {
// //       onAddAccount();
// //     } else {
// //       Alert.alert("Add Account", "Add new bank account functionality");
// //     }
// //   };

// //   // ─── Loading State ────────────────────────────────────────────
// //   if (isLoading) {
// //     return (
// //       <SafeAreaView style={styles.container}>
// //         <View style={styles.header}>
// //           <Text style={styles.headerTitle}>Bank Accounts</Text>
// //           <TouchableOpacity style={styles.closeButton} onPress={onBack}>
// //             <Ionicons name="close" size={24} color="#1a1a2e" />
// //           </TouchableOpacity>
// //         </View>
// //         <View style={styles.centeredState}>
// //           <ActivityIndicator size="large" color="#1a1a2e" />
// //           <Text style={styles.stateText}>Loading accounts...</Text>
// //         </View>
// //       </SafeAreaView>
// //     );
// //   }

// //   // ─── Error State ──────────────────────────────────────────────
// //   if (isError) {
// //     return (
// //       <SafeAreaView style={styles.container}>
// //         <View style={styles.header}>
// //           <Text style={styles.headerTitle}>Bank Accounts</Text>
// //           <TouchableOpacity style={styles.closeButton} onPress={onBack}>
// //             <Ionicons name="close" size={24} color="#1a1a2e" />
// //           </TouchableOpacity>
// //         </View>
// //         <View style={styles.centeredState}>
// //           <Ionicons name="alert-circle-outline" size={48} color="#ef4444" />
// //           <Text style={styles.stateText}>
// //             {(error as any)?.message || "Failed to load accounts"}
// //           </Text>
// //           <TouchableOpacity
// //             style={styles.retryButton}
// //             onPress={() => refetch()}
// //           >
// //             <Text style={styles.retryText}>Try Again</Text>
// //           </TouchableOpacity>
// //         </View>
// //       </SafeAreaView>
// //     );
// //   }

// //   return (
// //     <SafeAreaView style={styles.container}>
// //       {/* Header */}
// //       <View style={styles.header}>
// //         <Text style={styles.headerTitle}>Bank Accounts</Text>
// //         <TouchableOpacity style={styles.closeButton} onPress={onBack}>
// //           <Ionicons name="close" size={24} color="#1a1a2e" />
// //         </TouchableOpacity>
// //       </View>

// //       <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
// //         {/* Empty State */}
// //         {accounts.length === 0 && (
// //           <View style={styles.emptyState}>
// //             <Ionicons name="wallet-outline" size={48} color="#ccc" />
// //             <Text style={styles.emptyTitle}>No accounts yet</Text>
// //             <Text style={styles.emptySubtitle}>
// //               Add a bank account to get started
// //             </Text>
// //           </View>
// //         )}

// //         {/* Bank Account Cards */}
// //         {accounts.map((account, index) => (
// //           <View key={account._id ?? index} style={styles.accountCard}>
// //             {/* Bank icon + name row */}
// //             <View style={styles.accountHeader}>
// //               <View style={styles.bankIconWrap}>
// //                 <Ionicons name="business-outline" size={18} color="#1a1a2e" />
// //               </View>
// //               <Text style={styles.bankName}>{account.bankName}</Text>
// //               {account.isDefault && (
// //                 <View style={styles.defaultBadge}>
// //                   <Text style={styles.defaultBadgeText}>Default</Text>
// //                 </View>
// //               )}
// //             </View>

// //             {/* Divider */}
// //             <View style={styles.divider} />

// //             {/* Account details */}
// //             <Text style={styles.accountName}>{account.accountName}</Text>
// //             <View style={styles.accountFooter}>
// //               <View style={styles.accountNumberRow}>
// //                 <Ionicons name="card-outline" size={14} color="#999" />
// //                 <Text style={styles.accountNumber}>
// //                   {account.accountNumber}
// //                 </Text>
// //               </View>
// //               <TouchableOpacity
// //                 style={styles.copyButton}
// //                 onPress={() =>
// //                   Alert.alert("Copied", `${account.accountNumber} copied`)
// //                 }
// //               >
// //                 <Ionicons name="copy-outline" size={14} color="#1a1a2e" />
// //                 <Text style={styles.copyText}>Copy</Text>
// //               </TouchableOpacity>
// //             </View>
// //           </View>
// //         ))}

// //         {/* Add Bank Account Button */}
// //         <TouchableOpacity
// //           style={styles.addAccountButton}
// //           onPress={handleAddAccount}
// //         >
// //           <Ionicons name="add-circle-outline" size={20} color="#666" />
// //           <Text style={styles.addAccountText}>Add Bank Account</Text>
// //         </TouchableOpacity>
// //       </ScrollView>
// //     </SafeAreaView>
// //   );
// // };

// // const styles = StyleSheet.create({
// //   container: {
// //     flex: 1,
// //     backgroundColor: "#f5f5f5",
// //   },
// //   header: {
// //     flexDirection: "row",
// //     justifyContent: "space-between",
// //     alignItems: "center",
// //     paddingHorizontal: 20,
// //     paddingVertical: 16,
// //     borderBottomWidth: 1,
// //     borderBottomColor: "#e5e5e5",
// //     backgroundColor: "#fff",
// //   },
// //   headerTitle: {
// //     fontSize: 24,
// //     fontWeight: "700",
// //     color: "#1a1a2e",
// //   },
// //   closeButton: {
// //     width: 40,
// //     height: 40,
// //     justifyContent: "center",
// //     alignItems: "center",
// //   },
// //   content: {
// //     flex: 1,
// //     padding: 16,
// //   },

// //   // ── Loading / Error / Empty ──
// //   centeredState: {
// //     flex: 1,
// //     justifyContent: "center",
// //     alignItems: "center",
// //     gap: 12,
// //     paddingHorizontal: 32,
// //   },
// //   stateText: {
// //     fontSize: 14,
// //     color: "#666",
// //     textAlign: "center",
// //   },
// //   retryButton: {
// //     marginTop: 4,
// //     backgroundColor: "#1a1a2e",
// //     paddingHorizontal: 24,
// //     paddingVertical: 12,
// //     borderRadius: 10,
// //   },
// //   retryText: {
// //     color: "#fff",
// //     fontWeight: "600",
// //     fontSize: 14,
// //   },
// //   emptyState: {
// //     alignItems: "center",
// //     paddingVertical: 48,
// //     gap: 8,
// //   },
// //   emptyTitle: {
// //     fontSize: 16,
// //     fontWeight: "600",
// //     color: "#333",
// //   },
// //   emptySubtitle: {
// //     fontSize: 13,
// //     color: "#999",
// //   },

// //   // ── Account Card ──
// //   accountCard: {
// //     backgroundColor: "#fff",
// //     borderRadius: 16,
// //     borderWidth: 1,
// //     borderColor: "#e5e5e5",
// //     padding: 20,
// //     marginBottom: 12,
// //   },
// //   accountHeader: {
// //     flexDirection: "row",
// //     alignItems: "center",
// //     gap: 8,
// //     marginBottom: 12,
// //   },
// //   bankIconWrap: {
// //     width: 32,
// //     height: 32,
// //     borderRadius: 8,
// //     backgroundColor: "#f0f4f8",
// //     justifyContent: "center",
// //     alignItems: "center",
// //   },
// //   bankName: {
// //     flex: 1,
// //     fontSize: 16,
// //     fontWeight: "600",
// //     color: "#1a1a2e",
// //   },
// //   defaultBadge: {
// //     backgroundColor: "#fef3c7",
// //     paddingHorizontal: 10,
// //     paddingVertical: 4,
// //     borderRadius: 12,
// //   },
// //   defaultBadgeText: {
// //     fontSize: 11,
// //     fontWeight: "600",
// //     color: "#92400e",
// //   },
// //   divider: {
// //     height: 1,
// //     backgroundColor: "#f0f0f0",
// //     marginBottom: 12,
// //   },
// //   accountName: {
// //     fontSize: 13,
// //     color: "#666",
// //     marginBottom: 10,
// //   },
// //   accountFooter: {
// //     flexDirection: "row",
// //     justifyContent: "space-between",
// //     alignItems: "center",
// //   },
// //   accountNumberRow: {
// //     flexDirection: "row",
// //     alignItems: "center",
// //     gap: 6,
// //   },
// //   accountNumber: {
// //     fontSize: 15,
// //     fontWeight: "600",
// //     color: "#1a1a2e",
// //     letterSpacing: 1,
// //   },
// //   copyButton: {
// //     flexDirection: "row",
// //     alignItems: "center",
// //     gap: 4,
// //     backgroundColor: "#f0f4f8",
// //     paddingHorizontal: 12,
// //     paddingVertical: 6,
// //     borderRadius: 8,
// //   },
// //   copyText: {
// //     fontSize: 12,
// //     fontWeight: "500",
// //     color: "#1a1a2e",
// //   },

// //   // ── Add Account ──
// //   addAccountButton: {
// //     flexDirection: "row",
// //     alignItems: "center",
// //     justifyContent: "center",
// //     gap: 8,
// //     borderWidth: 2,
// //     borderColor: "#e5e5e5",
// //     borderStyle: "dashed",
// //     borderRadius: 16,
// //     paddingVertical: 20,
// //     marginTop: 4,
// //   },
// //   addAccountText: {
// //     fontSize: 15,
// //     fontWeight: "500",
// //     color: "#666",
// //   },
// // });

// // export default BankAccountsScreen;

// import React from "react";
// import {
//   View,
//   Text,
//   StyleSheet,
//   TouchableOpacity,
//   ScrollView,
//   Alert,
//   ActivityIndicator,
// } from "react-native";
// import { SafeAreaView } from "react-native-safe-area-context";
// import { Ionicons } from "@expo/vector-icons";
// import { useFetchData_v2 } from "../../hooks/Requestv2";

// // ─── Types ────────────────────────────────────────────────────
// interface VirtualAccount {
//   alias: string;
//   bankName: string;
//   accountName: string;
//   accountNumber: string;
//   isDefault?: boolean;
// }

// interface BankAccountsScreenProps {
//   onBack: () => void;
//   onAddAccount?: () => void;
// }

// const BankAccountsScreen = ({
//   onBack,
//   onAddAccount,
// }: BankAccountsScreenProps) => {
//   // ─── Fetch Virtual Account ────────────────────────────────────
//   const { data, isLoading, isError, error, refetch } = useFetchData_v2(
//     "account/getVirtualAccount",
//     "virtualAccount",
//   );

//   // Response shape: data.data.data = { accountName, accountNumber, bankName, alias }
//   const virtualAccount: VirtualAccount | null = data?.data?.data ?? null;
//   const accounts: VirtualAccount[] = virtualAccount ? [virtualAccount] : [];

//   console.log({
//     oooo: accounts,
//   });

//   const handleAddAccount = () => {
//     if (onAddAccount) {
//       onAddAccount();
//     } else {
//       Alert.alert("Add Account", "Add new bank account functionality");
//     }
//   };

//   // ─── Loading State ────────────────────────────────────────────
//   if (isLoading) {
//     return (
//       <SafeAreaView style={styles.container}>
//         <View style={styles.header}>
//           <Text style={styles.headerTitle}>Bank Accounts</Text>
//           <TouchableOpacity style={styles.closeButton} onPress={onBack}>
//             <Ionicons name="close" size={24} color="#1a1a2e" />
//           </TouchableOpacity>
//         </View>
//         <View style={styles.centeredState}>
//           <ActivityIndicator size="large" color="#1a1a2e" />
//           <Text style={styles.stateText}>Loading accounts...</Text>
//         </View>
//       </SafeAreaView>
//     );
//   }

//   // ─── Error State ──────────────────────────────────────────────
//   if (isError) {
//     return (
//       <SafeAreaView style={styles.container}>
//         <View style={styles.header}>
//           <Text style={styles.headerTitle}>Bank Accounts</Text>
//           <TouchableOpacity style={styles.closeButton} onPress={onBack}>
//             <Ionicons name="close" size={24} color="#1a1a2e" />
//           </TouchableOpacity>
//         </View>
//         <View style={styles.centeredState}>
//           <Ionicons name="alert-circle-outline" size={48} color="#ef4444" />
//           <Text style={styles.stateText}>
//             {(error as any)?.message || "Failed to load accounts"}
//           </Text>
//           <TouchableOpacity
//             style={styles.retryButton}
//             onPress={() => refetch()}
//           >
//             <Text style={styles.retryText}>Try Again</Text>
//           </TouchableOpacity>
//         </View>
//       </SafeAreaView>
//     );
//   }

//   return (
//     <SafeAreaView style={styles.container}>
//       {/* Header */}
//       <View style={styles.header}>
//         <Text style={styles.headerTitle}>Bank Accounts</Text>
//         <TouchableOpacity style={styles.closeButton} onPress={onBack}>
//           <Ionicons name="close" size={24} color="#1a1a2e" />
//         </TouchableOpacity>
//       </View>

//       <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
//         {/* Empty State */}
//         {accounts.length === 0 && (
//           <View style={styles.emptyState}>
//             <Ionicons name="wallet-outline" size={48} color="#ccc" />
//             <Text style={styles.emptyTitle}>No accounts yet</Text>
//             <Text style={styles.emptySubtitle}>
//               Add a bank account to get started
//             </Text>
//           </View>
//         )}

//         {/* Bank Account Cards */}
//         {accounts.map((account, index) => (
//           <View key={account.alias ?? index} style={styles.accountCard}>
//             {/* Bank icon + name row */}
//             <View style={styles.accountHeader}>
//               <View style={styles.bankIconWrap}>
//                 <Ionicons name="business-outline" size={18} color="#1a1a2e" />
//               </View>
//               <Text style={styles.bankName}>{account.bankName}</Text>
//               {account.isDefault && (
//                 <View style={styles.defaultBadge}>
//                   <Text style={styles.defaultBadgeText}>Default</Text>
//                 </View>
//               )}
//             </View>

//             {/* Divider */}
//             <View style={styles.divider} />

//             {/* Account Name */}
//             <Text style={styles.accountName}>{account.accountName}</Text>

//             {/* Account Number + Copy */}
//             <View style={styles.accountFooter}>
//               <View style={styles.accountNumberRow}>
//                 <Ionicons name="card-outline" size={14} color="#999" />
//                 <Text style={styles.accountNumber}>
//                   {account.accountNumber}
//                 </Text>
//               </View>
//               <TouchableOpacity
//                 style={styles.copyButton}
//                 onPress={() =>
//                   Alert.alert("Copied", `${account.accountNumber} copied`)
//                 }
//               >
//                 <Ionicons name="copy-outline" size={14} color="#1a1a2e" />
//                 <Text style={styles.copyText}>Copy</Text>
//               </TouchableOpacity>
//             </View>
//           </View>
//         ))}

//         {/* Add Bank Account Button */}
//         <TouchableOpacity
//           style={styles.addAccountButton}
//           onPress={handleAddAccount}
//         >
//           <Ionicons name="add-circle-outline" size={20} color="#666" />
//           <Text style={styles.addAccountText}>Add Bank Account</Text>
//         </TouchableOpacity>
//       </ScrollView>
//     </SafeAreaView>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#f5f5f5",
//   },
//   header: {
//     flexDirection: "row",
//     justifyContent: "space-between",
//     alignItems: "center",
//     paddingHorizontal: 20,
//     paddingVertical: 16,
//     borderBottomWidth: 1,
//     borderBottomColor: "#e5e5e5",
//     backgroundColor: "#fff",
//   },
//   headerTitle: {
//     fontSize: 24,
//     fontWeight: "700",
//     color: "#1a1a2e",
//   },
//   closeButton: {
//     width: 40,
//     height: 40,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   content: {
//     flex: 1,
//     padding: 16,
//   },

//   // ── Loading / Error / Empty ──
//   centeredState: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     gap: 12,
//     paddingHorizontal: 32,
//   },
//   stateText: {
//     fontSize: 14,
//     color: "#666",
//     textAlign: "center",
//   },
//   retryButton: {
//     marginTop: 4,
//     backgroundColor: "#1a1a2e",
//     paddingHorizontal: 24,
//     paddingVertical: 12,
//     borderRadius: 10,
//   },
//   retryText: {
//     color: "#fff",
//     fontWeight: "600",
//     fontSize: 14,
//   },
//   emptyState: {
//     alignItems: "center",
//     paddingVertical: 48,
//     gap: 8,
//   },
//   emptyTitle: {
//     fontSize: 16,
//     fontWeight: "600",
//     color: "#333",
//   },
//   emptySubtitle: {
//     fontSize: 13,
//     color: "#999",
//   },

//   // ── Account Card ──
//   accountCard: {
//     backgroundColor: "#fff",
//     borderRadius: 16,
//     borderWidth: 1,
//     borderColor: "#e5e5e5",
//     padding: 20,
//     marginBottom: 12,
//   },
//   accountHeader: {
//     flexDirection: "row",
//     alignItems: "center",
//     gap: 8,
//     marginBottom: 12,
//   },
//   bankIconWrap: {
//     width: 32,
//     height: 32,
//     borderRadius: 8,
//     backgroundColor: "#f0f4f8",
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   bankName: {
//     flex: 1,
//     fontSize: 16,
//     fontWeight: "600",
//     color: "#1a1a2e",
//   },
//   defaultBadge: {
//     backgroundColor: "#fef3c7",
//     paddingHorizontal: 10,
//     paddingVertical: 4,
//     borderRadius: 12,
//   },
//   defaultBadgeText: {
//     fontSize: 11,
//     fontWeight: "600",
//     color: "#92400e",
//   },
//   divider: {
//     height: 1,
//     backgroundColor: "#f0f0f0",
//     marginBottom: 12,
//   },
//   accountName: {
//     fontSize: 13,
//     color: "#666",
//     marginBottom: 10,
//   },
//   accountFooter: {
//     flexDirection: "row",
//     justifyContent: "space-between",
//     alignItems: "center",
//   },
//   accountNumberRow: {
//     flexDirection: "row",
//     alignItems: "center",
//     gap: 6,
//   },
//   accountNumber: {
//     fontSize: 15,
//     fontWeight: "600",
//     color: "#1a1a2e",
//     letterSpacing: 1,
//   },
//   copyButton: {
//     flexDirection: "row",
//     alignItems: "center",
//     gap: 4,
//     backgroundColor: "#f0f4f8",
//     paddingHorizontal: 12,
//     paddingVertical: 6,
//     borderRadius: 8,
//   },
//   copyText: {
//     fontSize: 12,
//     fontWeight: "500",
//     color: "#1a1a2e",
//   },

//   // ── Add Account ──
//   addAccountButton: {
//     flexDirection: "row",
//     alignItems: "center",
//     justifyContent: "center",
//     gap: 8,
//     borderWidth: 2,
//     borderColor: "#e5e5e5",
//     borderStyle: "dashed",
//     borderRadius: 16,
//     paddingVertical: 20,
//     marginTop: 4,
//   },
//   addAccountText: {
//     fontSize: 15,
//     fontWeight: "500",
//     color: "#666",
//   },
// });

// export default BankAccountsScreen;

import React from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useFetchData_v2 } from "../../hooks/Requestv2";

interface BankAccountsScreenProps {
  onBack: () => void;
  onAddAccount?: () => void;
}

const BankAccountsScreen = ({
  onBack,
  onAddAccount,
}: BankAccountsScreenProps) => {
  const { data, isLoading, isError, error, refetch } = useFetchData_v2(
    "account/getVirtualAccount",
    "virtualAccount",
  );

  // Single account object from API
  const account = data?.data?.data;

  console.log({
    ggg: account,
  });

  const handleAddAccount = () => {
    if (onAddAccount) {
      onAddAccount();
    } else {
      Alert.alert("Add Account", "Add new bank account functionality");
    }
  };

  // ─── Loading ──────────────────────────────────────────────────
  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Bank Accounts</Text>
          <TouchableOpacity style={styles.closeButton} onPress={onBack}>
            <Ionicons name="close" size={24} color="#1a1a2e" />
          </TouchableOpacity>
        </View>
        <View style={styles.centeredState}>
          <ActivityIndicator size="large" color="#1a1a2e" />
          <Text style={styles.stateText}>Loading account...</Text>
        </View>
      </SafeAreaView>
    );
  }

  // ─── Error ────────────────────────────────────────────────────
  if (isError) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Bank Accounts</Text>
          <TouchableOpacity style={styles.closeButton} onPress={onBack}>
            <Ionicons name="close" size={24} color="#1a1a2e" />
          </TouchableOpacity>
        </View>
        <View style={styles.centeredState}>
          <Ionicons name="alert-circle-outline" size={48} color="#ef4444" />
          <Text style={styles.stateText}>
            {(error as any)?.message || "Failed to load account"}
          </Text>
          <TouchableOpacity
            style={styles.retryButton}
            onPress={() => refetch()}
          >
            <Text style={styles.retryText}>Try Again</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Bank Accounts</Text>
        <TouchableOpacity style={styles.closeButton} onPress={onBack}>
          <Ionicons name="close" size={24} color="#1a1a2e" />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
        {/* No account returned */}
        {!account ? (
          <View style={styles.emptyState}>
            <Ionicons name="wallet-outline" size={48} color="#ccc" />
            <Text style={styles.emptyTitle}>No account yet</Text>
            <Text style={styles.emptySubtitle}>
              Add a bank account to get started
            </Text>
          </View>
        ) : (
          /* Single Account Card */
          <View style={styles.accountCard}>
            {/* Bank icon + name */}
            <View style={styles.accountHeader}>
              <View style={styles.bankIconWrap}>
                <Ionicons name="business-outline" size={18} color="#1a1a2e" />
              </View>
              <Text style={styles.bankName}>{account.data.bankName}</Text>
            </View>

            <View style={styles.divider} />

            {/* Account Name */}
            <Text style={styles.accountName}>{account.data.accountName}</Text>

            {/* Account Number + Copy */}
            <View style={styles.accountFooter}>
              <View style={styles.accountNumberRow}>
                <Ionicons name="card-outline" size={14} color="#999" />
                <Text style={styles.accountNumber}>
                  {account.data.accountNumber}
                </Text>
              </View>
              <TouchableOpacity
                style={styles.copyButton}
                onPress={() =>
                  Alert.alert("Copied", `${account.data.accountNumber} copied`)
                }
              >
                <Ionicons name="copy-outline" size={14} color="#1a1a2e" />
                <Text style={styles.copyText}>Copy</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Add Bank Account Button */}
        <TouchableOpacity
          style={styles.addAccountButton}
          onPress={handleAddAccount}
        >
          <Ionicons name="add-circle-outline" size={20} color="#666" />
          <Text style={styles.addAccountText}>Add Bank Account</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e5e5",
    backgroundColor: "#fff",
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: "#1a1a2e",
  },
  closeButton: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  content: {
    flex: 1,
    padding: 16,
  },
  centeredState: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    gap: 12,
    paddingHorizontal: 32,
  },
  stateText: {
    fontSize: 14,
    color: "#666",
    textAlign: "center",
  },
  retryButton: {
    marginTop: 4,
    backgroundColor: "#1a1a2e",
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 10,
  },
  retryText: {
    color: "#fff",
    fontWeight: "600",
    fontSize: 14,
  },
  emptyState: {
    alignItems: "center",
    paddingVertical: 48,
    gap: 8,
  },
  emptyTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#333",
  },
  emptySubtitle: {
    fontSize: 13,
    color: "#999",
  },
  accountCard: {
    backgroundColor: "#fff",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    padding: 20,
    marginBottom: 12,
  },
  accountHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginBottom: 12,
  },
  bankIconWrap: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: "#f0f4f8",
    justifyContent: "center",
    alignItems: "center",
  },
  bankName: {
    flex: 1,
    fontSize: 16,
    fontWeight: "600",
    color: "#1a1a2e",
  },
  divider: {
    height: 1,
    backgroundColor: "#f0f0f0",
    marginBottom: 12,
  },
  accountName: {
    fontSize: 13,
    color: "#666",
    marginBottom: 10,
  },
  accountFooter: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  accountNumberRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  accountNumber: {
    fontSize: 15,
    fontWeight: "600",
    color: "#1a1a2e",
    letterSpacing: 1,
  },
  copyButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: "#f0f4f8",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  copyText: {
    fontSize: 12,
    fontWeight: "500",
    color: "#1a1a2e",
  },
  addAccountButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    borderWidth: 2,
    borderColor: "#e5e5e5",
    borderStyle: "dashed",
    borderRadius: 16,
    paddingVertical: 20,
    marginTop: 4,
  },
  addAccountText: {
    fontSize: 15,
    fontWeight: "500",
    color: "#666",
  },
});

export default BankAccountsScreen;
