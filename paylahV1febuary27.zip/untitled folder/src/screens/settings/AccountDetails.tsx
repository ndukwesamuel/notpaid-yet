// // // // import React from "react";
// // // // import {
// // // //   View,
// // // //   Text,
// // // //   StyleSheet,
// // // //   TouchableOpacity,
// // // //   ScrollView,
// // // //   Alert,
// // // //   ActivityIndicator,
// // // // } from "react-native";
// // // // import { SafeAreaView } from "react-native-safe-area-context";
// // // // import { Ionicons } from "@expo/vector-icons";
// // // // import { useFetchData_v2 } from "../../hooks/Requestv2";
// // // // import { useNavigation } from "@react-navigation/native";

// // // // interface BankAccountsScreenProps {
// // // //   onBack: () => void;
// // // //   onAddAccount?: () => void;
// // // // }

// // // // const AccountDetails = () => {
// // // //   const navigation = useNavigation();
// // // //   const { data, isLoading, isError, error, refetch } = useFetchData_v2(
// // // //     "account/getVirtualAccount",
// // // //     "virtualAccount",
// // // //   );

// // // //   // Single account object from API
// // // //   const account = data?.data?.data;

// // // //   console.log({
// // // //     ggg: account,
// // // //   });

// // // //   const handleAddAccount = () => {
// // // //     if (onAddAccount) {
// // // //       onAddAccount();
// // // //     } else {
// // // //       Alert.alert("Add Account", "Add new bank account functionality");
// // // //     }
// // // //   };

// // // //   // ─── Loading ──────────────────────────────────────────────────
// // // //   if (isLoading) {
// // // //     return (
// // // //       <SafeAreaView style={styles.container}>
// // // //         <View style={styles.header}>
// // // //           <Text style={styles.headerTitle}>Bank Accounts</Text>
// // // //           <TouchableOpacity style={styles.closeButton} onPress={onBack}>
// // // //             <Ionicons name="close" size={24} color="#1a1a2e" />
// // // //           </TouchableOpacity>
// // // //         </View>
// // // //         <View style={styles.centeredState}>
// // // //           <ActivityIndicator size="large" color="#1a1a2e" />
// // // //           <Text style={styles.stateText}>Loading account...</Text>
// // // //         </View>
// // // //       </SafeAreaView>
// // // //     );
// // // //   }

// // // //   // ─── Error ────────────────────────────────────────────────────
// // // //   if (isError) {
// // // //     return (
// // // //       <SafeAreaView style={styles.container}>
// // // //         <View style={styles.header}>
// // // //           <Text style={styles.headerTitle}>Bank Accounts</Text>
// // // //           <TouchableOpacity
// // // //             style={styles.closeButton}
// // // //             onPress={() => navigation.goBack()}
// // // //           >
// // // //             <Ionicons name="close" size={24} color="#1a1a2e" />
// // // //           </TouchableOpacity>
// // // //         </View>
// // // //         <View style={styles.centeredState}>
// // // //           <Ionicons name="alert-circle-outline" size={48} color="#ef4444" />
// // // //           <Text style={styles.stateText}>
// // // //             {(error as any)?.message || "Failed to load account"}
// // // //           </Text>
// // // //           <TouchableOpacity
// // // //             style={styles.retryButton}
// // // //             onPress={() => refetch()}
// // // //           >
// // // //             <Text style={styles.retryText}>Try Again</Text>
// // // //           </TouchableOpacity>
// // // //         </View>
// // // //       </SafeAreaView>
// // // //     );
// // // //   }

// // // //   return (
// // // //     <SafeAreaView style={styles.container}>
// // // //       {/* Header */}
// // // //       <View style={styles.header}>
// // // //         <Text style={styles.headerTitle}>Bank Accounts</Text>
// // // //         <TouchableOpacity
// // // //           style={styles.closeButton}
// // // //           onPress={() => navigation.goBack()}
// // // //         >
// // // //           <Ionicons name="close" size={24} color="#1a1a2e" />
// // // //         </TouchableOpacity>
// // // //       </View>

// // // //       <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
// // // //         {/* No account returned */}
// // // //         {!account ? (
// // // //           <View style={styles.emptyState}>
// // // //             <Ionicons name="wallet-outline" size={48} color="#ccc" />
// // // //             <Text style={styles.emptyTitle}>No account yet</Text>
// // // //             <Text style={styles.emptySubtitle}>
// // // //               Add a bank account to get started
// // // //             </Text>
// // // //           </View>
// // // //         ) : (
// // // //           /* Single Account Card */
// // // //           <View style={styles.accountCard}>
// // // //             {/* Bank icon + name */}
// // // //             <View style={styles.accountHeader}>
// // // //               <View style={styles.bankIconWrap}>
// // // //                 <Ionicons name="business-outline" size={18} color="#1a1a2e" />
// // // //               </View>
// // // //               <Text style={styles.bankName}>{account.data.bankName}</Text>
// // // //             </View>

// // // //             <View style={styles.divider} />

// // // //             {/* Account Name */}
// // // //             <Text style={styles.accountName}>{account.data.accountName}</Text>

// // // //             {/* Account Number + Copy */}
// // // //             <View style={styles.accountFooter}>
// // // //               <View style={styles.accountNumberRow}>
// // // //                 <Ionicons name="card-outline" size={14} color="#999" />
// // // //                 <Text style={styles.accountNumber}>
// // // //                   {account.data.accountNumber}
// // // //                 </Text>
// // // //               </View>
// // // //               <TouchableOpacity
// // // //                 style={styles.copyButton}
// // // //                 onPress={() =>
// // // //                   Alert.alert("Copied", `${account.data.accountNumber} copied`)
// // // //                 }
// // // //               >
// // // //                 <Ionicons name="copy-outline" size={14} color="#1a1a2e" />
// // // //                 <Text style={styles.copyText}>Copy</Text>
// // // //               </TouchableOpacity>
// // // //             </View>
// // // //           </View>
// // // //         )}

// // // //         {/* Add Bank Account Button */}
// // // //         <TouchableOpacity
// // // //           style={styles.addAccountButton}
// // // //           onPress={handleAddAccount}
// // // //         >
// // // //           <Ionicons name="add-circle-outline" size={20} color="#666" />
// // // //           <Text style={styles.addAccountText}>Add Bank Account</Text>
// // // //         </TouchableOpacity>
// // // //       </ScrollView>
// // // //     </SafeAreaView>
// // // //   );
// // // // };

// // // // const styles = StyleSheet.create({
// // // //   container: {
// // // //     flex: 1,
// // // //     backgroundColor: "#f5f5f5",
// // // //   },
// // // //   header: {
// // // //     flexDirection: "row",
// // // //     justifyContent: "space-between",
// // // //     alignItems: "center",
// // // //     paddingHorizontal: 20,
// // // //     paddingVertical: 16,
// // // //     borderBottomWidth: 1,
// // // //     borderBottomColor: "#e5e5e5",
// // // //     backgroundColor: "#fff",
// // // //   },
// // // //   headerTitle: {
// // // //     fontSize: 24,
// // // //     fontWeight: "700",
// // // //     color: "#1a1a2e",
// // // //   },
// // // //   closeButton: {
// // // //     width: 40,
// // // //     height: 40,
// // // //     justifyContent: "center",
// // // //     alignItems: "center",
// // // //   },
// // // //   content: {
// // // //     flex: 1,
// // // //     padding: 16,
// // // //   },
// // // //   centeredState: {
// // // //     flex: 1,
// // // //     justifyContent: "center",
// // // //     alignItems: "center",
// // // //     gap: 12,
// // // //     paddingHorizontal: 32,
// // // //   },
// // // //   stateText: {
// // // //     fontSize: 14,
// // // //     color: "#666",
// // // //     textAlign: "center",
// // // //   },
// // // //   retryButton: {
// // // //     marginTop: 4,
// // // //     backgroundColor: "#1a1a2e",
// // // //     paddingHorizontal: 24,
// // // //     paddingVertical: 12,
// // // //     borderRadius: 10,
// // // //   },
// // // //   retryText: {
// // // //     color: "#fff",
// // // //     fontWeight: "600",
// // // //     fontSize: 14,
// // // //   },
// // // //   emptyState: {
// // // //     alignItems: "center",
// // // //     paddingVertical: 48,
// // // //     gap: 8,
// // // //   },
// // // //   emptyTitle: {
// // // //     fontSize: 16,
// // // //     fontWeight: "600",
// // // //     color: "#333",
// // // //   },
// // // //   emptySubtitle: {
// // // //     fontSize: 13,
// // // //     color: "#999",
// // // //   },
// // // //   accountCard: {
// // // //     backgroundColor: "#fff",
// // // //     borderRadius: 16,
// // // //     borderWidth: 1,
// // // //     borderColor: "#e5e5e5",
// // // //     padding: 20,
// // // //     marginBottom: 12,
// // // //   },
// // // //   accountHeader: {
// // // //     flexDirection: "row",
// // // //     alignItems: "center",
// // // //     gap: 8,
// // // //     marginBottom: 12,
// // // //   },
// // // //   bankIconWrap: {
// // // //     width: 32,
// // // //     height: 32,
// // // //     borderRadius: 8,
// // // //     backgroundColor: "#f0f4f8",
// // // //     justifyContent: "center",
// // // //     alignItems: "center",
// // // //   },
// // // //   bankName: {
// // // //     flex: 1,
// // // //     fontSize: 16,
// // // //     fontWeight: "600",
// // // //     color: "#1a1a2e",
// // // //   },
// // // //   divider: {
// // // //     height: 1,
// // // //     backgroundColor: "#f0f0f0",
// // // //     marginBottom: 12,
// // // //   },
// // // //   accountName: {
// // // //     fontSize: 13,
// // // //     color: "#666",
// // // //     marginBottom: 10,
// // // //   },
// // // //   accountFooter: {
// // // //     flexDirection: "row",
// // // //     justifyContent: "space-between",
// // // //     alignItems: "center",
// // // //   },
// // // //   accountNumberRow: {
// // // //     flexDirection: "row",
// // // //     alignItems: "center",
// // // //     gap: 6,
// // // //   },
// // // //   accountNumber: {
// // // //     fontSize: 15,
// // // //     fontWeight: "600",
// // // //     color: "#1a1a2e",
// // // //     letterSpacing: 1,
// // // //   },
// // // //   copyButton: {
// // // //     flexDirection: "row",
// // // //     alignItems: "center",
// // // //     gap: 4,
// // // //     backgroundColor: "#f0f4f8",
// // // //     paddingHorizontal: 12,
// // // //     paddingVertical: 6,
// // // //     borderRadius: 8,
// // // //   },
// // // //   copyText: {
// // // //     fontSize: 12,
// // // //     fontWeight: "500",
// // // //     color: "#1a1a2e",
// // // //   },
// // // //   addAccountButton: {
// // // //     flexDirection: "row",
// // // //     alignItems: "center",
// // // //     justifyContent: "center",
// // // //     gap: 8,
// // // //     borderWidth: 2,
// // // //     borderColor: "#e5e5e5",
// // // //     borderStyle: "dashed",
// // // //     borderRadius: 16,
// // // //     paddingVertical: 20,
// // // //     marginTop: 4,
// // // //   },
// // // //   addAccountText: {
// // // //     fontSize: 15,
// // // //     fontWeight: "500",
// // // //     color: "#666",
// // // //   },
// // // // });

// // // // export default AccountDetails;

// // // import React from "react";
// // // import {
// // //   View,
// // //   Text,
// // //   StyleSheet,
// // //   TouchableOpacity,
// // //   ScrollView,
// // //   Alert,
// // //   ActivityIndicator,
// // // } from "react-native";
// // // import { SafeAreaView } from "react-native-safe-area-context";
// // // import { Ionicons } from "@expo/vector-icons";
// // // import { useFetchData_v2 } from "../../hooks/Requestv2";
// // // import { useNavigation } from "@react-navigation/native";

// // // const AccountDetails = () => {
// // //   const navigation = useNavigation();
// // //   const { data, isLoading, isError, error, refetch } = useFetchData_v2(
// // //     "account/getVirtualAccount",
// // //     "virtualAccount",
// // //   );

// // //   const account = data?.data?.data;

// // //   // ─── Loading ──────────────────────────────────────────────────
// // //   if (isLoading) {
// // //     return (
// // //       <SafeAreaView style={styles.container}>
// // //         <View style={styles.header}>
// // //           <Text style={styles.headerTitle}>Bank Accounts</Text>
// // //           <TouchableOpacity
// // //             style={styles.closeButton}
// // //             onPress={() => navigation.goBack()}
// // //           >
// // //             <Ionicons name="close" size={24} color="#1a1a2e" />
// // //           </TouchableOpacity>
// // //         </View>
// // //         <View style={styles.centeredState}>
// // //           <ActivityIndicator size="large" color="#1a1a2e" />
// // //           <Text style={styles.stateText}>Loading account...</Text>
// // //         </View>
// // //       </SafeAreaView>
// // //     );
// // //   }

// // //   // ─── Error ────────────────────────────────────────────────────
// // //   if (isError) {
// // //     return (
// // //       <SafeAreaView style={styles.container}>
// // //         <View style={styles.header}>
// // //           <Text style={styles.headerTitle}>Bank Accounts</Text>
// // //           <TouchableOpacity
// // //             style={styles.closeButton}
// // //             onPress={() => navigation.goBack()}
// // //           >
// // //             <Ionicons name="close" size={24} color="#1a1a2e" />
// // //           </TouchableOpacity>
// // //         </View>
// // //         <View style={styles.centeredState}>
// // //           <Ionicons name="alert-circle-outline" size={48} color="#ef4444" />
// // //           <Text style={styles.stateText}>
// // //             {(error as any)?.message || "Failed to load account"}
// // //           </Text>
// // //           <TouchableOpacity
// // //             style={styles.retryButton}
// // //             onPress={() => refetch()}
// // //           >
// // //             <Text style={styles.retryText}>Try Again</Text>
// // //           </TouchableOpacity>
// // //         </View>
// // //       </SafeAreaView>
// // //     );
// // //   }

// // //   return (
// // //     <SafeAreaView style={styles.container}>
// // //       {/* Header */}
// // //       <View style={styles.header}>
// // //         <Text style={styles.headerTitle}>Bank Accounts</Text>
// // //         <TouchableOpacity
// // //           style={styles.closeButton}
// // //           onPress={() => navigation.goBack()}
// // //         >
// // //           <Ionicons name="close" size={24} color="#1a1a2e" />
// // //         </TouchableOpacity>
// // //       </View>

// // //       <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
// // //         {!account ? (
// // //           <View style={styles.emptyState}>
// // //             <Ionicons name="wallet-outline" size={48} color="#ccc" />
// // //             <Text style={styles.emptyTitle}>No account yet</Text>
// // //             <Text style={styles.emptySubtitle}>
// // //               Add a bank account to get started
// // //             </Text>
// // //           </View>
// // //         ) : (
// // //           <View style={styles.accountCard}>
// // //             <View style={styles.accountHeader}>
// // //               <View style={styles.bankIconWrap}>
// // //                 <Ionicons name="business-outline" size={18} color="#1a1a2e" />
// // //               </View>
// // //               <Text style={styles.bankName}>{account.data.bankName}</Text>
// // //             </View>

// // //             <View style={styles.divider} />

// // //             <Text style={styles.accountName}>{account.data.accountName}</Text>

// // //             <View style={styles.accountFooter}>
// // //               <View style={styles.accountNumberRow}>
// // //                 <Ionicons name="card-outline" size={14} color="#999" />
// // //                 <Text style={styles.accountNumber}>
// // //                   {account.data.accountNumber}
// // //                 </Text>
// // //               </View>
// // //               <TouchableOpacity
// // //                 style={styles.copyButton}
// // //                 onPress={() =>
// // //                   Alert.alert("Copied", `${account.data.accountNumber} copied`)
// // //                 }
// // //               >
// // //                 <Ionicons name="copy-outline" size={14} color="#1a1a2e" />
// // //                 <Text style={styles.copyText}>Copy</Text>
// // //               </TouchableOpacity>
// // //             </View>
// // //           </View>
// // //         )}

// // //         <TouchableOpacity
// // //           style={styles.addAccountButton}
// // //           onPress={() =>
// // //             Alert.alert("Add Account", "Add new bank account functionality")
// // //           }
// // //         >
// // //           <Ionicons name="add-circle-outline" size={20} color="#666" />
// // //           <Text style={styles.addAccountText}>Add Bank Account</Text>
// // //         </TouchableOpacity>
// // //       </ScrollView>
// // //     </SafeAreaView>
// // //   );
// // // };

// // // const styles = StyleSheet.create({
// // //   container: {
// // //     flex: 1,
// // //     backgroundColor: "#f5f5f5",
// // //   },
// // //   header: {
// // //     flexDirection: "row",
// // //     justifyContent: "space-between",
// // //     alignItems: "center",
// // //     paddingHorizontal: 20,
// // //     paddingVertical: 16,
// // //     borderBottomWidth: 1,
// // //     borderBottomColor: "#e5e5e5",
// // //     backgroundColor: "#fff",
// // //   },
// // //   headerTitle: {
// // //     fontSize: 24,
// // //     fontWeight: "700",
// // //     color: "#1a1a2e",
// // //   },
// // //   closeButton: {
// // //     width: 40,
// // //     height: 40,
// // //     justifyContent: "center",
// // //     alignItems: "center",
// // //   },
// // //   content: {
// // //     flex: 1,
// // //     padding: 16,
// // //   },
// // //   centeredState: {
// // //     flex: 1,
// // //     justifyContent: "center",
// // //     alignItems: "center",
// // //     gap: 12,
// // //     paddingHorizontal: 32,
// // //   },
// // //   stateText: {
// // //     fontSize: 14,
// // //     color: "#666",
// // //     textAlign: "center",
// // //   },
// // //   retryButton: {
// // //     marginTop: 4,
// // //     backgroundColor: "#1a1a2e",
// // //     paddingHorizontal: 24,
// // //     paddingVertical: 12,
// // //     borderRadius: 10,
// // //   },
// // //   retryText: {
// // //     color: "#fff",
// // //     fontWeight: "600",
// // //     fontSize: 14,
// // //   },
// // //   emptyState: {
// // //     alignItems: "center",
// // //     paddingVertical: 48,
// // //     gap: 8,
// // //   },
// // //   emptyTitle: {
// // //     fontSize: 16,
// // //     fontWeight: "600",
// // //     color: "#333",
// // //   },
// // //   emptySubtitle: {
// // //     fontSize: 13,
// // //     color: "#999",
// // //   },
// // //   accountCard: {
// // //     backgroundColor: "#fff",
// // //     borderRadius: 16,
// // //     borderWidth: 1,
// // //     borderColor: "#e5e5e5",
// // //     padding: 20,
// // //     marginBottom: 12,
// // //   },
// // //   accountHeader: {
// // //     flexDirection: "row",
// // //     alignItems: "center",
// // //     gap: 8,
// // //     marginBottom: 12,
// // //   },
// // //   bankIconWrap: {
// // //     width: 32,
// // //     height: 32,
// // //     borderRadius: 8,
// // //     backgroundColor: "#f0f4f8",
// // //     justifyContent: "center",
// // //     alignItems: "center",
// // //   },
// // //   bankName: {
// // //     flex: 1,
// // //     fontSize: 16,
// // //     fontWeight: "600",
// // //     color: "#1a1a2e",
// // //   },
// // //   divider: {
// // //     height: 1,
// // //     backgroundColor: "#f0f0f0",
// // //     marginBottom: 12,
// // //   },
// // //   accountName: {
// // //     fontSize: 13,
// // //     color: "#666",
// // //     marginBottom: 10,
// // //   },
// // //   accountFooter: {
// // //     flexDirection: "row",
// // //     justifyContent: "space-between",
// // //     alignItems: "center",
// // //   },
// // //   accountNumberRow: {
// // //     flexDirection: "row",
// // //     alignItems: "center",
// // //     gap: 6,
// // //   },
// // //   accountNumber: {
// // //     fontSize: 15,
// // //     fontWeight: "600",
// // //     color: "#1a1a2e",
// // //     letterSpacing: 1,
// // //   },
// // //   copyButton: {
// // //     flexDirection: "row",
// // //     alignItems: "center",
// // //     gap: 4,
// // //     backgroundColor: "#f0f4f8",
// // //     paddingHorizontal: 12,
// // //     paddingVertical: 6,
// // //     borderRadius: 8,
// // //   },
// // //   copyText: {
// // //     fontSize: 12,
// // //     fontWeight: "500",
// // //     color: "#1a1a2e",
// // //   },
// // //   addAccountButton: {
// // //     flexDirection: "row",
// // //     alignItems: "center",
// // //     justifyContent: "center",
// // //     gap: 8,
// // //     borderWidth: 2,
// // //     borderColor: "#e5e5e5",
// // //     borderStyle: "dashed",
// // //     borderRadius: 16,
// // //     paddingVertical: 20,
// // //     marginTop: 4,
// // //   },
// // //   addAccountText: {
// // //     fontSize: 15,
// // //     fontWeight: "500",
// // //     color: "#666",
// // //   },
// // // });

// // // export default AccountDetails;

// // import React from "react";
// // import {
// //   View,
// //   Text,
// //   StyleSheet,
// //   TouchableOpacity,
// //   ScrollView,
// //   Alert,
// //   ActivityIndicator,
// // } from "react-native";
// // import { SafeAreaView } from "react-native-safe-area-context";
// // import { Ionicons } from "@expo/vector-icons";
// // import { useFetchData_v2, useMutateData_v2 } from "../../hooks/Requestv2";
// // import { useNavigation } from "@react-navigation/native";

// // const AccountDetails = () => {
// //   const navigation = useNavigation();

// //   const { data, isLoading, isError, error, refetch } = useFetchData_v2(
// //     "account/getVirtualAccount",
// //     "virtualAccount",
// //   );

// //   const { mutate: createVirtualAccount, isPending: isCreating } =
// //     useMutateData_v2(
// //       "account/createVirtualAccount",
// //       "POST",
// //       "virtualAccount", // auto-refetches getVirtualAccount on success
// //       {
// //         onSuccess: () => {
// //           Alert.alert("Success", "Virtual account created successfully!");
// //         },
// //         onError: (error: any) => {
// //           const msg =
// //             error?.data?.message || "Failed to create virtual account";
// //           Alert.alert("Error", msg);
// //         },
// //       },
// //     );

// //   const account = data?.data?.data;

// //   // ─── Loading ──────────────────────────────────────────────────
// //   if (isLoading) {
// //     return (
// //       <SafeAreaView style={styles.container}>
// //         <View style={styles.header}>
// //           <Text style={styles.headerTitle}>Bank Accounts</Text>
// //           <TouchableOpacity
// //             style={styles.closeButton}
// //             onPress={() => navigation.goBack()}
// //           >
// //             <Ionicons name="close" size={24} color="#1a1a2e" />
// //           </TouchableOpacity>
// //         </View>
// //         <View style={styles.centeredState}>
// //           <ActivityIndicator size="large" color="#1a1a2e" />
// //           <Text style={styles.stateText}>Loading account...</Text>
// //         </View>
// //       </SafeAreaView>
// //     );
// //   }

// //   // ─── Error ────────────────────────────────────────────────────
// //   if (isError) {
// //     return (
// //       <SafeAreaView style={styles.container}>
// //         <View style={styles.header}>
// //           <Text style={styles.headerTitle}>Bank Accounts</Text>
// //           <TouchableOpacity
// //             style={styles.closeButton}
// //             onPress={() => navigation.goBack()}
// //           >
// //             <Ionicons name="close" size={24} color="#1a1a2e" />
// //           </TouchableOpacity>
// //         </View>
// //         <View style={styles.centeredState}>
// //           <Ionicons name="alert-circle-outline" size={48} color="#ef4444" />
// //           <Text style={styles.stateText}>
// //             {(error as any)?.message || "Failed to load account"}
// //           </Text>
// //           <TouchableOpacity
// //             style={styles.retryButton}
// //             onPress={() => refetch()}
// //           >
// //             <Text style={styles.retryText}>Try Again</Text>
// //           </TouchableOpacity>
// //         </View>
// //       </SafeAreaView>
// //     );
// //   }

// //   return (
// //     <SafeAreaView style={styles.container}>
// //       {/* Header */}
// //       <View style={styles.header}>
// //         <Text style={styles.headerTitle}>Bank Accounts</Text>
// //         <TouchableOpacity
// //           style={styles.closeButton}
// //           onPress={() => navigation.goBack()}
// //         >
// //           <Ionicons name="close" size={24} color="#1a1a2e" />
// //         </TouchableOpacity>
// //       </View>

// //       <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
// //         <View style={styles.accountCard}>
// //           <View style={styles.accountHeader}>
// //             <View style={styles.bankIconWrap}>
// //               <Ionicons name="business-outline" size={18} color="#1a1a2e" />
// //             </View>
// //             <Text style={styles.bankName}>{account.data.bankName}</Text>
// //           </View>

// //           <View style={styles.divider} />

// //           <Text style={styles.accountName}>{account.data.accountName}</Text>

// //           <View style={styles.accountFooter}>
// //             <View style={styles.accountNumberRow}>
// //               <Ionicons name="card-outline" size={14} color="#999" />
// //               <Text style={styles.accountNumber}>
// //                 {account.data.accountNumber}
// //               </Text>
// //             </View>
// //             <TouchableOpacity
// //               style={styles.copyButton}
// //               onPress={() =>
// //                 Alert.alert("Copied", `${account.data.accountNumber} copied`)
// //               }
// //             >
// //               <Ionicons name="copy-outline" size={14} color="#1a1a2e" />
// //               <Text style={styles.copyText}>Copy</Text>
// //             </TouchableOpacity>
// //           </View>
// //         </View>
// //         <View style={styles.emptyState}>
// //           <View style={styles.emptyIconWrap}>
// //             <Ionicons name="wallet-outline" size={40} color="#1a1a2e" />
// //           </View>
// //           <Text style={styles.emptyTitle}>No bank account yet</Text>
// //           <Text style={styles.emptySubtitle}>
// //             Create a free virtual bank account to start sending and receiving
// //             money instantly.
// //           </Text>
// //           <TouchableOpacity
// //             style={[styles.createButton, isCreating && styles.buttonDisabled]}
// //             onPress={() => createVirtualAccount({})}
// //             disabled={isCreating}
// //           >
// //             {isCreating ? (
// //               <ActivityIndicator color="#fff" />
// //             ) : (
// //               <>
// //                 <Ionicons name="add-circle-outline" size={20} color="#fff" />
// //                 <Text style={styles.createButtonText}>
// //                   Create Virtual Account
// //                 </Text>
// //               </>
// //             )}
// //           </TouchableOpacity>
// //         </View>
// //       </ScrollView>
// //     </SafeAreaView>
// //   );
// // };

// // const styles = StyleSheet.create({
// //   container: {
// //     flex: 1,
// //     backgroundColor: "#f5f5f5",
// //   },
// //   header: {
// //     flexDirection: "row",
// //     justifyContent: "space-between",
// //     alignItems: "center",
// //     paddingHorizontal: 20,
// //     paddingVertical: 16,
// //     borderBottomWidth: 1,
// //     borderBottomColor: "#e5e5e5",
// //     backgroundColor: "#fff",
// //   },
// //   headerTitle: {
// //     fontSize: 24,
// //     fontWeight: "700",
// //     color: "#1a1a2e",
// //   },
// //   closeButton: {
// //     width: 40,
// //     height: 40,
// //     justifyContent: "center",
// //     alignItems: "center",
// //   },
// //   content: {
// //     flex: 1,
// //     padding: 16,
// //   },
// //   centeredState: {
// //     flex: 1,
// //     justifyContent: "center",
// //     alignItems: "center",
// //     gap: 12,
// //     paddingHorizontal: 32,
// //   },
// //   stateText: {
// //     fontSize: 14,
// //     color: "#666",
// //     textAlign: "center",
// //   },
// //   retryButton: {
// //     marginTop: 4,
// //     backgroundColor: "#1a1a2e",
// //     paddingHorizontal: 24,
// //     paddingVertical: 12,
// //     borderRadius: 10,
// //   },
// //   retryText: {
// //     color: "#fff",
// //     fontWeight: "600",
// //     fontSize: 14,
// //   },
// //   // ─── Empty / Create state ─────────────────────────────────────
// //   emptyState: {
// //     alignItems: "center",
// //     paddingVertical: 60,
// //     paddingHorizontal: 24,
// //     gap: 12,
// //   },
// //   emptyIconWrap: {
// //     width: 80,
// //     height: 80,
// //     borderRadius: 40,
// //     backgroundColor: "#f0f4f8",
// //     justifyContent: "center",
// //     alignItems: "center",
// //     marginBottom: 8,
// //   },
// //   emptyTitle: {
// //     fontSize: 18,
// //     fontWeight: "700",
// //     color: "#1a1a2e",
// //   },
// //   emptySubtitle: {
// //     fontSize: 14,
// //     color: "#666",
// //     textAlign: "center",
// //     lineHeight: 20,
// //     marginBottom: 8,
// //   },
// //   createButton: {
// //     flexDirection: "row",
// //     alignItems: "center",
// //     gap: 8,
// //     backgroundColor: "#1a1a2e",
// //     paddingVertical: 16,
// //     paddingHorizontal: 32,
// //     borderRadius: 12,
// //     marginTop: 8,
// //     width: "100%",
// //     justifyContent: "center",
// //   },
// //   createButtonText: {
// //     color: "#fff",
// //     fontSize: 16,
// //     fontWeight: "600",
// //   },
// //   buttonDisabled: {
// //     opacity: 0.7,
// //   },
// //   // ─── Account card ─────────────────────────────────────────────
// //   accountCard: {
// //     backgroundColor: "#fff",
// //     borderRadius: 16,
// //     borderWidth: 1,
// //     borderColor: "#e5e5e5",
// //     padding: 20,
// //     marginBottom: 12,
// //   },
// //   accountHeader: {
// //     flexDirection: "row",
// //     alignItems: "center",
// //     gap: 8,
// //     marginBottom: 12,
// //   },
// //   bankIconWrap: {
// //     width: 32,
// //     height: 32,
// //     borderRadius: 8,
// //     backgroundColor: "#f0f4f8",
// //     justifyContent: "center",
// //     alignItems: "center",
// //   },
// //   bankName: {
// //     flex: 1,
// //     fontSize: 16,
// //     fontWeight: "600",
// //     color: "#1a1a2e",
// //   },
// //   divider: {
// //     height: 1,
// //     backgroundColor: "#f0f0f0",
// //     marginBottom: 12,
// //   },
// //   accountName: {
// //     fontSize: 13,
// //     color: "#666",
// //     marginBottom: 10,
// //   },
// //   accountFooter: {
// //     flexDirection: "row",
// //     justifyContent: "space-between",
// //     alignItems: "center",
// //   },
// //   accountNumberRow: {
// //     flexDirection: "row",
// //     alignItems: "center",
// //     gap: 6,
// //   },
// //   accountNumber: {
// //     fontSize: 15,
// //     fontWeight: "600",
// //     color: "#1a1a2e",
// //     letterSpacing: 1,
// //   },
// //   copyButton: {
// //     flexDirection: "row",
// //     alignItems: "center",
// //     gap: 4,
// //     backgroundColor: "#f0f4f8",
// //     paddingHorizontal: 12,
// //     paddingVertical: 6,
// //     borderRadius: 8,
// //   },
// //   copyText: {
// //     fontSize: 12,
// //     fontWeight: "500",
// //     color: "#1a1a2e",
// //   },
// // });

// // export default AccountDetails;

// import React from "react";
// import {
//   View,
//   Text,
//   StyleSheet,
//   TouchableOpacity,
//   ScrollView,
//   Alert,
//   ActivityIndicator,
// } from "react-native";
// import { SafeAreaView } from "react-native-safe-area-context";
// import { Ionicons } from "@expo/vector-icons";
// import { useFetchData_v2, useMutateData_v2 } from "../../hooks/Requestv2";
// import { useNavigation } from "@react-navigation/native";

// const AccountDetails = () => {
//   const navigation = useNavigation();

//   const { data, isLoading, isError, error, refetch } = useFetchData_v2(
//     "account/getVirtualAccount",
//     "virtualAccount",
//   );

//   const { mutate: createVirtualAccount, isPending: isCreating } =
//     useMutateData_v2(
//       "account/createVirtualAccount",
//       "POST",
//       "virtualAccount", // auto-refetches getVirtualAccount on success
//       {
//         onSuccess: () => {
//           Alert.alert("Success", "Virtual account created successfully!");
//         },
//         onError: (error: any) => {
//           const msg =
//             error?.data?.message || "Failed to create virtual account";
//           Alert.alert("Error", msg);
//         },
//       },
//     );

//   const account = data?.data?.data;

//   // ─── Loading ──────────────────────────────────────────────────
//   if (isLoading) {
//     return (
//       <SafeAreaView style={styles.container}>
//         <View style={styles.header}>
//           <Text style={styles.headerTitle}>Bank Accounts</Text>
//           <TouchableOpacity
//             style={styles.closeButton}
//             onPress={() => navigation.goBack()}
//           >
//             <Ionicons name="close" size={24} color="#1a1a2e" />
//           </TouchableOpacity>
//         </View>
//         <View style={styles.centeredState}>
//           <ActivityIndicator size="large" color="#1a1a2e" />
//           <Text style={styles.stateText}>Loading account...</Text>
//         </View>
//       </SafeAreaView>
//     );
//   }

//   // ─── Error ────────────────────────────────────────────────────
//   if (isError) {
//     return (
//       <SafeAreaView style={styles.container}>
//         <View style={styles.header}>
//           <Text style={styles.headerTitle}>Bank Accounts</Text>
//           <TouchableOpacity
//             style={styles.closeButton}
//             onPress={() => navigation.goBack()}
//           >
//             <Ionicons name="close" size={24} color="#1a1a2e" />
//           </TouchableOpacity>
//         </View>
//         <View style={styles.centeredState}>
//           <Ionicons name="alert-circle-outline" size={48} color="#ef4444" />
//           <Text style={styles.stateText}>
//             {(error as any)?.message || "Failed to load account"}
//           </Text>
//           <TouchableOpacity
//             style={styles.retryButton}
//             onPress={() => refetch()}
//           >
//             <Text style={styles.retryText}>Try Again</Text>
//           </TouchableOpacity>
//         </View>
//       </SafeAreaView>
//     );
//   }

//   return (
//     <SafeAreaView style={styles.container}>
//       {/* Header */}
//       <View style={styles.header}>
//         <Text style={styles.headerTitle}>Bank Accounts</Text>
//         <TouchableOpacity
//           style={styles.closeButton}
//           onPress={() => navigation.goBack()}
//         >
//           <Ionicons name="close" size={24} color="#1a1a2e" />
//         </TouchableOpacity>
//       </View>

//       <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
//         {!account ? (
//           /* ─── No account — show create button ─── */
//           <View style={styles.emptyState}>
//             <View style={styles.emptyIconWrap}>
//               <Ionicons name="wallet-outline" size={40} color="#1a1a2e" />
//             </View>
//             <Text style={styles.emptyTitle}>No bank account yet</Text>
//             <Text style={styles.emptySubtitle}>
//               Create a free virtual bank account to start sending and receiving
//               money instantly.
//             </Text>
//             <TouchableOpacity
//               style={[styles.createButton, isCreating && styles.buttonDisabled]}
//               onPress={() => createVirtualAccount({})}
//               disabled={isCreating}
//             >
//               {isCreating ? (
//                 <ActivityIndicator color="#fff" />
//               ) : (
//                 <>
//                   <Ionicons name="add-circle-outline" size={20} color="#fff" />
//                   <Text style={styles.createButtonText}>
//                     Create Virtual Account
//                   </Text>
//                 </>
//               )}
//             </TouchableOpacity>
//           </View>
//         ) : (
//           /* ─── Account card ─── */
//           <View style={styles.accountCard}>
//             <View style={styles.accountHeader}>
//               <View style={styles.bankIconWrap}>
//                 <Ionicons name="business-outline" size={18} color="#1a1a2e" />
//               </View>
//               <Text style={styles.bankName}>{account.data.bankName}</Text>
//             </View>

//             <View style={styles.divider} />

//             <Text style={styles.accountName}>{account.data.accountName}</Text>

//             <View style={styles.accountFooter}>
//               <View style={styles.accountNumberRow}>
//                 <Ionicons name="card-outline" size={14} color="#999" />
//                 <Text style={styles.accountNumber}>
//                   {account.data.accountNumber}
//                 </Text>
//               </View>
//               <TouchableOpacity
//                 style={styles.copyButton}
//                 onPress={() =>
//                   Alert.alert("Copied", `${account.data.accountNumber} copied`)
//                 }
//               >
//                 <Ionicons name="copy-outline" size={14} color="#1a1a2e" />
//                 <Text style={styles.copyText}>Copy</Text>
//               </TouchableOpacity>
//             </View>
//           </View>
//         )}
//       </ScrollView>
//     </SafeAreaView>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#f5f5f5",
//   },
//   header: {
//     flexDirection: "row",
//     justifyContent: "space-between",
//     alignItems: "center",
//     paddingHorizontal: 20,
//     paddingVertical: 16,
//     borderBottomWidth: 1,
//     borderBottomColor: "#e5e5e5",
//     backgroundColor: "#fff",
//   },
//   headerTitle: {
//     fontSize: 24,
//     fontWeight: "700",
//     color: "#1a1a2e",
//   },
//   closeButton: {
//     width: 40,
//     height: 40,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   content: {
//     flex: 1,
//     padding: 16,
//   },
//   centeredState: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     gap: 12,
//     paddingHorizontal: 32,
//   },
//   stateText: {
//     fontSize: 14,
//     color: "#666",
//     textAlign: "center",
//   },
//   retryButton: {
//     marginTop: 4,
//     backgroundColor: "#1a1a2e",
//     paddingHorizontal: 24,
//     paddingVertical: 12,
//     borderRadius: 10,
//   },
//   retryText: {
//     color: "#fff",
//     fontWeight: "600",
//     fontSize: 14,
//   },
//   // ─── Empty / Create state ─────────────────────────────────────
//   emptyState: {
//     alignItems: "center",
//     paddingVertical: 60,
//     paddingHorizontal: 24,
//     gap: 12,
//   },
//   emptyIconWrap: {
//     width: 80,
//     height: 80,
//     borderRadius: 40,
//     backgroundColor: "#f0f4f8",
//     justifyContent: "center",
//     alignItems: "center",
//     marginBottom: 8,
//   },
//   emptyTitle: {
//     fontSize: 18,
//     fontWeight: "700",
//     color: "#1a1a2e",
//   },
//   emptySubtitle: {
//     fontSize: 14,
//     color: "#666",
//     textAlign: "center",
//     lineHeight: 20,
//     marginBottom: 8,
//   },
//   createButton: {
//     flexDirection: "row",
//     alignItems: "center",
//     gap: 8,
//     backgroundColor: "#1a1a2e",
//     paddingVertical: 16,
//     paddingHorizontal: 32,
//     borderRadius: 12,
//     marginTop: 8,
//     width: "100%",
//     justifyContent: "center",
//   },
//   createButtonText: {
//     color: "#fff",
//     fontSize: 16,
//     fontWeight: "600",
//   },
//   buttonDisabled: {
//     opacity: 0.7,
//   },
//   // ─── Account card ─────────────────────────────────────────────
//   accountCard: {
//     backgroundColor: "#fff",
//     borderRadius: 16,
//     borderWidth: 1,
//     borderColor: "#e5e5e5",
//     padding: 20,
//     marginBottom: 12,
//   },
//   accountHeader: {
//     flexDirection: "row",
//     alignItems: "center",
//     gap: 8,
//     marginBottom: 12,
//   },
//   bankIconWrap: {
//     width: 32,
//     height: 32,
//     borderRadius: 8,
//     backgroundColor: "#f0f4f8",
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   bankName: {
//     flex: 1,
//     fontSize: 16,
//     fontWeight: "600",
//     color: "#1a1a2e",
//   },
//   divider: {
//     height: 1,
//     backgroundColor: "#f0f0f0",
//     marginBottom: 12,
//   },
//   accountName: {
//     fontSize: 13,
//     color: "#666",
//     marginBottom: 10,
//   },
//   accountFooter: {
//     flexDirection: "row",
//     justifyContent: "space-between",
//     alignItems: "center",
//   },
//   accountNumberRow: {
//     flexDirection: "row",
//     alignItems: "center",
//     gap: 6,
//   },
//   accountNumber: {
//     fontSize: 15,
//     fontWeight: "600",
//     color: "#1a1a2e",
//     letterSpacing: 1,
//   },
//   copyButton: {
//     flexDirection: "row",
//     alignItems: "center",
//     gap: 4,
//     backgroundColor: "#f0f4f8",
//     paddingHorizontal: 12,
//     paddingVertical: 6,
//     borderRadius: 8,
//   },
//   copyText: {
//     fontSize: 12,
//     fontWeight: "500",
//     color: "#1a1a2e",
//   },
// });

// export default AccountDetails;

import React from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
  Linking,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import { useFetchData_v2, useMutateData_v2 } from "../../hooks/Requestv2";
import { useNavigation } from "@react-navigation/native";
import { useSelector } from "react-redux";

const AccountDetails = () => {
  const navigation = useNavigation();

  // ─── Read user details from Redux ────────────────────────────
  const userDetails = useSelector((state: any) => state.authSlice.userDetails);
  const usdAccountCreated = userDetails?.virtualUsdAccountCreated === true;
  const usdKycLink = userDetails?.virtualUsdAccountKycLink;
  const usdTosLink = userDetails?.virtualUsdAccountTosLink;
  const usdStatus = userDetails?.virtualUsdAccountStatus; // e.g. "inactive", "active"

  // ─── Fetch NGN virtual account ────────────────────────────────
  const { data, isLoading, isError, error, refetch } = useFetchData_v2(
    "account/getVirtualAccount",
    "virtualAccount",
  );

  // ─── Create NGN virtual account ───────────────────────────────
  const { mutate: createNgnAccount, isPending: isCreatingNgn } =
    useMutateData_v2("account/createVirtualAccount", "POST", "virtualAccount", {
      onSuccess: () => {
        Alert.alert("Success", "NGN virtual account created successfully!");
      },
      onError: (error: any) => {
        const msg = error?.data?.message || "Failed to create NGN account";
        Alert.alert("Error", msg);
      },
    });

  // ─── Create USD virtual account ───────────────────────────────
  const { mutate: createUsdAccount, isPending: isCreatingUsd } =
    useMutateData_v2(
      "account/createUsdVirtualAccount",
      "POST",
      "userDetails", // invalidate user details so usdAccountCreated updates
      {
        onSuccess: (data) => {
          const tosLink = data?.data?.data?.tos_link;
          const kycLink = data?.data?.data?.kyc_link;

          // Prompt user to accept ToS first, then KYC
          if (tosLink) {
            Alert.alert(
              "USD Account Created",
              "Please accept the Terms of Service and complete KYC to activate your USD account.",
              [
                {
                  text: "Accept Terms",
                  onPress: () => Linking.openURL(tosLink),
                },
                { text: "Later", style: "cancel" },
              ],
            );
          } else {
            Alert.alert("Success", "USD virtual account created successfully!");
          }
        },
        onError: (error: any) => {
          const msg = error?.data?.message || "Failed to create USD account";
          Alert.alert("Error", msg);
        },
      },
    );

  const account = data?.data?.data;

  // ─── Loading ──────────────────────────────────────────────────
  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Bank Accounts</Text>
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => navigation.goBack()}
          >
            <Ionicons name="close" size={24} color="#1a1a2e" />
          </TouchableOpacity>
        </View>
        <View style={styles.centeredState}>
          <ActivityIndicator size="large" color="#1a1a2e" />
          <Text style={styles.stateText}>Loading account...</Text>
        </View>
      </SafeAreaView>
    );
  }

  // ─── Error ────────────────────────────────────────────────────
  if (isError) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Bank Accounts</Text>
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => navigation.goBack()}
          >
            <Ionicons name="close" size={24} color="#1a1a2e" />
          </TouchableOpacity>
        </View>
        <View style={styles.centeredState}>
          <Ionicons name="alert-circle-outline" size={48} color="#ef4444" />
          <Text style={styles.stateText}>
            {(error as any)?.message || "Failed to load account"}
          </Text>
          <TouchableOpacity
            style={styles.retryButton}
            onPress={() => refetch()}
          >
            <Text style={styles.retryText}>Try Again</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Bank Accounts</Text>
        <TouchableOpacity
          style={styles.closeButton}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="close" size={24} color="#1a1a2e" />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
        {/* ══════════════════════════════════════
            NGN ACCOUNT SECTION
        ══════════════════════════════════════ */}
        <Text style={styles.sectionLabel}>🇳🇬 Naira Account</Text>

        {!account ? (
          <View style={styles.emptyState}>
            <View style={styles.emptyIconWrap}>
              <Ionicons name="wallet-outline" size={36} color="#1a1a2e" />
            </View>
            <Text style={styles.emptyTitle}>No NGN account yet</Text>
            <Text style={styles.emptySubtitle}>
              Create a free virtual Naira account to send and receive money.
            </Text>
            <TouchableOpacity
              style={[
                styles.createButton,
                isCreatingNgn && styles.buttonDisabled,
              ]}
              onPress={() => createNgnAccount({})}
              disabled={isCreatingNgn}
            >
              {isCreatingNgn ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Ionicons name="add-circle-outline" size={20} color="#fff" />
                  <Text style={styles.createButtonText}>
                    Create NGN Account
                  </Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.accountCard}>
            <View style={styles.accountHeader}>
              <View style={styles.bankIconWrap}>
                <Ionicons name="business-outline" size={18} color="#1a1a2e" />
              </View>
              <Text style={styles.bankName}>{account.data.bankName}</Text>
              <View style={styles.activeBadge}>
                <Text style={styles.activeBadgeText}>Active</Text>
              </View>
            </View>

            <View style={styles.divider} />

            <Text style={styles.accountName}>{account.data.accountName}</Text>

            <View style={styles.accountFooter}>
              <View style={styles.accountNumberRow}>
                <Ionicons name="card-outline" size={14} color="#999" />
                <Text style={styles.accountNumber}>
                  {account.data.accountNumber}
                </Text>
              </View>
              <TouchableOpacity
                style={styles.copyButton}
                onPress={() =>
                  Alert.alert("Copied", `${account.data.accountNumber} copied`)
                }
              >
                <Ionicons name="copy-outline" size={14} color="#1a1a2e" />
                <Text style={styles.copyText}>Copy</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* ══════════════════════════════════════
            USD ACCOUNT SECTION
        ══════════════════════════════════════ */}
        <Text style={[styles.sectionLabel, { marginTop: 28 }]}>
          🇺🇸 USD Account
        </Text>

        {usdAccountCreated ? (
          /* USD account exists — show status card */
          <View style={styles.accountCard}>
            <View style={styles.accountHeader}>
              <View
                style={[styles.bankIconWrap, { backgroundColor: "#e8f5e9" }]}
              >
                <MaterialCommunityIcons
                  name="currency-usd"
                  size={18}
                  color="#2e7d32"
                />
              </View>
              <Text style={styles.bankName}>USD Virtual Account</Text>
              <View
                style={[
                  styles.activeBadge,
                  usdStatus === "active"
                    ? styles.badgeActive
                    : styles.badgePending,
                ]}
              >
                <Text
                  style={[
                    styles.activeBadgeText,
                    usdStatus === "active"
                      ? styles.badgeActiveText
                      : styles.badgePendingText,
                  ]}
                >
                  {usdStatus === "active" ? "Active" : "Pending"}
                </Text>
              </View>
            </View>

            <View style={styles.divider} />

            {/* If pending, show KYC/ToS action links */}
            {usdStatus !== "active" && (
              <View style={styles.pendingActions}>
                <Text style={styles.pendingText}>
                  Complete the steps below to activate your USD account:
                </Text>
                {usdTosLink && (
                  <TouchableOpacity
                    style={styles.linkButton}
                    onPress={() => Linking.openURL(usdTosLink)}
                  >
                    <Ionicons
                      name="document-text-outline"
                      size={16}
                      color="#1a1a2e"
                    />
                    <Text style={styles.linkButtonText}>
                      Accept Terms of Service
                    </Text>
                    <Ionicons name="open-outline" size={14} color="#999" />
                  </TouchableOpacity>
                )}
                {usdKycLink && (
                  <TouchableOpacity
                    style={styles.linkButton}
                    onPress={() => Linking.openURL(usdKycLink)}
                  >
                    <Ionicons
                      name="shield-checkmark-outline"
                      size={16}
                      color="#1a1a2e"
                    />
                    <Text style={styles.linkButtonText}>Complete KYC</Text>
                    <Ionicons name="open-outline" size={14} color="#999" />
                  </TouchableOpacity>
                )}
              </View>
            )}

            {usdStatus === "active" && (
              <Text style={styles.accountName}>USD account is active</Text>
            )}
          </View>
        ) : (
          /* No USD account yet */
          <View style={styles.emptyState}>
            <View
              style={[styles.emptyIconWrap, { backgroundColor: "#e8f5e9" }]}
            >
              <MaterialCommunityIcons
                name="currency-usd"
                size={36}
                color="#2e7d32"
              />
            </View>
            <Text style={styles.emptyTitle}>No USD account yet</Text>
            <Text style={styles.emptySubtitle}>
              Create a USD virtual account to send and receive dollars
              internationally.
            </Text>
            <TouchableOpacity
              style={[
                styles.createButton,
                styles.createButtonUsd,
                isCreatingUsd && styles.buttonDisabled,
              ]}
              onPress={() => createUsdAccount({})}
              disabled={isCreatingUsd}
            >
              {isCreatingUsd ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <MaterialCommunityIcons
                    name="currency-usd"
                    size={20}
                    color="#fff"
                  />
                  <Text style={styles.createButtonText}>
                    Create USD Account
                  </Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        )}

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e5e5",
    backgroundColor: "#fff",
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: "#1a1a2e",
  },
  closeButton: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  content: {
    flex: 1,
    padding: 16,
  },
  centeredState: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    gap: 12,
    paddingHorizontal: 32,
  },
  stateText: {
    fontSize: 14,
    color: "#666",
    textAlign: "center",
  },
  retryButton: {
    marginTop: 4,
    backgroundColor: "#1a1a2e",
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 10,
  },
  retryText: {
    color: "#fff",
    fontWeight: "600",
    fontSize: 14,
  },
  sectionLabel: {
    fontSize: 13,
    fontWeight: "700",
    color: "#888",
    letterSpacing: 0.5,
    marginBottom: 10,
    marginTop: 4,
    textTransform: "uppercase",
  },
  // ─── Empty state ──────────────────────────────────────────────
  emptyState: {
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 24,
    gap: 10,
  },
  emptyIconWrap: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: "#f0f4f8",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 4,
  },
  emptyTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#1a1a2e",
  },
  emptySubtitle: {
    fontSize: 13,
    color: "#666",
    textAlign: "center",
    lineHeight: 20,
  },
  createButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "#1a1a2e",
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 12,
    marginTop: 6,
    width: "100%",
    justifyContent: "center",
  },
  createButtonUsd: {
    backgroundColor: "#2e7d32",
  },
  createButtonText: {
    color: "#fff",
    fontSize: 15,
    fontWeight: "600",
  },
  buttonDisabled: {
    opacity: 0.7,
  },
  // ─── Account card ─────────────────────────────────────────────
  accountCard: {
    backgroundColor: "#fff",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    padding: 20,
  },
  accountHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginBottom: 12,
  },
  bankIconWrap: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: "#f0f4f8",
    justifyContent: "center",
    alignItems: "center",
  },
  bankName: {
    flex: 1,
    fontSize: 15,
    fontWeight: "600",
    color: "#1a1a2e",
  },
  activeBadge: {
    backgroundColor: "#e8f5e9",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
  },
  activeBadgeText: {
    fontSize: 11,
    fontWeight: "600",
    color: "#2e7d32",
  },
  badgeActive: {
    backgroundColor: "#e8f5e9",
  },
  badgeActiveText: {
    color: "#2e7d32",
  },
  badgePending: {
    backgroundColor: "#fff8e1",
  },
  badgePendingText: {
    color: "#f57f17",
  },
  divider: {
    height: 1,
    backgroundColor: "#f0f0f0",
    marginBottom: 12,
  },
  accountName: {
    fontSize: 13,
    color: "#666",
    marginBottom: 10,
  },
  accountFooter: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  accountNumberRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  accountNumber: {
    fontSize: 15,
    fontWeight: "600",
    color: "#1a1a2e",
    letterSpacing: 1,
  },
  copyButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: "#f0f4f8",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  copyText: {
    fontSize: 12,
    fontWeight: "500",
    color: "#1a1a2e",
  },
  // ─── USD pending actions ──────────────────────────────────────
  pendingActions: {
    gap: 10,
  },
  pendingText: {
    fontSize: 13,
    color: "#666",
    marginBottom: 4,
    lineHeight: 18,
  },
  linkButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "#f5f7fa",
    padding: 14,
    borderRadius: 10,
  },
  linkButtonText: {
    flex: 1,
    fontSize: 14,
    fontWeight: "500",
    color: "#1a1a2e",
  },
});

export default AccountDetails;
