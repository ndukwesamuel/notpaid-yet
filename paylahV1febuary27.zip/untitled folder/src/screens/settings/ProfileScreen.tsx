// import React, { useState } from "react";
// import {
//   View,
//   Text,
//   StyleSheet,
//   TouchableOpacity,
//   TextInput,
//   Alert,
//   ScrollView,
// } from "react-native";
// import { SafeAreaView } from "react-native-safe-area-context";
// import { Ionicons } from "@expo/vector-icons";
// import { useNavigation } from "@react-navigation/native";

// const ProfileScreen = () => {
//   const navigation = useNavigation();
//   const [fullName, setFullName] = useState("");
//   const [email, setEmail] = useState("");
//   const [phone, setPhone] = useState("");

//   const handleSave = () => {
//     Alert.alert("Success", "Profile updated successfully", [{ text: "OK" }]);
//   };

//   return (
//     <SafeAreaView style={styles.container}>
//       {/* Header */}
//       <View style={styles.header}>
//         <Text style={styles.headerTitle}>Profile</Text>
//         <TouchableOpacity
//           style={styles.closeButton}
//           onPress={() => navigation.goBack()}
//         >
//           <Ionicons name="close" size={24} color="#1a1a2e" />
//         </TouchableOpacity>
//       </View>

//       <ScrollView showsVerticalScrollIndicator={false}>
//         <View style={styles.card}>
//           {/* Avatar */}
//           <View style={styles.avatarContainer}>
//             <View style={styles.avatar}>
//               <Text style={styles.avatarText}>EI</Text>
//             </View>
//             <Text style={styles.userName}>User</Text>
//             <Text style={styles.userEmail}>No email</Text>
//           </View>

//           {/* Form */}
//           <View style={styles.form}>
//             <Text style={styles.label}>Full Name</Text>
//             <TextInput
//               style={styles.input}
//               placeholder="Enter your name"
//               placeholderTextColor="#999"
//               value={fullName}
//               onChangeText={setFullName}
//             />

//             <Text style={styles.label}>Email</Text>
//             <TextInput
//               style={styles.input}
//               placeholder="Enter your email"
//               placeholderTextColor="#999"
//               keyboardType="email-address"
//               autoCapitalize="none"
//               value={email}
//               onChangeText={setEmail}
//             />

//             <Text style={styles.label}>Phone Number</Text>
//             <TextInput
//               style={styles.input}
//               placeholder="08012345678"
//               placeholderTextColor="#999"
//               keyboardType="phone-pad"
//               value={phone}
//               onChangeText={setPhone}
//             />

//             <TouchableOpacity style={styles.button} onPress={handleSave}>
//               <Text style={styles.buttonText}>Save Changes</Text>
//             </TouchableOpacity>
//           </View>
//         </View>
//       </ScrollView>
//     </SafeAreaView>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#f5f5f5",
//   },
//   header: {
//     flexDirection: "row",
//     justifyContent: "space-between",
//     alignItems: "center",
//     paddingHorizontal: 20,
//     paddingVertical: 16,
//     borderBottomWidth: 1,
//     borderBottomColor: "#e5e5e5",
//     backgroundColor: "#fff",
//   },
//   headerTitle: {
//     fontSize: 24,
//     fontWeight: "700",
//     color: "#1a1a2e",
//   },
//   closeButton: {
//     width: 40,
//     height: 40,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   card: {
//     backgroundColor: "#fff",
//     margin: 16,
//     borderRadius: 16,
//     borderWidth: 1,
//     borderColor: "#e5e5e5",
//     padding: 24,
//   },
//   avatarContainer: {
//     alignItems: "center",
//     marginBottom: 24,
//   },
//   avatar: {
//     width: 80,
//     height: 80,
//     borderRadius: 40,
//     backgroundColor: "#1a1a2e",
//     justifyContent: "center",
//     alignItems: "center",
//     marginBottom: 12,
//   },
//   avatarText: {
//     color: "#fff",
//     fontSize: 24,
//     fontWeight: "600",
//   },
//   userName: {
//     fontSize: 20,
//     fontWeight: "600",
//     color: "#1a1a2e",
//     marginBottom: 4,
//   },
//   userEmail: {
//     fontSize: 14,
//     color: "#666",
//   },
//   form: {
//     gap: 8,
//   },
//   label: {
//     fontSize: 14,
//     fontWeight: "500",
//     color: "#1a1a2e",
//     marginTop: 8,
//   },
//   input: {
//     borderWidth: 1,
//     borderColor: "#e5e5e5",
//     borderRadius: 12,
//     paddingHorizontal: 16,
//     paddingVertical: 14,
//     fontSize: 16,
//     color: "#1a1a2e",
//     backgroundColor: "#f9f9f9",
//     marginTop: 8,
//   },
//   button: {
//     backgroundColor: "#1a1a2e",
//     height: 56,
//     borderRadius: 12,
//     justifyContent: "center",
//     alignItems: "center",
//     marginTop: 24,
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 16,
//     fontWeight: "600",
//   },
// });

// export default ProfileScreen;

import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  ScrollView,
  ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { useFetchData_v2, useMutateData_v2 } from "../../hooks/Requestv2";

const ProfileScreen = () => {
  const navigation = useNavigation();
  const [isEditing, setIsEditing] = useState(false);

  // Editable fields
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");

  // ─── Fetch account details ─────────────────────────────────────
  const {
    data: accountData,
    isLoading,
    isError,
  } = useFetchData_v2("account/getAccountDetails", "accountDetails");

  const account = accountData?.data?.data;

  // Populate fields when data loads
  useEffect(() => {
    if (account) {
      setFullName(`${account.first_name} ${account.last_name}`.trim());
      setEmail(account.email ?? "");
      setPhone(account.phone_number ?? "");
      setAddress(account.address ?? "");
    }
  }, [account]);

  // ─── Update profile ────────────────────────────────────────────
  const { mutate: updateProfile, isPending: saving } = useMutateData_v2(
    "account/updateProfile",
    "PUT",
    "accountDetails",
    {
      onSuccess: () => {
        Alert.alert("Success", "Profile updated successfully");
        setIsEditing(false);
      },
      onError: (error: any) => {
        Alert.alert(
          "Error",
          error?.data?.message || "Failed to update profile",
        );
      },
    },
  );

  const handleSave = () => {
    updateProfile({ fullName, email, phone, address });
  };

  const handleCancelEdit = () => {
    // Reset fields back to account data
    if (account) {
      setFullName(`${account.first_name} ${account.last_name}`.trim());
      setEmail(account.email ?? "");
      setPhone(account.phone_number ?? "");
      setAddress(account.address ?? "");
    }
    setIsEditing(false);
  };

  const initials = account
    ? `${account.first_name?.[0] ?? ""}${account.last_name?.[0] ?? ""}`.toUpperCase()
    : "??";

  // ─── Loading ───────────────────────────────────────────────────
  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <Header
          isEditing={false}
          onBack={() => navigation.goBack()}
          onEdit={() => {}}
          onCancel={() => {}}
        />
        <View style={styles.centeredState}>
          <ActivityIndicator size="large" color="#1a1a2e" />
          <Text style={styles.stateText}>Loading profile...</Text>
        </View>
      </SafeAreaView>
    );
  }

  // ─── Error ─────────────────────────────────────────────────────
  if (isError || !account) {
    return (
      <SafeAreaView style={styles.container}>
        <Header
          isEditing={false}
          onBack={() => navigation.goBack()}
          onEdit={() => {}}
          onCancel={() => {}}
        />
        <View style={styles.centeredState}>
          <Ionicons name="alert-circle-outline" size={48} color="#ef4444" />
          <Text style={styles.stateText}>Failed to load profile</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Header
        isEditing={isEditing}
        onBack={() => navigation.goBack()}
        onEdit={() => setIsEditing(true)}
        onCancel={handleCancelEdit}
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* ── Avatar Section ─────────────────────────────── */}
        <View style={styles.avatarSection}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>{initials}</Text>
          </View>
          <Text style={styles.userName}>
            {account.first_name} {account.last_name}
          </Text>
          <Text style={styles.userEmail}>{account.email}</Text>

          {/* KYC badge */}
          {account.kyc_metadata && (
            <View style={styles.kycBadge}>
              <Ionicons name="shield-checkmark" size={13} color="#10b981" />
              <Text style={styles.kycBadgeText}>KYC Verified</Text>
            </View>
          )}
        </View>

        {/* ── Details / Edit Card ─────────────────────────── */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>
            {isEditing ? "Edit Profile" : "Personal Information"}
          </Text>

          <DetailRow
            icon="person-outline"
            label="Full Name"
            value={fullName}
            isEditing={isEditing}
            onChangeText={setFullName}
            placeholder="Enter your full name"
          />

          <DetailRow
            icon="mail-outline"
            label="Email"
            value={email}
            isEditing={isEditing}
            onChangeText={setEmail}
            placeholder="Enter your email"
            keyboardType="email-address"
            autoCapitalize="none"
          />

          <DetailRow
            icon="call-outline"
            label="Phone Number"
            value={phone}
            isEditing={isEditing}
            onChangeText={setPhone}
            placeholder="Phone number"
            keyboardType="phone-pad"
          />

          <DetailRow
            icon="location-outline"
            label="Address"
            value={address}
            isEditing={isEditing}
            onChangeText={setAddress}
            placeholder="Enter your address"
            isLast
          />

          {/* Save button — only in edit mode */}
          {isEditing && (
            <TouchableOpacity
              style={[styles.saveButton, saving && styles.saveButtonDisabled]}
              onPress={handleSave}
              disabled={saving}
            >
              {saving ? (
                <ActivityIndicator color="#fff" size="small" />
              ) : (
                <>
                  <Ionicons
                    name="checkmark-circle-outline"
                    size={18}
                    color="#fff"
                  />
                  <Text style={styles.saveButtonText}>Save Changes</Text>
                </>
              )}
            </TouchableOpacity>
          )}
        </View>

        {/* ── Account Info Card ───────────────────────────── */}
        {!isEditing && (
          <View style={styles.card}>
            <Text style={styles.sectionTitle}>Account Info</Text>

            <InfoRow
              label="Country"
              value={account.country}
              icon="globe-outline"
            />
            <InfoRow
              label="Member Since"
              value={new Date(account.created_at).toLocaleDateString("en-NG", {
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
              icon="calendar-outline"
            />
            {account.kyc_metadata?.id_type && (
              <InfoRow
                label="ID Verification"
                value={account.kyc_metadata.id_type.replace(/_/g, " ")}
                icon="card-outline"
                isLast
              />
            )}
          </View>
        )}

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
};

// ── Header ────────────────────────────────────────────────────────
const Header = ({
  isEditing,
  onBack,
  onEdit,
  onCancel,
}: {
  isEditing: boolean;
  onBack: () => void;
  onEdit: () => void;
  onCancel: () => void;
}) => (
  <View style={styles.header}>
    <TouchableOpacity
      style={styles.headerBtn}
      onPress={onBack}
      hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
    >
      <Ionicons name="arrow-back" size={24} color="#1a1a2e" />
    </TouchableOpacity>

    <Text style={styles.headerTitle}>Profile</Text>

    <TouchableOpacity
      style={styles.headerBtn}
      onPress={isEditing ? onCancel : onEdit}
      hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
    >
      <Ionicons
        name={isEditing ? "close" : "create-outline"}
        size={22}
        color={isEditing ? "#ef4444" : "#1a1a2e"}
      />
    </TouchableOpacity>
  </View>
);

// ── DetailRow — shows value or input ─────────────────────────────
const DetailRow = ({
  icon,
  label,
  value,
  isEditing,
  onChangeText,
  placeholder,
  keyboardType,
  autoCapitalize,
  isLast,
}: {
  icon: any;
  label: string;
  value: string;
  isEditing: boolean;
  onChangeText: (t: string) => void;
  placeholder?: string;
  keyboardType?: any;
  autoCapitalize?: any;
  isLast?: boolean;
}) => (
  <View style={[styles.detailRow, !isLast && styles.detailRowBorder]}>
    <View style={styles.detailIconWrap}>
      <Ionicons name={icon} size={16} color="#666" />
    </View>
    <View style={styles.detailContent}>
      <Text style={styles.detailLabel}>{label}</Text>
      {isEditing ? (
        <TextInput
          style={styles.detailInput}
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor="#bbb"
          keyboardType={keyboardType}
          autoCapitalize={autoCapitalize ?? "words"}
        />
      ) : (
        <Text style={styles.detailValue}>{value || "—"}</Text>
      )}
    </View>
  </View>
);

// ── InfoRow — read-only ───────────────────────────────────────────
const InfoRow = ({
  icon,
  label,
  value,
  isLast,
}: {
  icon: any;
  label: string;
  value: string;
  isLast?: boolean;
}) => (
  <View style={[styles.detailRow, !isLast && styles.detailRowBorder]}>
    <View style={styles.detailIconWrap}>
      <Ionicons name={icon} size={16} color="#666" />
    </View>
    <View style={styles.detailContent}>
      <Text style={styles.detailLabel}>{label}</Text>
      <Text style={styles.detailValue}>{value || "—"}</Text>
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f5f5f5" },

  // ── Header ────────────────────────────────────────────────────
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e5e5",
    backgroundColor: "#fff",
  },
  headerTitle: { fontSize: 18, fontWeight: "700", color: "#1a1a2e" },
  headerBtn: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },

  // ── States ────────────────────────────────────────────────────
  centeredState: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    gap: 12,
  },
  stateText: { fontSize: 14, color: "#666" },

  // ── Avatar Section ────────────────────────────────────────────
  avatarSection: {
    alignItems: "center",
    paddingVertical: 28,
    gap: 4,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: "#1a1a2e",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 10,
  },
  avatarText: { color: "#fff", fontSize: 26, fontWeight: "700" },
  userName: { fontSize: 20, fontWeight: "700", color: "#1a1a2e" },
  userEmail: { fontSize: 14, color: "#777" },
  kycBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    backgroundColor: "#f0fdf7",
    borderRadius: 20,
    borderWidth: 1,
    borderColor: "#6ee7b7",
    paddingHorizontal: 10,
    paddingVertical: 4,
    marginTop: 8,
  },
  kycBadgeText: { fontSize: 12, color: "#059669", fontWeight: "600" },

  // ── Card ──────────────────────────────────────────────────────
  card: {
    backgroundColor: "#fff",
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    overflow: "hidden",
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: "700",
    color: "#999",
    textTransform: "uppercase",
    letterSpacing: 0.6,
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 12,
  },

  // ── Detail Rows ───────────────────────────────────────────────
  detailRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 14,
    gap: 12,
  },
  detailRowBorder: {
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  detailIconWrap: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: "#f5f7fa",
    justifyContent: "center",
    alignItems: "center",
  },
  detailContent: { flex: 1 },
  detailLabel: {
    fontSize: 11,
    fontWeight: "600",
    color: "#999",
    textTransform: "uppercase",
    letterSpacing: 0.4,
    marginBottom: 3,
  },
  detailValue: { fontSize: 15, color: "#1a1a2e", fontWeight: "500" },
  detailInput: {
    fontSize: 15,
    color: "#1a1a2e",
    fontWeight: "500",
    padding: 0,
    borderBottomWidth: 1,
    borderBottomColor: "#1a1a2e",
    paddingBottom: 2,
  },

  // ── Save Button ───────────────────────────────────────────────
  saveButton: {
    margin: 16,
    backgroundColor: "#1a1a2e",
    height: 52,
    borderRadius: 12,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 8,
  },
  saveButtonDisabled: { backgroundColor: "#9ca3af" },
  saveButtonText: { color: "#fff", fontSize: 15, fontWeight: "600" },
});

export default ProfileScreen;
