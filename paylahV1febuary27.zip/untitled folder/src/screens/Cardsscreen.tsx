import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
  Clipboard,
  TextInput,
  Modal,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { useFetchData_v2, useMutateData_v2 } from "../hooks/Requestv2";

type CardType = "virtual" | "physical";

const CardsScreen = () => {
  const navigation = useNavigation();
  const [revealCard, setRevealCard] = useState(false);
  const [revealCvv, setRevealCvv] = useState(false);
  const [cardType, setCardType] = useState<CardType>("virtual");

  // Fund card modal state
  const [fundModalVisible, setFundModalVisible] = useState(false);
  const [fundAmountUsd, setFundAmountUsd] = useState("");

  // ─── Fetch card details ───────────────────────────────────────
  const {
    data: getCardDetails,
    isLoading,
    isError,
    refetch,
  } = useFetchData_v2("account/getCardDetails", "getCardDetails");

  // ─── Fetch exchange rate ──────────────────────────────────────
  const { data: getRates, isLoading: ratesLoading } = useFetchData_v2(
    "account/getRates",
    "getRates",
  );

  const card = getCardDetails?.data?.data;
  const hasCard = !!card;
  const rate: number = getRates?.data?.data?.result ?? null;

  // NGN equivalent of USD amount entered
  const usdAmount = parseFloat(fundAmountUsd) || 0;
  const ngnEquivalent = rate
    ? (usdAmount * rate).toLocaleString("en-NG", { minimumFractionDigits: 2 })
    : "—";

  // ─── Purchase card ────────────────────────────────────────────
  const { mutate: purchaseCard, isPending: purchasing } = useMutateData_v2(
    "account/createUsdCard",
    "POST",
    "getCardDetails",
    {
      onSuccess: () => {
        Alert.alert(
          "Success",
          `Your ${cardType === "virtual" ? "Virtual" : "Physical"} Card is being processed. Details will be sent to your email.`,
          [{ text: "OK" }],
        );
        refetch();
      },
      onError: (error: any) => {
        Alert.alert("Error", error?.data?.message || "Failed to purchase card");
      },
    },
  );

  // ─── Fund card ────────────────────────────────────────────────
  const { mutate: fundCard, isPending: funding } = useMutateData_v2(
    "account/fundUsdCard",
    "POST",
    "getCardDetails",
    {
      onSuccess: () => {
        setFundModalVisible(false);
        setFundAmountUsd("");
        Alert.alert("Success", "Card funded successfully!");
        refetch();
      },
      onError: (error: any) => {
        Alert.alert("Error", error?.data?.message || "Failed to fund card");
      },
    },
  );

  const handlePurchase = () => {
    Alert.alert(
      "Confirm Purchase",
      `Purchase a ${cardType === "virtual" ? "Virtual" : "Physical"} Card for ${cardType === "virtual" ? "₦500.00" : "₦2,000.00"}?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Confirm",
          onPress: () => purchaseCard({ cardType: cardType.toUpperCase() }),
        },
      ],
    );
  };

  const handleFundCard = () => {
    if (!fundAmountUsd || usdAmount <= 0) {
      Alert.alert("Error", "Enter a valid USD amount");
      return;
    }
    Alert.alert(
      "Confirm Fund",
      `Fund card with $${usdAmount} USD (≈ ₦${ngnEquivalent})?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Confirm",
          onPress: () => fundCard({ amountInUsd: usdAmount }),
        },
      ],
    );
  };

  const copyToClipboard = (value: string, label: string) => {
    Clipboard.setString(value);
    Alert.alert("Copied", `${label} copied to clipboard`);
  };

  const formatCardNumber = (num: string) =>
    num.replace(/(.{4})/g, "$1 ").trim();

  const getStatusColor = (status: string) => {
    switch (status?.toUpperCase()) {
      case "ACTIVE":
        return { bg: "#f0fdf7", text: "#059669", border: "#6ee7b7" };
      case "INACTIVE":
        return { bg: "#fef9ec", text: "#b45309", border: "#fcd34d" };
      case "BLOCKED":
        return { bg: "#fff0f0", text: "#dc2626", border: "#fca5a5" };
      default:
        return { bg: "#f5f5f5", text: "#666", border: "#e5e5e5" };
    }
  };

  // ─── Loading ──────────────────────────────────────────────────
  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <Header onBack={() => navigation.goBack()} title="My Card" />
        <View style={styles.centeredState}>
          <ActivityIndicator size="large" color="#1a1a2e" />
          <Text style={styles.stateText}>Loading card details...</Text>
        </View>
      </SafeAreaView>
    );
  }

  // ─── Error ────────────────────────────────────────────────────
  if (isError) {
    return (
      <SafeAreaView style={styles.container}>
        <Header onBack={() => navigation.goBack()} title="My Card" />
        <View style={styles.centeredState}>
          <Ionicons name="alert-circle-outline" size={48} color="#ef4444" />
          <Text style={styles.stateText}>Failed to load card details</Text>
          <TouchableOpacity
            style={styles.retryButton}
            onPress={() => refetch()}
          >
            <Text style={styles.retryText}>Try Again</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // NO CARD — Purchase Flow
  // ═══════════════════════════════════════════════════════════════
  if (!hasCard) {
    return (
      <SafeAreaView style={styles.container}>
        <Header onBack={() => navigation.goBack()} title="Get a Card" />

        <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
          {/* Mock Card Preview */}
          <View style={styles.cardVisual}>
            <View style={styles.cardTopRow}>
              <View>
                <Text style={styles.cardBrand}>
                  {cardType === "virtual" ? "VISA" : "MASTERCARD"}
                </Text>
                <Text style={styles.cardTypeLabel}>
                  {cardType.toUpperCase()} CARD
                </Text>
              </View>
              <View
                style={[
                  styles.statusBadge,
                  { backgroundColor: "#1e3a2e", borderColor: "#2d5a40" },
                ]}
              >
                <View
                  style={[styles.statusDot, { backgroundColor: "#10b981" }]}
                />
                <Text style={[styles.statusText, { color: "#10b981" }]}>
                  NGN
                </Text>
              </View>
            </View>
            <View style={styles.cardNumberSection}>
              <Text style={styles.cardFieldLabel}>CARD NUMBER</Text>
              <Text style={styles.cardNumber}>•••• •••• •••• ••••</Text>
            </View>
            <View style={styles.cardBottomRow}>
              <View>
                <Text style={styles.cardFieldLabel}>CARD HOLDER</Text>
                <Text style={styles.cardFieldValue}>YOUR NAME</Text>
              </View>
              <View>
                <Text style={styles.cardFieldLabel}>EXPIRES</Text>
                <Text style={styles.cardFieldValue}>MM/YY</Text>
              </View>
              <View>
                <Text style={styles.cardFieldLabel}>CVV</Text>
                <Text style={styles.cardFieldValue}>•••</Text>
              </View>
            </View>
          </View>

          {/* Exchange Rate Banner */}
          <View style={styles.rateBanner}>
            <Ionicons name="trending-up-outline" size={16} color="#059669" />
            {ratesLoading ? (
              <ActivityIndicator size="small" color="#059669" />
            ) : rate ? (
              <Text style={styles.rateText}>
                Current Rate:{" "}
                <Text style={styles.rateValue}>
                  $1 = ₦
                  {rate.toLocaleString("en-NG", { minimumFractionDigits: 2 })}
                </Text>
              </Text>
            ) : (
              <Text style={styles.rateText}>Rate unavailable</Text>
            )}
          </View>

          {/* Card Type Selection */}
          <Text style={styles.sectionLabel}>Card Type</Text>
          <View style={styles.cardTypeContainer}>
            <TouchableOpacity
              style={[
                styles.cardTypeOption,
                cardType === "virtual" && styles.cardTypeSelected,
              ]}
              onPress={() => setCardType("virtual")}
            >
              <View style={styles.cardTypeIconWrap}>
                <Ionicons
                  name="phone-portrait-outline"
                  size={22}
                  color={cardType === "virtual" ? "#1a1a2e" : "#bbb"}
                />
              </View>
              <Text
                style={[
                  styles.cardTypeTitle,
                  cardType === "virtual" && styles.cardTypeTitleSelected,
                ]}
              >
                Virtual Card
              </Text>
              <Text style={styles.cardTypeSubtitle}>Instant delivery</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.cardTypeOption,
                cardType === "physical" && styles.cardTypeSelected,
              ]}
              onPress={() => setCardType("physical")}
            >
              <View style={styles.cardTypeIconWrap}>
                <Ionicons
                  name="card-outline"
                  size={22}
                  color={cardType === "physical" ? "#1a1a2e" : "#bbb"}
                />
              </View>
              <Text
                style={[
                  styles.cardTypeTitle,
                  cardType === "physical" && styles.cardTypeTitleSelected,
                ]}
              >
                Physical Card
              </Text>
              <Text style={styles.cardTypeSubtitle}>7–14 days delivery</Text>
            </TouchableOpacity>
          </View>

          {/* Currency */}
          <Text style={styles.sectionLabel}>Currency</Text>
          <View style={styles.currencySelector}>
            <View style={styles.currencyLeft}>
              <View style={styles.currencyFlag}>
                <Text style={{ fontSize: 18 }}>🇳🇬</Text>
              </View>
              <Text style={styles.currencyText}>Nigerian Naira (NGN)</Text>
            </View>
            <Ionicons name="checkmark-circle" size={20} color="#10b981" />
          </View>

          {/* Fee Breakdown */}
          <Text style={styles.sectionLabel}>Fee Breakdown</Text>
          <View style={styles.feeContainer}>
            <View style={styles.feeRow}>
              <Text style={styles.feeLabel}>Card Fee</Text>
              <Text style={styles.feeValue}>₦500.00</Text>
            </View>
            <View style={styles.feeRow}>
              <Text style={styles.feeLabel}>Initial Load</Text>
              <Text style={styles.feeValue}>₦0.00</Text>
            </View>
            {cardType === "physical" && (
              <View style={styles.feeRow}>
                <Text style={styles.feeLabel}>Delivery Fee</Text>
                <Text style={styles.feeValue}>₦1,500.00</Text>
              </View>
            )}
            {rate && (
              <View style={styles.feeRow}>
                <Text style={styles.feeLabel}>Exchange Rate</Text>
                <Text style={[styles.feeValue, { color: "#059669" }]}>
                  $1 = ₦
                  {rate.toLocaleString("en-NG", { minimumFractionDigits: 2 })}
                </Text>
              </View>
            )}
            <View style={styles.feeDivider} />
            <View style={styles.feeRow}>
              <Text style={styles.totalLabel}>Total</Text>
              <Text style={styles.totalValue}>
                {cardType === "virtual" ? "₦500.00" : "₦2,000.00"}
              </Text>
            </View>
          </View>

          {/* Purchase Button */}
          <TouchableOpacity
            style={[styles.purchaseButton, purchasing && styles.buttonDisabled]}
            onPress={handlePurchase}
            disabled={purchasing}
          >
            {purchasing ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <>
                <Ionicons name="card-outline" size={20} color="#fff" />
                <Text style={styles.purchaseButtonText}>
                  Purchase {cardType === "virtual" ? "Virtual" : "Physical"}{" "}
                  Card
                </Text>
              </>
            )}
          </TouchableOpacity>

          <Text style={styles.termsText}>
            By purchasing a card, you agree to our terms and conditions. Card
            details will be sent to your email once processed.
          </Text>
          <View style={{ height: 40 }} />
        </ScrollView>
      </SafeAreaView>
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // HAS CARD — Card Details View
  // ═══════════════════════════════════════════════════════════════
  const statusColors = getStatusColor(card.status);

  return (
    <SafeAreaView style={styles.container}>
      <Header onBack={() => navigation.goBack()} title="My Card" />

      <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
        {/* ── Card Visual ──────────────────────────────────── */}
        <View style={styles.cardVisual}>
          <View style={styles.cardTopRow}>
            <View>
              <Text style={styles.cardBrand}>{card.brand}</Text>
              <Text style={styles.cardTypeLabel}>{card.cardType} CARD</Text>
            </View>
            <View
              style={[
                styles.statusBadge,
                {
                  backgroundColor: statusColors.bg,
                  borderColor: statusColors.border,
                },
              ]}
            >
              <View
                style={[
                  styles.statusDot,
                  { backgroundColor: statusColors.text },
                ]}
              />
              <Text style={[styles.statusText, { color: statusColors.text }]}>
                {card.status}
              </Text>
            </View>
          </View>

          <View style={styles.cardNumberSection}>
            <Text style={styles.cardFieldLabel}>CARD NUMBER</Text>
            <View style={styles.cardNumberRow}>
              <Text style={styles.cardNumber}>
                {revealCard
                  ? formatCardNumber(card.cardNumber)
                  : card.maskedPan?.replace(/\*/g, "•")}
              </Text>
              <View style={styles.cardNumberActions}>
                <TouchableOpacity
                  style={styles.cardActionBtn}
                  onPress={() => setRevealCard(!revealCard)}
                >
                  <Ionicons
                    name={revealCard ? "eye-off-outline" : "eye-outline"}
                    size={16}
                    color="#8b8b9e"
                  />
                </TouchableOpacity>
                {revealCard && (
                  <TouchableOpacity
                    style={styles.cardActionBtn}
                    onPress={() =>
                      copyToClipboard(card.cardNumber, "Card number")
                    }
                  >
                    <Ionicons name="copy-outline" size={16} color="#8b8b9e" />
                  </TouchableOpacity>
                )}
              </View>
            </View>
          </View>

          <View style={styles.cardBottomRow}>
            <View>
              <Text style={styles.cardFieldLabel}>CARD HOLDER</Text>
              <Text style={styles.cardFieldValue}>{card.displayName}</Text>
            </View>
            <View>
              <Text style={styles.cardFieldLabel}>EXPIRES</Text>
              <Text style={styles.cardFieldValue}>{card.expirationDate}</Text>
            </View>
            <View>
              <Text style={styles.cardFieldLabel}>CVV</Text>
              <TouchableOpacity onPress={() => setRevealCvv(!revealCvv)}>
                <Text style={styles.cardFieldValue}>
                  {revealCvv ? card.cvv : "•••"}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* ── Balance + Fund Row ────────────────────────────── */}
        <View style={styles.balanceCard}>
          <View style={styles.balanceItem}>
            <Text style={styles.balanceLabel}>Balance</Text>
            <Text style={styles.balanceValue}>
              $
              {parseFloat(card.balance || "0").toLocaleString("en-NG", {
                minimumFractionDigits: 2,
              })}
            </Text>
            {rate && (
              <Text style={styles.balanceSubtext}>
                ≈ ₦
                {(parseFloat(card.balance || "0") * rate).toLocaleString(
                  "en-NG",
                  { minimumFractionDigits: 2 },
                )}
              </Text>
            )}
          </View>
          <View style={styles.balanceDivider} />
          <View style={styles.balanceItem}>
            <Text style={styles.balanceLabel}>Rate</Text>
            {ratesLoading ? (
              <ActivityIndicator size="small" color="#1a1a2e" />
            ) : (
              <>
                <Text style={styles.balanceValue}>${"1"}</Text>
                <Text style={styles.balanceSubtext}>
                  = ₦
                  {rate
                    ? rate.toLocaleString("en-NG", { minimumFractionDigits: 2 })
                    : "—"}
                </Text>
              </>
            )}
          </View>
        </View>

        {/* ── Fund Card Button ─────────────────────────────── */}
        <TouchableOpacity
          style={styles.fundButton}
          onPress={() => navigation.navigate("CardTransactions" as never)}
        >
          <Ionicons name="add-circle-outline" size={20} color="#fff" />
          <Text>View Transactions</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.fundButton}
          onPress={() => setFundModalVisible(true)}
        >
          <Ionicons name="add-circle-outline" size={20} color="#fff" />
          <Text style={styles.fundButtonText}>Fund Card</Text>
        </TouchableOpacity>

        {/* ── Card Details ─────────────────────────────────── */}
        <View style={styles.detailsCard}>
          <Text style={styles.sectionTitle}>Card Details</Text>
          <DetailRow
            icon="person-outline"
            label="Card Holder"
            value={card.displayName}
          />
          <DetailRow
            icon="card-outline"
            label="Card Brand"
            value={card.brand}
          />
          <DetailRow
            icon="layers-outline"
            label="Card Type"
            value={card.cardType}
          />
          <DetailRow
            icon="calendar-outline"
            label="Expiration"
            value={card.expirationDate}
          />
          <DetailRow
            icon="time-outline"
            label="Created"
            value={new Date(card.createdAt).toLocaleDateString("en-NG", {
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          />
          <DetailRow
            icon="refresh-outline"
            label="Last Updated"
            value={new Date(card.updatedAt).toLocaleDateString("en-NG", {
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
            isLast
          />
        </View>

        {/* ── Billing Address ───────────────────────────────── */}
        <View style={styles.detailsCard}>
          <Text style={styles.sectionTitle}>Billing Address</Text>
          <DetailRow
            icon="location-outline"
            label="Address"
            value={card.addressLine1}
          />
          <DetailRow
            icon="business-outline"
            label="City"
            value={`${card.city}, ${card.state}`}
          />
          <DetailRow
            icon="mail-outline"
            label="Postal Code"
            value={card.postalCode}
          />
          <DetailRow
            icon="globe-outline"
            label="Country"
            value={card.country}
            isLast
          />
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>

      {/* ── Fund Card Modal ───────────────────────────────── */}
      <Modal
        visible={fundModalVisible}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setFundModalVisible(false)}
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Fund Card</Text>
            <TouchableOpacity
              onPress={() => {
                setFundModalVisible(false);
                setFundAmountUsd("");
              }}
            >
              <Ionicons name="close" size={24} color="#1a1a2e" />
            </TouchableOpacity>
          </View>

          <ScrollView
            style={styles.modalContent}
            keyboardShouldPersistTaps="handled"
          >
            {/* Rate info */}
            <View style={styles.rateInfoCard}>
              <Ionicons name="trending-up-outline" size={18} color="#059669" />
              <View style={{ flex: 1 }}>
                <Text style={styles.rateInfoLabel}>Current Exchange Rate</Text>
                {ratesLoading ? (
                  <ActivityIndicator size="small" color="#059669" />
                ) : (
                  <Text style={styles.rateInfoValue}>
                    $1 USD = ₦
                    {rate
                      ? rate.toLocaleString("en-NG", {
                          minimumFractionDigits: 2,
                        })
                      : "—"}
                  </Text>
                )}
              </View>
            </View>

            {/* Amount input */}
            <Text style={styles.inputLabel}>Amount (USD)</Text>
            <View style={styles.amountInputWrap}>
              <Text style={styles.currencySymbol}>$</Text>
              <TextInput
                style={styles.amountInput}
                placeholder="0.00"
                placeholderTextColor="#bbb"
                keyboardType="decimal-pad"
                value={fundAmountUsd}
                onChangeText={setFundAmountUsd}
                autoFocus
              />
            </View>

            {/* NGN equivalent */}
            {usdAmount > 0 && (
              <View style={styles.conversionRow}>
                <Ionicons
                  name="swap-horizontal-outline"
                  size={14}
                  color="#999"
                />
                <Text style={styles.conversionText}>
                  You'll be charged{" "}
                  <Text style={styles.conversionAmount}>₦{ngnEquivalent}</Text>{" "}
                  from your wallet
                </Text>
              </View>
            )}

            {/* Quick amounts */}
            <Text style={styles.inputLabel}>Quick Amount</Text>
            <View style={styles.quickAmounts}>
              {["10", "25", "50", "100"].map((amt) => (
                <TouchableOpacity
                  key={amt}
                  style={[
                    styles.quickAmountBtn,
                    fundAmountUsd === amt && styles.quickAmountSelected,
                  ]}
                  onPress={() => setFundAmountUsd(amt)}
                >
                  <Text
                    style={[
                      styles.quickAmountText,
                      fundAmountUsd === amt && styles.quickAmountTextSelected,
                    ]}
                  >
                    ${amt}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Fund button */}
            <TouchableOpacity
              style={[
                styles.fundSubmitButton,
                (!fundAmountUsd || usdAmount <= 0 || funding) &&
                  styles.buttonDisabled,
              ]}
              onPress={handleFundCard}
              disabled={!fundAmountUsd || usdAmount <= 0 || funding}
            >
              {funding ? (
                <ActivityIndicator color="#fff" size="small" />
              ) : (
                <>
                  <Ionicons name="add-circle-outline" size={18} color="#fff" />
                  <Text style={styles.fundSubmitText}>
                    Fund ${fundAmountUsd || "0"} to Card
                  </Text>
                </>
              )}
            </TouchableOpacity>

            <Text style={styles.termsText}>
              Funds will be deducted from your NGN wallet at the current
              exchange rate.
            </Text>
          </ScrollView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
};

// ── Header ─────────────────────────────────────────────────────────
const Header = ({ onBack, title }: { onBack: () => void; title: string }) => (
  <View style={styles.header}>
    <TouchableOpacity
      style={styles.backButton}
      onPress={onBack}
      hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
    >
      <Ionicons name="arrow-back" size={24} color="#1a1a2e" />
    </TouchableOpacity>
    <Text style={styles.headerTitle}>{title}</Text>
    <View style={{ width: 40 }} />
  </View>
);

// ── DetailRow ──────────────────────────────────────────────────────
const DetailRow = ({
  icon,
  label,
  value,
  isLast,
}: {
  icon: any;
  label: string;
  value: string;
  isLast?: boolean;
}) => (
  <View style={[styles.detailRow, !isLast && styles.detailRowBorder]}>
    <View style={styles.detailIconWrap}>
      <Ionicons name={icon} size={15} color="#666" />
    </View>
    <View style={styles.detailContent}>
      <Text style={styles.detailLabel}>{label}</Text>
      <Text style={styles.detailValue}>{value || "—"}</Text>
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f5f5f5" },

  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e5e5",
    backgroundColor: "#fff",
  },
  headerTitle: { fontSize: 18, fontWeight: "700", color: "#1a1a2e" },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },

  centeredState: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    gap: 12,
    paddingHorizontal: 32,
  },
  stateText: { fontSize: 14, color: "#666", textAlign: "center" },
  retryButton: {
    backgroundColor: "#1a1a2e",
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 10,
  },
  retryText: { color: "#fff", fontWeight: "600", fontSize: 14 },

  content: { flex: 1, padding: 16 },

  // ── Card Visual ─────────────────────────────────────────────
  cardVisual: {
    backgroundColor: "#1a1a2e",
    borderRadius: 20,
    padding: 22,
    marginBottom: 16,
    shadowColor: "#1a1a2e",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 8,
  },
  cardTopRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 28,
  },
  cardBrand: {
    fontSize: 20,
    fontWeight: "800",
    color: "#fff",
    letterSpacing: 1,
  },
  cardTypeLabel: {
    fontSize: 10,
    color: "#8b8b9e",
    letterSpacing: 1.5,
    marginTop: 2,
  },
  statusBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
    borderWidth: 1,
  },
  statusDot: { width: 6, height: 6, borderRadius: 3 },
  statusText: { fontSize: 11, fontWeight: "700", letterSpacing: 0.5 },
  cardNumberSection: { marginBottom: 28 },
  cardFieldLabel: {
    fontSize: 9,
    color: "#8b8b9e",
    letterSpacing: 1.5,
    marginBottom: 6,
    fontWeight: "600",
  },
  cardNumberRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  cardNumber: {
    fontSize: 17,
    color: "#fff",
    fontWeight: "600",
    letterSpacing: 2,
    flex: 1,
  },
  cardNumberActions: { flexDirection: "row", gap: 8 },
  cardActionBtn: {
    width: 28,
    height: 28,
    borderRadius: 8,
    backgroundColor: "rgba(255,255,255,0.1)",
    justifyContent: "center",
    alignItems: "center",
  },
  cardBottomRow: { flexDirection: "row", justifyContent: "space-between" },
  cardFieldValue: { fontSize: 14, color: "#fff", fontWeight: "600" },

  // ── Rate Banner (purchase flow) ──────────────────────────────
  rateBanner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "#f0fdf7",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#6ee7b7",
    paddingHorizontal: 14,
    paddingVertical: 10,
    marginBottom: 4,
  },
  rateText: { fontSize: 13, color: "#555", fontWeight: "500" },
  rateValue: { fontWeight: "700", color: "#059669" },

  // ── Balance Card ────────────────────────────────────────────
  balanceCard: {
    backgroundColor: "#fff",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    flexDirection: "row",
    marginBottom: 12,
    overflow: "hidden",
  },
  balanceItem: { flex: 1, padding: 16, alignItems: "center" },
  balanceDivider: { width: 1, backgroundColor: "#f0f0f0" },
  balanceLabel: {
    fontSize: 11,
    color: "#999",
    fontWeight: "600",
    textTransform: "uppercase",
    letterSpacing: 0.5,
    marginBottom: 4,
  },
  balanceValue: { fontSize: 18, fontWeight: "700", color: "#1a1a2e" },
  balanceSubtext: {
    fontSize: 11,
    color: "#059669",
    fontWeight: "500",
    marginTop: 2,
  },

  // ── Fund Button ─────────────────────────────────────────────
  fundButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    backgroundColor: "#10b981",
    height: 50,
    borderRadius: 14,
    marginBottom: 16,
  },
  fundButtonText: { color: "#fff", fontSize: 15, fontWeight: "700" },

  // ── Details Card ────────────────────────────────────────────
  detailsCard: {
    backgroundColor: "#fff",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    marginBottom: 16,
    overflow: "hidden",
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: "700",
    color: "#999",
    textTransform: "uppercase",
    letterSpacing: 0.6,
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 12,
  },
  detailRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  detailRowBorder: { borderBottomWidth: 1, borderBottomColor: "#f0f0f0" },
  detailIconWrap: {
    width: 30,
    height: 30,
    borderRadius: 8,
    backgroundColor: "#f5f7fa",
    justifyContent: "center",
    alignItems: "center",
  },
  detailContent: { flex: 1 },
  detailLabel: {
    fontSize: 11,
    fontWeight: "600",
    color: "#999",
    textTransform: "uppercase",
    letterSpacing: 0.4,
    marginBottom: 2,
  },
  detailValue: { fontSize: 14, color: "#1a1a2e", fontWeight: "500" },

  // ── Purchase Flow ────────────────────────────────────────────
  sectionLabel: {
    fontSize: 14,
    fontWeight: "600",
    color: "#1a1a2e",
    marginTop: 20,
    marginBottom: 10,
  },
  cardTypeContainer: { flexDirection: "row", gap: 12, marginBottom: 4 },
  cardTypeOption: {
    flex: 1,
    paddingVertical: 16,
    paddingHorizontal: 12,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    alignItems: "center",
    gap: 6,
    backgroundColor: "#fff",
  },
  cardTypeSelected: {
    borderColor: "#1a1a2e",
    borderWidth: 2,
    backgroundColor: "#f8f9ff",
  },
  cardTypeIconWrap: { marginBottom: 2 },
  cardTypeTitle: { fontSize: 14, fontWeight: "600", color: "#bbb" },
  cardTypeTitleSelected: { color: "#1a1a2e" },
  cardTypeSubtitle: { fontSize: 11, color: "#bbb" },
  currencySelector: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    backgroundColor: "#fff",
  },
  currencyLeft: { flexDirection: "row", alignItems: "center", gap: 10 },
  currencyFlag: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: "#f5f5f5",
    justifyContent: "center",
    alignItems: "center",
  },
  currencyText: { fontSize: 15, fontWeight: "500", color: "#1a1a2e" },
  feeContainer: {
    padding: 16,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    backgroundColor: "#fff",
  },
  feeRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  feeLabel: { fontSize: 14, color: "#666" },
  feeValue: { fontSize: 14, color: "#1a1a2e", fontWeight: "500" },
  feeDivider: { height: 1, backgroundColor: "#f0f0f0", marginVertical: 8 },
  totalLabel: { fontSize: 15, fontWeight: "700", color: "#1a1a2e" },
  totalValue: { fontSize: 15, fontWeight: "700", color: "#1a1a2e" },
  purchaseButton: {
    backgroundColor: "#1a1a2e",
    height: 56,
    borderRadius: 12,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 8,
    marginTop: 24,
  },
  buttonDisabled: { opacity: 0.6 },
  purchaseButtonText: { color: "#fff", fontSize: 16, fontWeight: "600" },
  termsText: {
    fontSize: 12,
    color: "#999",
    textAlign: "center",
    lineHeight: 18,
    marginTop: 16,
  },

  // ── Fund Modal ───────────────────────────────────────────────
  modalContainer: { flex: 1, backgroundColor: "#fff" },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e5e5",
  },
  modalTitle: { fontSize: 18, fontWeight: "700", color: "#1a1a2e" },
  modalContent: { padding: 20 },
  rateInfoCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    backgroundColor: "#f0fdf7",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#6ee7b7",
    padding: 14,
    marginBottom: 24,
  },
  rateInfoLabel: {
    fontSize: 11,
    color: "#666",
    fontWeight: "600",
    textTransform: "uppercase",
    letterSpacing: 0.4,
    marginBottom: 2,
  },
  rateInfoValue: { fontSize: 15, fontWeight: "700", color: "#059669" },
  inputLabel: {
    fontSize: 13,
    fontWeight: "600",
    color: "#555",
    textTransform: "uppercase",
    letterSpacing: 0.5,
    marginBottom: 8,
  },
  amountInputWrap: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f5f7fa",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    paddingHorizontal: 16,
    paddingVertical: 14,
    marginBottom: 10,
  },
  currencySymbol: {
    fontSize: 22,
    fontWeight: "700",
    color: "#1a1a2e",
    marginRight: 8,
  },
  amountInput: {
    flex: 1,
    fontSize: 28,
    fontWeight: "700",
    color: "#1a1a2e",
    padding: 0,
  },
  conversionRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: "#f9fafb",
    borderRadius: 8,
    padding: 10,
    marginBottom: 20,
  },
  conversionText: { fontSize: 13, color: "#666", flex: 1 },
  conversionAmount: { fontWeight: "700", color: "#1a1a2e" },
  quickAmounts: { flexDirection: "row", gap: 10, marginBottom: 28 },
  quickAmountBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  quickAmountSelected: {
    borderColor: "#1a1a2e",
    backgroundColor: "#f8f9ff",
    borderWidth: 2,
  },
  quickAmountText: { fontSize: 14, fontWeight: "600", color: "#bbb" },
  quickAmountTextSelected: { color: "#1a1a2e" },
  fundSubmitButton: {
    backgroundColor: "#10b981",
    height: 54,
    borderRadius: 12,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 8,
  },
  fundSubmitText: { color: "#fff", fontSize: 16, fontWeight: "700" },
});

export default CardsScreen;
