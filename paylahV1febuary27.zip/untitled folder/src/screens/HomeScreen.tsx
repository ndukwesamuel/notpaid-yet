// // import React, { useEffect, useState } from "react";
// // import {
// //   View,
// //   Text,
// //   StyleSheet,
// //   TouchableOpacity,
// //   ScrollView,
// //   StatusBar,
// // } from "react-native";
// // import { SafeAreaView } from "react-native-safe-area-context";
// // import { Ionicons, MaterialCommunityIcons, Feather } from "@expo/vector-icons";
// // import { useDispatch, useSelector } from "react-redux";
// // import { useNavigation } from "@react-navigation/native";

// // import AddMoneyModal from "../components/AddMoneyModal";
// // import SendMoneyModal from "../components/Sendmoneymodal";
// // import { setAccountDetails, setUserDetails } from "../redux/Authslice"; //"../redux/authSlice"; // adjust path
// // import { useFetchData_v2 } from "../hooks/Requestv2";
// // // import { useFetchData_v2 } from "../../hooks/Requestv2"; // adjust path
// // const HomeScreen = () => {
// //   const [addMoneyVisible, setAddMoneyVisible] = useState(false);
// //   const [sendMoneyVisible, setSendMoneyVisible] = useState(false);
// //   const [balanceVisible, setBalanceVisible] = useState(true);

// //   const navigation = useNavigation();
// //   const dispatch = useDispatch();

// //   // ─── Read from Redux (available anywhere in app after first fetch) ──
// //   const accountDetails = useSelector(
// //     (state: any) => state.authSlice.accountDetails,
// //   );
// //   const userDetails = useSelector((state: any) => state.authSlice.userDetails);

// //   const { data: accountData, isSuccess: accountSuccess } = useFetchData_v2(
// //     "account/getAccountDetails",
// //     "accountDetails",
// //   );

// //   // ─── Fetch current user details ───────────────────────────────
// //   const { data: userData, isSuccess: userSuccess } = useFetchData_v2(
// //     "users/user",
// //     "userDetails",
// //   );

// //   console.log({
// //     yui: userData?.data?.user,
// //   });

// //   // ─── Dispatch account details into Redux ──────────────────────
// //   useEffect(() => {
// //     if (accountSuccess && accountData?.data?.customer) {
// //       dispatch(setAccountDetails(accountData.data.customer));
// //     }
// //   }, [accountSuccess, accountData]);

// //   // ─── Dispatch user details into Redux ─────────────────────────
// //   useEffect(() => {
// //     if (userSuccess && userData?.data) {
// //       dispatch(setUserDetails(userData.data.user));
// //     }
// //   }, [userSuccess, userData]);

// //   // ─── Get user initials for avatar ─────────────────────────────
// //   const getInitials = () => {
// //     if (!userDetails) return "EI";
// //     const first = userDetails?.firstName?.[0] || "";
// //     const last = userDetails?.lastName?.[0] || "";
// //     return `${first}${last}`.toUpperCase() || "EI";
// //   };

// //   return (
// //     <SafeAreaView style={styles.container}>
// //       <StatusBar barStyle="dark-content" backgroundColor="#fff" />
// //       <ScrollView showsVerticalScrollIndicator={false}>
// //         {/* Header */}
// //         <View style={styles.header}>
// //           <TouchableOpacity style={styles.iconButton}>
// //             <Ionicons name="chatbubble-outline" size={22} color="#1a1a2e" />
// //           </TouchableOpacity>
// //           <TouchableOpacity
// //             style={styles.avatarButton}
// //             onPress={() => navigation.navigate("More" as never)}
// //           >
// //             <Text style={styles.avatarText}>{getInitials()}</Text>
// //           </TouchableOpacity>
// //         </View>

// //         {/* ID Verification Banner */}
// //         <View style={styles.verificationBanner}>
// //           <Text style={styles.verificationLabel}>ID VERIFICATION</Text>
// //           <Text style={styles.verificationText}>
// //             Verify your ID to finish setting up your account
// //           </Text>
// //           <TouchableOpacity style={styles.beginButton}>
// //             <Text style={styles.beginButtonText}>Begin</Text>
// //           </TouchableOpacity>
// //         </View>

// //         {/* Currency & Balance Section */}
// //         <View style={styles.balanceSection}>
// //           <TouchableOpacity style={styles.currencySelector}>
// //             <Text style={styles.flagEmoji}>🇳🇬</Text>
// //             <Text style={styles.currencyText}>Nigerian Naira</Text>
// //             <Ionicons name="chevron-down" size={18} color="#666" />
// //           </TouchableOpacity>

// //           <View style={styles.balanceRow}>
// //             <Text style={styles.balanceAmount}>
// //               {balanceVisible
// //                 ? `₦${userDetails?.virtualAccountBalance}`
// //                 : "₦ ••••••"}
// //             </Text>
// //             <TouchableOpacity
// //               style={styles.eyeButton}
// //               onPress={() => setBalanceVisible((prev) => !prev)}
// //             >
// //               <Ionicons
// //                 name={balanceVisible ? "eye-outline" : "eye-off-outline"}
// //                 size={16}
// //                 color="#666"
// //               />
// //             </TouchableOpacity>
// //           </View>
// //         </View>

// //         {/* Get Bank Account Card */}
// //         <TouchableOpacity
// //           style={styles.bankAccountCard}
// //           onPress={() => navigation.navigate("AccountDetails")}
// //         >
// //           <View style={styles.bankIconContainer}>
// //             <MaterialCommunityIcons
// //               name="bank-outline"
// //               size={22}
// //               color="#666"
// //             />
// //           </View>
// //           <Text style={styles.bankAccountText}>Get your Bank Account</Text>
// //           <Ionicons name="chevron-forward" size={20} color="#999" />
// //         </TouchableOpacity>

// //         {/* Quick Actions */}
// //         <View style={styles.quickActions}>
// //           <TouchableOpacity
// //             style={styles.actionItem}
// //             onPress={() => setAddMoneyVisible(true)}
// //           >
// //             <View style={styles.actionIconContainer}>
// //               <Feather name="plus" size={26} color="#1a1a2e" />
// //             </View>
// //             <Text style={styles.actionLabel}>Add Money</Text>
// //           </TouchableOpacity>

// //           <TouchableOpacity
// //             style={styles.actionItem}
// //             onPress={() => setSendMoneyVisible(true)}
// //           >
// //             <View style={styles.actionIconContainer}>
// //               <Ionicons name="send" size={22} color="#1a1a2e" />
// //             </View>
// //             <Text style={styles.actionLabel}>Send</Text>
// //           </TouchableOpacity>

// //           <TouchableOpacity style={styles.actionItem}>
// //             <View style={styles.actionIconContainer}>
// //               <Ionicons name="swap-horizontal" size={24} color="#1a1a2e" />
// //             </View>
// //             <Text style={styles.actionLabel}>Convert</Text>
// //           </TouchableOpacity>
// //         </View>

// //         {/* Recommended Section */}
// //         <Text style={styles.sectionTitle}>Recommended</Text>
// //         <View style={styles.recommendedGrid}>
// //           <TouchableOpacity style={styles.recommendedCard}>
// //             <View style={styles.recommendedIconContainer}>
// //               <MaterialCommunityIcons
// //                 name="lightning-bolt"
// //                 size={22}
// //                 color="#fff"
// //               />
// //             </View>
// //             <Text style={styles.recommendedLabel}>Bills & Airtime</Text>
// //             <Ionicons
// //               name="chevron-forward"
// //               size={16}
// //               color="#999"
// //               style={styles.recommendedArrow}
// //             />
// //           </TouchableOpacity>

// //           <TouchableOpacity style={styles.recommendedCard}>
// //             <View style={styles.recommendedIconContainer}>
// //               <Feather name="gift" size={20} color="#fff" />
// //             </View>
// //             <Text style={styles.recommendedLabel}>Gift Cards</Text>
// //             <Ionicons
// //               name="chevron-forward"
// //               size={16}
// //               color="#999"
// //               style={styles.recommendedArrow}
// //             />
// //           </TouchableOpacity>

// //           <TouchableOpacity style={styles.recommendedCard}>
// //             <View style={styles.recommendedIconContainer}>
// //               <Ionicons name="document-text-outline" size={20} color="#fff" />
// //             </View>
// //             <Text style={styles.recommendedLabel}>Invoice</Text>
// //           </TouchableOpacity>
// //         </View>
// //       </ScrollView>

// //       {/* Modals */}
// //       <AddMoneyModal
// //         visible={addMoneyVisible}
// //         onClose={() => setAddMoneyVisible(false)}
// //       />
// //       <SendMoneyModal
// //         visible={sendMoneyVisible}
// //         onClose={() => setSendMoneyVisible(false)}
// //       />
// //     </SafeAreaView>
// //   );
// // };

// // const styles = StyleSheet.create({
// //   container: {
// //     flex: 1,
// //     backgroundColor: "#fff",
// //   },
// //   header: {
// //     flexDirection: "row",
// //     justifyContent: "space-between",
// //     alignItems: "center",
// //     paddingHorizontal: 20,
// //     paddingVertical: 12,
// //   },
// //   iconButton: {
// //     width: 44,
// //     height: 44,
// //     borderRadius: 22,
// //     backgroundColor: "#f5f5f5",
// //     justifyContent: "center",
// //     alignItems: "center",
// //   },
// //   avatarButton: {
// //     width: 44,
// //     height: 44,
// //     borderRadius: 22,
// //     backgroundColor: "#1a1a2e",
// //     justifyContent: "center",
// //     alignItems: "center",
// //   },
// //   avatarText: {
// //     color: "#fff",
// //     fontSize: 14,
// //     fontWeight: "600",
// //   },
// //   verificationBanner: {
// //     backgroundColor: "#1a1a2e",
// //     marginHorizontal: 20,
// //     borderRadius: 16,
// //     padding: 20,
// //     marginTop: 8,
// //   },
// //   verificationLabel: {
// //     color: "#8b8b9e",
// //     fontSize: 11,
// //     fontWeight: "600",
// //     letterSpacing: 1,
// //     marginBottom: 8,
// //   },
// //   verificationText: {
// //     color: "#fff",
// //     fontSize: 15,
// //     fontWeight: "500",
// //     lineHeight: 22,
// //     marginBottom: 16,
// //   },
// //   beginButton: {
// //     backgroundColor: "#fff",
// //     paddingVertical: 12,
// //     paddingHorizontal: 28,
// //     borderRadius: 8,
// //     alignSelf: "flex-start",
// //   },
// //   beginButtonText: {
// //     color: "#1a1a2e",
// //     fontSize: 14,
// //     fontWeight: "600",
// //   },
// //   balanceSection: {
// //     paddingHorizontal: 20,
// //     marginTop: 24,
// //   },
// //   currencySelector: {
// //     flexDirection: "row",
// //     alignItems: "center",
// //     gap: 8,
// //   },
// //   flagEmoji: {
// //     fontSize: 18,
// //   },
// //   currencyText: {
// //     fontSize: 15,
// //     fontWeight: "500",
// //     color: "#1a1a2e",
// //   },
// //   balanceRow: {
// //     flexDirection: "row",
// //     alignItems: "center",
// //     marginTop: 8,
// //     gap: 12,
// //   },
// //   balanceAmount: {
// //     fontSize: 32,
// //     fontWeight: "700",
// //     color: "#1a1a2e",
// //   },
// //   eyeButton: {
// //     width: 32,
// //     height: 32,
// //     borderRadius: 16,
// //     backgroundColor: "#f5f5f5",
// //     justifyContent: "center",
// //     alignItems: "center",
// //   },
// //   bankAccountCard: {
// //     flexDirection: "row",
// //     alignItems: "center",
// //     backgroundColor: "#f8f8f8",
// //     marginHorizontal: 20,
// //     marginTop: 20,
// //     padding: 16,
// //     borderRadius: 12,
// //   },
// //   bankIconContainer: {
// //     width: 40,
// //     height: 40,
// //     borderRadius: 8,
// //     backgroundColor: "#fff",
// //     justifyContent: "center",
// //     alignItems: "center",
// //     marginRight: 12,
// //   },
// //   bankAccountText: {
// //     flex: 1,
// //     fontSize: 15,
// //     fontWeight: "500",
// //     color: "#1a1a2e",
// //   },
// //   quickActions: {
// //     flexDirection: "row",
// //     justifyContent: "center",
// //     gap: 32,
// //     marginTop: 28,
// //     paddingHorizontal: 20,
// //   },
// //   actionItem: {
// //     alignItems: "center",
// //   },
// //   actionIconContainer: {
// //     width: 60,
// //     height: 60,
// //     borderRadius: 30,
// //     borderWidth: 1.5,
// //     borderColor: "#1a1a2e",
// //     justifyContent: "center",
// //     alignItems: "center",
// //     marginBottom: 10,
// //   },
// //   actionLabel: {
// //     fontSize: 13,
// //     fontWeight: "500",
// //     color: "#1a1a2e",
// //   },
// //   sectionTitle: {
// //     fontSize: 17,
// //     fontWeight: "700",
// //     color: "#1a1a2e",
// //     marginTop: 32,
// //     marginBottom: 16,
// //     paddingHorizontal: 20,
// //   },
// //   recommendedGrid: {
// //     flexDirection: "row",
// //     paddingHorizontal: 20,
// //     gap: 12,
// //     paddingBottom: 24,
// //   },
// //   recommendedCard: {
// //     flex: 1,
// //     backgroundColor: "#f5f7fa",
// //     borderRadius: 12,
// //     padding: 16,
// //     minHeight: 120,
// //   },
// //   recommendedIconContainer: {
// //     width: 40,
// //     height: 40,
// //     borderRadius: 10,
// //     backgroundColor: "#1a1a2e",
// //     justifyContent: "center",
// //     alignItems: "center",
// //     marginBottom: 12,
// //   },
// //   recommendedLabel: {
// //     fontSize: 13,
// //     fontWeight: "600",
// //     color: "#1a1a2e",
// //   },
// //   recommendedArrow: {
// //     position: "absolute",
// //     bottom: 16,
// //     right: 16,
// //   },
// // });

// // export default HomeScreen;

// import React, { useEffect, useState } from "react";
// import {
//   View,
//   Text,
//   StyleSheet,
//   TouchableOpacity,
//   ScrollView,
//   StatusBar,
// } from "react-native";
// import { SafeAreaView } from "react-native-safe-area-context";
// import { Ionicons, MaterialCommunityIcons, Feather } from "@expo/vector-icons";
// import { useDispatch, useSelector } from "react-redux";
// import { useNavigation } from "@react-navigation/native";

// import AddMoneyModal from "../components/AddMoneyModal";
// import SendMoneyModal from "../components/Sendmoneymodal";
// import { setAccountDetails, setUserDetails } from "../redux/Authslice";
// import { useFetchData_v2 } from "../hooks/Requestv2";

// // ─── Helper: Determine what verification is needed ───────────────
// const getVerificationStatus = (userDetails: any) => {
//   if (!userDetails) return null;

//   const bvnVerified = userDetails?.bvnKycStatus === true;
//   const ninVerified = userDetails?.ninKycStatus === true;

//   if (bvnVerified && ninVerified) return null; // fully verified, hide banner

//   if (!bvnVerified && !ninVerified) {
//     return {
//       message: "Verify your BVN and NIN to finish setting up your account",
//       buttonLabel: "Verify BVN",
//       navigateTo: "kyc",
//       tag: "ID VERIFICATION",
//     };
//   }

//   if (!bvnVerified) {
//     return {
//       message:
//         "Your BVN is not verified yet. Please complete BVN verification to unlock full access.",
//       buttonLabel: "Verify BVN",
//       navigateTo: "kyc",
//       tag: "BVN VERIFICATION",
//     };
//   }

//   if (!ninVerified) {
//     return {
//       message:
//         "Your NIN is not verified yet. Please complete NIN verification to unlock full access.",
//       buttonLabel: "Verify NIN",
//       navigateTo: "kyc",
//       tag: "NIN VERIFICATION",
//     };
//   }

//   return null;
// };

// const HomeScreen = () => {
//   const [addMoneyVisible, setAddMoneyVisible] = useState(false);
//   const [sendMoneyVisible, setSendMoneyVisible] = useState(false);
//   const [balanceVisible, setBalanceVisible] = useState(true);

//   const navigation = useNavigation();
//   const dispatch = useDispatch();

//   const accountDetails = useSelector(
//     (state: any) => state.authSlice.accountDetails,
//   );
//   const userDetails = useSelector((state: any) => state.authSlice.userDetails);

//   const { data: accountData, isSuccess: accountSuccess } = useFetchData_v2(
//     "account/getAccountDetails",
//     "accountDetails",
//   );

//   console.log({
//     tttt: accountData?.data?.data,
//   });

//   const { data: userData, isSuccess: userSuccess } = useFetchData_v2(
//     "users/user",
//     "userDetails",
//   );

//   useEffect(() => {
//     if (accountSuccess && accountData?.data?.customer) {
//       dispatch(setAccountDetails(accountData.data.customer));
//     }
//   }, [accountSuccess, accountData]);

//   useEffect(() => {
//     if (userSuccess && userData?.data) {
//       dispatch(setUserDetails(userData.data.user));
//     }
//   }, [userSuccess, userData]);

//   const getInitials = () => {
//     if (!userDetails) return "EI";
//     const first = userDetails?.firstName?.[0] || "";
//     const last = userDetails?.lastName?.[0] || "";
//     return `${first}${last}`.toUpperCase() || "EI";
//   };

//   // ─── Compute verification banner info ────────────────────────
//   const verificationInfo = getVerificationStatus(userDetails);

//   return (
//     <SafeAreaView style={styles.container}>
//       <StatusBar barStyle="dark-content" backgroundColor="#fff" />
//       <ScrollView showsVerticalScrollIndicator={false}>
//         {/* Header */}
//         <View style={styles.header}>
//           <TouchableOpacity style={styles.iconButton}>
//             <Ionicons name="chatbubble-outline" size={22} color="#1a1a2e" />
//           </TouchableOpacity>
//           <TouchableOpacity
//             style={styles.avatarButton}
//             onPress={() => navigation.navigate("More" as never)}
//           >
//             <Text style={styles.avatarText}>{getInitials()}</Text>
//           </TouchableOpacity>
//         </View>

//         {/* ─── ID Verification Banner (only shown if verification is needed) ─── */}
//         {verificationInfo && (
//           <View style={styles.verificationBanner}>
//             <View style={styles.verificationTagRow}>
//               <Ionicons
//                 name="shield-outline"
//                 size={14}
//                 color="#8b8b9e"
//                 style={{ marginRight: 6 }}
//               />
//               <Text style={styles.verificationLabel}>
//                 {verificationInfo.tag}
//               </Text>
//             </View>
//             <Text style={styles.verificationText}>
//               {verificationInfo.message}
//             </Text>
//             <TouchableOpacity
//               style={styles.beginButton}
//               onPress={() =>
//                 navigation.navigate(verificationInfo.navigateTo as never)
//               }
//             >
//               <Text style={styles.beginButtonText}>
//                 {verificationInfo.buttonLabel}
//               </Text>
//             </TouchableOpacity>
//           </View>
//         )}

//         {/* Currency & Balance Section */}
//         <View style={styles.balanceSection}>
//           <TouchableOpacity style={styles.currencySelector}>
//             <Text style={styles.flagEmoji}>🇳🇬</Text>
//             <Text style={styles.currencyText}>Nigerian Naira</Text>
//             <Ionicons name="chevron-down" size={18} color="#666" />
//           </TouchableOpacity>

//           <View style={styles.balanceRow}>
//             <Text style={styles.balanceAmount}>
//               {balanceVisible
//                 ? `₦${userDetails?.virtualAccountBalance?.toLocaleString() ?? "0"}`
//                 : "₦ ••••••"}
//             </Text>
//             <TouchableOpacity
//               style={styles.eyeButton}
//               onPress={() => setBalanceVisible((prev) => !prev)}
//             >
//               <Ionicons
//                 name={balanceVisible ? "eye-outline" : "eye-off-outline"}
//                 size={16}
//                 color="#666"
//               />
//             </TouchableOpacity>
//           </View>
//         </View>

//         {/* Get Bank Account Card */}
//         <TouchableOpacity
//           style={styles.bankAccountCard}
//           onPress={() => navigation.navigate("AccountDetails" as never)}
//         >
//           <View style={styles.bankIconContainer}>
//             <MaterialCommunityIcons
//               name="bank-outline"
//               size={22}
//               color="#666"
//             />
//           </View>
//           <Text style={styles.bankAccountText}>Get your Bank Account</Text>
//           <Ionicons name="chevron-forward" size={20} color="#999" />
//         </TouchableOpacity>

//         {/* Quick Actions */}
//         <View style={styles.quickActions}>
//           <TouchableOpacity
//             style={styles.actionItem}
//             onPress={() => setAddMoneyVisible(true)}
//           >
//             <View style={styles.actionIconContainer}>
//               <Feather name="plus" size={26} color="#1a1a2e" />
//             </View>
//             <Text style={styles.actionLabel}>Add Money</Text>
//           </TouchableOpacity>

//           <TouchableOpacity
//             style={styles.actionItem}
//             onPress={() => setSendMoneyVisible(true)}
//           >
//             <View style={styles.actionIconContainer}>
//               <Ionicons name="send" size={22} color="#1a1a2e" />
//             </View>
//             <Text style={styles.actionLabel}>Send</Text>
//           </TouchableOpacity>

//           <TouchableOpacity style={styles.actionItem}>
//             <View style={styles.actionIconContainer}>
//               <Ionicons name="swap-horizontal" size={24} color="#1a1a2e" />
//             </View>
//             <Text style={styles.actionLabel}>Convert</Text>
//           </TouchableOpacity>
//         </View>

//         {/* Recommended Section */}
//         <Text style={styles.sectionTitle}>Recommended</Text>
//         <View style={styles.recommendedGrid}>
//           <TouchableOpacity style={styles.recommendedCard}>
//             <View style={styles.recommendedIconContainer}>
//               <MaterialCommunityIcons
//                 name="lightning-bolt"
//                 size={22}
//                 color="#fff"
//               />
//             </View>
//             <Text style={styles.recommendedLabel}>Bills & Airtime</Text>
//             <Ionicons
//               name="chevron-forward"
//               size={16}
//               color="#999"
//               style={styles.recommendedArrow}
//             />
//           </TouchableOpacity>

//           <TouchableOpacity style={styles.recommendedCard}>
//             <View style={styles.recommendedIconContainer}>
//               <Feather name="gift" size={20} color="#fff" />
//             </View>
//             <Text style={styles.recommendedLabel}>Gift Cards</Text>
//             <Ionicons
//               name="chevron-forward"
//               size={16}
//               color="#999"
//               style={styles.recommendedArrow}
//             />
//           </TouchableOpacity>

//           <TouchableOpacity style={styles.recommendedCard}>
//             <View style={styles.recommendedIconContainer}>
//               <Ionicons name="document-text-outline" size={20} color="#fff" />
//             </View>
//             <Text style={styles.recommendedLabel}>Invoice</Text>
//           </TouchableOpacity>
//         </View>
//       </ScrollView>

//       {/* Modals */}
//       <AddMoneyModal
//         visible={addMoneyVisible}
//         onClose={() => setAddMoneyVisible(false)}
//       />
//       <SendMoneyModal
//         visible={sendMoneyVisible}
//         onClose={() => setSendMoneyVisible(false)}
//       />
//     </SafeAreaView>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#fff",
//   },
//   header: {
//     flexDirection: "row",
//     justifyContent: "space-between",
//     alignItems: "center",
//     paddingHorizontal: 20,
//     paddingVertical: 12,
//   },
//   iconButton: {
//     width: 44,
//     height: 44,
//     borderRadius: 22,
//     backgroundColor: "#f5f5f5",
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   avatarButton: {
//     width: 44,
//     height: 44,
//     borderRadius: 22,
//     backgroundColor: "#1a1a2e",
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   avatarText: {
//     color: "#fff",
//     fontSize: 14,
//     fontWeight: "600",
//   },
//   verificationBanner: {
//     backgroundColor: "#1a1a2e",
//     marginHorizontal: 20,
//     borderRadius: 16,
//     padding: 20,
//     marginTop: 8,
//   },
//   verificationTagRow: {
//     flexDirection: "row",
//     alignItems: "center",
//     marginBottom: 8,
//   },
//   verificationLabel: {
//     color: "#8b8b9e",
//     fontSize: 11,
//     fontWeight: "600",
//     letterSpacing: 1,
//   },
//   verificationText: {
//     color: "#fff",
//     fontSize: 15,
//     fontWeight: "500",
//     lineHeight: 22,
//     marginBottom: 16,
//   },
//   beginButton: {
//     backgroundColor: "#fff",
//     paddingVertical: 12,
//     paddingHorizontal: 28,
//     borderRadius: 8,
//     alignSelf: "flex-start",
//   },
//   beginButtonText: {
//     color: "#1a1a2e",
//     fontSize: 14,
//     fontWeight: "600",
//   },
//   balanceSection: {
//     paddingHorizontal: 20,
//     marginTop: 24,
//   },
//   currencySelector: {
//     flexDirection: "row",
//     alignItems: "center",
//     gap: 8,
//   },
//   flagEmoji: {
//     fontSize: 18,
//   },
//   currencyText: {
//     fontSize: 15,
//     fontWeight: "500",
//     color: "#1a1a2e",
//   },
//   balanceRow: {
//     flexDirection: "row",
//     alignItems: "center",
//     marginTop: 8,
//     gap: 12,
//   },
//   balanceAmount: {
//     fontSize: 32,
//     fontWeight: "700",
//     color: "#1a1a2e",
//   },
//   eyeButton: {
//     width: 32,
//     height: 32,
//     borderRadius: 16,
//     backgroundColor: "#f5f5f5",
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   bankAccountCard: {
//     flexDirection: "row",
//     alignItems: "center",
//     backgroundColor: "#f8f8f8",
//     marginHorizontal: 20,
//     marginTop: 20,
//     padding: 16,
//     borderRadius: 12,
//   },
//   bankIconContainer: {
//     width: 40,
//     height: 40,
//     borderRadius: 8,
//     backgroundColor: "#fff",
//     justifyContent: "center",
//     alignItems: "center",
//     marginRight: 12,
//   },
//   bankAccountText: {
//     flex: 1,
//     fontSize: 15,
//     fontWeight: "500",
//     color: "#1a1a2e",
//   },
//   quickActions: {
//     flexDirection: "row",
//     justifyContent: "center",
//     gap: 32,
//     marginTop: 28,
//     paddingHorizontal: 20,
//   },
//   actionItem: {
//     alignItems: "center",
//   },
//   actionIconContainer: {
//     width: 60,
//     height: 60,
//     borderRadius: 30,
//     borderWidth: 1.5,
//     borderColor: "#1a1a2e",
//     justifyContent: "center",
//     alignItems: "center",
//     marginBottom: 10,
//   },
//   actionLabel: {
//     fontSize: 13,
//     fontWeight: "500",
//     color: "#1a1a2e",
//   },
//   sectionTitle: {
//     fontSize: 17,
//     fontWeight: "700",
//     color: "#1a1a2e",
//     marginTop: 32,
//     marginBottom: 16,
//     paddingHorizontal: 20,
//   },
//   recommendedGrid: {
//     flexDirection: "row",
//     paddingHorizontal: 20,
//     gap: 12,
//     paddingBottom: 24,
//   },
//   recommendedCard: {
//     flex: 1,
//     backgroundColor: "#f5f7fa",
//     borderRadius: 12,
//     padding: 16,
//     minHeight: 120,
//   },
//   recommendedIconContainer: {
//     width: 40,
//     height: 40,
//     borderRadius: 10,
//     backgroundColor: "#1a1a2e",
//     justifyContent: "center",
//     alignItems: "center",
//     marginBottom: 12,
//   },
//   recommendedLabel: {
//     fontSize: 13,
//     fontWeight: "600",
//     color: "#1a1a2e",
//   },
//   recommendedArrow: {
//     position: "absolute",
//     bottom: 16,
//     right: 16,
//   },
// });

// export default HomeScreen;

import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  Modal,
  TextInput,
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons, MaterialCommunityIcons, Feather } from "@expo/vector-icons";
import { useDispatch, useSelector } from "react-redux";
import { useNavigation } from "@react-navigation/native";

import AddMoneyModal from "../components/AddMoneyModal";
import SendMoneyModal from "../components/Sendmoneymodal";
import { setAccountDetails, setUserDetails } from "../redux/Authslice";
import { useFetchData_v2, useMutateData_v2 } from "../hooks/Requestv2";

// ─── Helper: Determine what verification is needed ───────────────
const getVerificationStatus = (userDetails: any) => {
  if (!userDetails) return null;

  const bvnVerified = userDetails?.bvnKycStatus === true;
  const ninVerified = userDetails?.ninKycStatus === true;

  if (bvnVerified && ninVerified) return null;

  if (!bvnVerified && !ninVerified) {
    return {
      message: "Verify your BVN and NIN to finish setting up your account",
      buttonLabel: "Verify BVN",
      navigateTo: "kyc",
      tag: "ID VERIFICATION",
    };
  }

  if (!bvnVerified) {
    return {
      message:
        "Your BVN is not verified yet. Please complete BVN verification to unlock full access.",
      buttonLabel: "Verify BVN",
      navigateTo: "kyc",
      tag: "BVN VERIFICATION",
    };
  }

  if (!ninVerified) {
    return {
      message:
        "Your NIN is not verified yet. Please complete NIN verification to unlock full access.",
      buttonLabel: "Verify NIN",
      navigateTo: "kyc",
      tag: "NIN VERIFICATION",
    };
  }

  return null;
};

// ════════════════════════════════════════════════════════════════
// Withdraw Modal
// ════════════════════════════════════════════════════════════════
const WithdrawModal = ({
  visible,
  onClose,
}: {
  visible: boolean;
  onClose: () => void;
}) => {
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState(
    "Withdrawal to personal bank account",
  );

  const { mutate: initiatePayout, isPending } = useMutateData_v2(
    "account/payoutFromTransactPay",
    "POST",
    undefined,
    {
      onSuccess: (data) => {
        const ref = data?.data?.data?.[0]?.payoutReference;
        Alert.alert(
          "Withdrawal Initiated",
          `Your withdrawal of ₦${Number(amount).toLocaleString()} has been initiated successfully.${ref ? `\n\nReference: ${ref}` : ""}`,
          [
            {
              text: "OK",
              onPress: () => {
                onClose();
                setAmount("");
              },
            },
          ],
        );
      },
      onError: (error: any) => {
        const msg = error?.data?.message || "Failed to initiate withdrawal";
        Alert.alert("Error", msg);
      },
    },
  );

  const handleWithdraw = () => {
    const parsedAmount = Number(amount);
    if (!amount || isNaN(parsedAmount) || parsedAmount <= 0) {
      Alert.alert("Invalid Amount", "Please enter a valid amount");
      return;
    }
    initiatePayout({ amount: parsedAmount, description });
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.modalOverlay}
      >
        <View style={styles.modalSheet}>
          {/* Handle bar */}
          <View style={styles.modalHandle} />

          {/* Header */}
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Withdraw</Text>
            <TouchableOpacity style={styles.modalClose} onPress={onClose}>
              <Ionicons name="close" size={22} color="#1a1a2e" />
            </TouchableOpacity>
          </View>

          {/* Icon */}
          <View style={styles.withdrawIconWrap}>
            <Ionicons name="arrow-down-circle" size={40} color="#1a1a2e" />
          </View>

          <Text style={styles.withdrawSubtitle}>
            Funds will be sent to your saved bank account
          </Text>

          {/* Amount input */}
          <Text style={styles.inputLabel}>Amount (₦)</Text>
          <View style={styles.amountInputWrap}>
            <Text style={styles.currencySymbol}>₦</Text>
            <TextInput
              style={styles.amountInput}
              placeholder="0.00"
              placeholderTextColor="#aaa"
              keyboardType="numeric"
              value={amount}
              onChangeText={setAmount}
              editable={!isPending}
            />
          </View>

          {/* Description input */}
          <Text style={styles.inputLabel}>Description (optional)</Text>
          <TextInput
            style={styles.descriptionInput}
            placeholder="Withdrawal to personal bank account"
            placeholderTextColor="#aaa"
            value={description}
            onChangeText={setDescription}
            editable={!isPending}
          />

          {/* Submit */}
          <TouchableOpacity
            style={[styles.withdrawButton, isPending && styles.buttonDisabled]}
            onPress={handleWithdraw}
            disabled={isPending}
          >
            {isPending ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.withdrawButtonText}>Withdraw Funds</Text>
            )}
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
};

// ════════════════════════════════════════════════════════════════
// Home Screen
// ════════════════════════════════════════════════════════════════
const HomeScreen = () => {
  const [addMoneyVisible, setAddMoneyVisible] = useState(false);
  const [sendMoneyVisible, setSendMoneyVisible] = useState(false);
  const [withdrawVisible, setWithdrawVisible] = useState(false);
  const [balanceVisible, setBalanceVisible] = useState(true);

  const navigation = useNavigation();
  const dispatch = useDispatch();

  const userDetails = useSelector((state: any) => state.authSlice.userDetails);

  const { data: accountData, isSuccess: accountSuccess } = useFetchData_v2(
    "account/getAccountDetails",
    "accountDetails",
  );

  const { data: userData, isSuccess: userSuccess } = useFetchData_v2(
    "users/user",
    "userDetails",
  );

  useEffect(() => {
    if (accountSuccess && accountData?.data?.customer) {
      dispatch(setAccountDetails(accountData.data.customer));
    }
  }, [accountSuccess, accountData]);

  useEffect(() => {
    if (userSuccess && userData?.data) {
      dispatch(setUserDetails(userData.data.user));
    }
  }, [userSuccess, userData]);

  const getInitials = () => {
    if (!userDetails) return "EI";
    const first = userDetails?.firstName?.[0] || "";
    const last = userDetails?.lastName?.[0] || "";
    return `${first}${last}`.toUpperCase() || "EI";
  };

  const verificationInfo = getVerificationStatus(userDetails);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity style={styles.iconButton}>
            <Ionicons name="chatbubble-outline" size={22} color="#1a1a2e" />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.avatarButton}
            onPress={() => navigation.navigate("More" as never)}
          >
            <Text style={styles.avatarText}>{getInitials()}</Text>
          </TouchableOpacity>
        </View>

        {/* Verification Banner */}
        {verificationInfo && (
          <View style={styles.verificationBanner}>
            <View style={styles.verificationTagRow}>
              <Ionicons
                name="shield-outline"
                size={14}
                color="#8b8b9e"
                style={{ marginRight: 6 }}
              />
              <Text style={styles.verificationLabel}>
                {verificationInfo.tag}
              </Text>
            </View>
            <Text style={styles.verificationText}>
              {verificationInfo.message}
            </Text>
            <TouchableOpacity
              style={styles.beginButton}
              onPress={() =>
                navigation.navigate(verificationInfo.navigateTo as never)
              }
            >
              <Text style={styles.beginButtonText}>
                {verificationInfo.buttonLabel}
              </Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Balance Section */}
        <View style={styles.balanceSection}>
          <TouchableOpacity style={styles.currencySelector}>
            <Text style={styles.flagEmoji}>🇳🇬</Text>
            <Text style={styles.currencyText}>Nigerian Naira</Text>
            <Ionicons name="chevron-down" size={18} color="#666" />
          </TouchableOpacity>

          <View style={styles.balanceRow}>
            <Text style={styles.balanceAmount}>
              {balanceVisible
                ? `₦${userDetails?.virtualAccountBalance?.toLocaleString() ?? "0"}`
                : "₦ ••••••"}
            </Text>
            <TouchableOpacity
              style={styles.eyeButton}
              onPress={() => setBalanceVisible((prev) => !prev)}
            >
              <Ionicons
                name={balanceVisible ? "eye-outline" : "eye-off-outline"}
                size={16}
                color="#666"
              />
            </TouchableOpacity>
          </View>
        </View>

        {/* Get Bank Account Card */}
        <TouchableOpacity
          style={styles.bankAccountCard}
          onPress={() => navigation.navigate("AccountDetails" as never)}
        >
          <View style={styles.bankIconContainer}>
            <MaterialCommunityIcons
              name="bank-outline"
              size={22}
              color="#666"
            />
          </View>
          <Text style={styles.bankAccountText}>Get your Bank Account</Text>
          <Ionicons name="chevron-forward" size={20} color="#999" />
        </TouchableOpacity>

        {/* ─── Quick Actions ─── */}
        <View style={styles.quickActions}>
          <TouchableOpacity
            style={styles.actionItem}
            onPress={() => setAddMoneyVisible(true)}
          >
            <View style={styles.actionIconContainer}>
              <Feather name="plus" size={26} color="#1a1a2e" />
            </View>
            <Text style={styles.actionLabel}>Add Money</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.actionItem}
            onPress={() => setSendMoneyVisible(true)}
          >
            <View style={styles.actionIconContainer}>
              <Ionicons name="send" size={22} color="#1a1a2e" />
            </View>
            <Text style={styles.actionLabel}>Send</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionItem}>
            <View style={styles.actionIconContainer}>
              <Ionicons name="swap-horizontal" size={24} color="#1a1a2e" />
            </View>
            <Text style={styles.actionLabel}>Convert</Text>
          </TouchableOpacity>

          {/* ─── Withdraw ─── */}
          <TouchableOpacity
            style={styles.actionItem}
            onPress={() => setWithdrawVisible(true)}
          >
            <View style={styles.actionIconContainer}>
              <Ionicons name="arrow-down" size={24} color="#1a1a2e" />
            </View>
            <Text style={styles.actionLabel}>Withdraw</Text>
          </TouchableOpacity>
        </View>

        {/* Recommended Section */}
        <Text style={styles.sectionTitle}>Recommended</Text>
        <View style={styles.recommendedGrid}>
          <TouchableOpacity style={styles.recommendedCard}>
            <View style={styles.recommendedIconContainer}>
              <MaterialCommunityIcons
                name="lightning-bolt"
                size={22}
                color="#fff"
              />
            </View>
            <Text style={styles.recommendedLabel}>Bills & Airtime</Text>
            <Ionicons
              name="chevron-forward"
              size={16}
              color="#999"
              style={styles.recommendedArrow}
            />
          </TouchableOpacity>

          <TouchableOpacity style={styles.recommendedCard}>
            <View style={styles.recommendedIconContainer}>
              <Feather name="gift" size={20} color="#fff" />
            </View>
            <Text style={styles.recommendedLabel}>Gift Cards</Text>
            <Ionicons
              name="chevron-forward"
              size={16}
              color="#999"
              style={styles.recommendedArrow}
            />
          </TouchableOpacity>

          <TouchableOpacity style={styles.recommendedCard}>
            <View style={styles.recommendedIconContainer}>
              <Ionicons name="document-text-outline" size={20} color="#fff" />
            </View>
            <Text style={styles.recommendedLabel}>Invoice</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Modals */}
      <AddMoneyModal
        visible={addMoneyVisible}
        onClose={() => setAddMoneyVisible(false)}
      />
      <SendMoneyModal
        visible={sendMoneyVisible}
        onClose={() => setSendMoneyVisible(false)}
      />
      <WithdrawModal
        visible={withdrawVisible}
        onClose={() => setWithdrawVisible(false)}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff" },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  iconButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: "#f5f5f5",
    justifyContent: "center",
    alignItems: "center",
  },
  avatarButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: "#1a1a2e",
    justifyContent: "center",
    alignItems: "center",
  },
  avatarText: { color: "#fff", fontSize: 14, fontWeight: "600" },
  verificationBanner: {
    backgroundColor: "#1a1a2e",
    marginHorizontal: 20,
    borderRadius: 16,
    padding: 20,
    marginTop: 8,
  },
  verificationTagRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  verificationLabel: {
    color: "#8b8b9e",
    fontSize: 11,
    fontWeight: "600",
    letterSpacing: 1,
  },
  verificationText: {
    color: "#fff",
    fontSize: 15,
    fontWeight: "500",
    lineHeight: 22,
    marginBottom: 16,
  },
  beginButton: {
    backgroundColor: "#fff",
    paddingVertical: 12,
    paddingHorizontal: 28,
    borderRadius: 8,
    alignSelf: "flex-start",
  },
  beginButtonText: { color: "#1a1a2e", fontSize: 14, fontWeight: "600" },
  balanceSection: { paddingHorizontal: 20, marginTop: 24 },
  currencySelector: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  flagEmoji: { fontSize: 18 },
  currencyText: { fontSize: 15, fontWeight: "500", color: "#1a1a2e" },
  balanceRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 8,
    gap: 12,
  },
  balanceAmount: { fontSize: 32, fontWeight: "700", color: "#1a1a2e" },
  eyeButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: "#f5f5f5",
    justifyContent: "center",
    alignItems: "center",
  },
  bankAccountCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f8f8f8",
    marginHorizontal: 20,
    marginTop: 20,
    padding: 16,
    borderRadius: 12,
  },
  bankIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 8,
    backgroundColor: "#fff",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },
  bankAccountText: {
    flex: 1,
    fontSize: 15,
    fontWeight: "500",
    color: "#1a1a2e",
  },
  quickActions: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 20,
    marginTop: 28,
    paddingHorizontal: 20,
  },
  actionItem: { alignItems: "center" },
  actionIconContainer: {
    width: 56,
    height: 56,
    borderRadius: 28,
    borderWidth: 1.5,
    borderColor: "#1a1a2e",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 8,
  },
  actionLabel: { fontSize: 12, fontWeight: "500", color: "#1a1a2e" },
  sectionTitle: {
    fontSize: 17,
    fontWeight: "700",
    color: "#1a1a2e",
    marginTop: 32,
    marginBottom: 16,
    paddingHorizontal: 20,
  },
  recommendedGrid: {
    flexDirection: "row",
    paddingHorizontal: 20,
    gap: 12,
    paddingBottom: 24,
  },
  recommendedCard: {
    flex: 1,
    backgroundColor: "#f5f7fa",
    borderRadius: 12,
    padding: 16,
    minHeight: 120,
  },
  recommendedIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: "#1a1a2e",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 12,
  },
  recommendedLabel: { fontSize: 13, fontWeight: "600", color: "#1a1a2e" },
  recommendedArrow: { position: "absolute", bottom: 16, right: 16 },

  // ─── Withdraw Modal ───────────────────────────────────────────
  modalOverlay: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(0,0,0,0.4)",
  },
  modalSheet: {
    backgroundColor: "#fff",
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 24,
    paddingBottom: 40,
    paddingTop: 12,
  },
  modalHandle: {
    width: 40,
    height: 4,
    backgroundColor: "#e0e0e0",
    borderRadius: 2,
    alignSelf: "center",
    marginBottom: 16,
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  modalTitle: { fontSize: 20, fontWeight: "700", color: "#1a1a2e" },
  modalClose: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "#f5f5f5",
    justifyContent: "center",
    alignItems: "center",
  },
  withdrawIconWrap: {
    alignSelf: "center",
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: "#f0f4f8",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 12,
  },
  withdrawSubtitle: {
    fontSize: 13,
    color: "#888",
    textAlign: "center",
    marginBottom: 24,
  },
  inputLabel: {
    fontSize: 13,
    fontWeight: "600",
    color: "#1a1a2e",
    marginBottom: 8,
  },
  amountInputWrap: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f0f4f8",
    borderRadius: 12,
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  currencySymbol: {
    fontSize: 18,
    fontWeight: "700",
    color: "#1a1a2e",
    marginRight: 6,
  },
  amountInput: {
    flex: 1,
    fontSize: 24,
    fontWeight: "700",
    color: "#1a1a2e",
    paddingVertical: 16,
  },
  descriptionInput: {
    backgroundColor: "#f0f4f8",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 14,
    color: "#1a1a2e",
    marginBottom: 24,
  },
  withdrawButton: {
    backgroundColor: "#1a1a2e",
    height: 56,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
  },
  buttonDisabled: { opacity: 0.7 },
  withdrawButtonText: { color: "#fff", fontSize: 16, fontWeight: "600" },
});

export default HomeScreen;
