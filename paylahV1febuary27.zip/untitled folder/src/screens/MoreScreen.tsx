// import React, { useState } from "react";
// import {
//   View,
//   Text,
//   StyleSheet,
//   TouchableOpacity,
//   ScrollView,
//   Switch,
// } from "react-native";
// import { SafeAreaView } from "react-native-safe-area-context";
// import { Ionicons, Feather, MaterialCommunityIcons } from "@expo/vector-icons";
// import { useNavigation } from "@react-navigation/native";

// const MoreScreen = () => {
//   const [notificationsEnabled, setNotificationsEnabled] = useState(true);
//   const [biometricEnabled, setBiometricEnabled] = useState(false);
//   const navigation = useNavigation();

//   return (
//     <SafeAreaView style={styles.container}>
//       {/* Header */}
//       <View style={styles.header}>
//         <Text style={styles.headerTitle}>Settings</Text>
//         <TouchableOpacity
//           style={styles.closeButton}
//           onPress={() => navigation.navigate("Home")}
//         >
//           <Ionicons name="close" size={24} color="#1a1a2e" />
//         </TouchableOpacity>
//       </View>

//       <ScrollView showsVerticalScrollIndicator={false}>
//         {/* User Profile Card */}
//         <View style={styles.profileCard}>
//           <View style={styles.avatar}>
//             <Text style={styles.avatarText}>EI</Text>
//           </View>
//           <View style={styles.profileInfo}>
//             <Text style={styles.userName}>User</Text>
//             <Text style={styles.userEmail}>No email</Text>
//           </View>
//           <TouchableOpacity style={styles.editButton}>
//             <Text style={styles.editButtonText}>Edit</Text>
//           </TouchableOpacity>
//         </View>

//         {/* Account Section */}
//         <View style={styles.section}>
//           <Text style={styles.sectionTitle}>Account</Text>

//           <TouchableOpacity style={styles.menuItem}>
//             <View style={styles.menuIconContainer}>
//               <Feather name="user" size={20} color="#666" />
//             </View>
//             <Text style={styles.menuItemText}>Profile</Text>
//             <Ionicons name="chevron-forward" size={20} color="#999" />
//           </TouchableOpacity>

//           <View style={styles.divider} />

//           <TouchableOpacity style={styles.menuItem}>
//             <View style={styles.menuIconContainer}>
//               <MaterialCommunityIcons
//                 name="lock-outline"
//                 size={20}
//                 color="#666"
//               />
//             </View>
//             <Text style={styles.menuItemText}>Security</Text>
//             <Ionicons name="chevron-forward" size={20} color="#999" />
//           </TouchableOpacity>

//           <View style={styles.divider} />

//           <TouchableOpacity style={styles.menuItem}>
//             <View style={styles.menuIconContainer}>
//               <MaterialCommunityIcons
//                 name="bank-outline"
//                 size={20}
//                 color="#666"
//               />
//             </View>
//             <Text style={styles.menuItemText}>Bank Accounts</Text>
//             <Ionicons name="chevron-forward" size={20} color="#999" />
//           </TouchableOpacity>
//         </View>

//         {/* Preferences Section */}
//         <View style={styles.section}>
//           <Text style={styles.sectionTitle}>Preferences</Text>

//           <View style={styles.menuItem}>
//             <View style={styles.menuIconContainer}>
//               <Ionicons name="notifications-outline" size={20} color="#666" />
//             </View>
//             <Text style={styles.menuItemText}>Notifications</Text>
//             <Switch
//               value={notificationsEnabled}
//               onValueChange={setNotificationsEnabled}
//               trackColor={{ false: "#e5e5e5", true: "#1a1a2e" }}
//               thumbColor="#fff"
//             />
//           </View>

//           <View style={styles.divider} />

//           <View style={styles.menuItem}>
//             <View style={styles.menuIconContainer}>
//               <MaterialCommunityIcons
//                 name="lock-outline"
//                 size={20}
//                 color="#666"
//               />
//             </View>
//             <View style={styles.menuItemContent}>
//               <Text style={styles.menuItemText}>Biometric Login</Text>
//               <Text style={styles.menuItemSubtext}>Disabled</Text>
//             </View>
//             <Switch
//               value={biometricEnabled}
//               onValueChange={setBiometricEnabled}
//               trackColor={{ false: "#e5e5e5", true: "#1a1a2e" }}
//               thumbColor="#fff"
//             />
//           </View>
//         </View>
//       </ScrollView>
//     </SafeAreaView>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#f5f5f5",
//   },
//   header: {
//     flexDirection: "row",
//     justifyContent: "space-between",
//     alignItems: "center",
//     paddingHorizontal: 20,
//     paddingVertical: 16,
//     backgroundColor: "#f5f5f5",
//   },
//   headerTitle: {
//     fontSize: 28,
//     fontWeight: "700",
//     color: "#1a1a2e",
//   },
//   closeButton: {
//     width: 40,
//     height: 40,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   profileCard: {
//     flexDirection: "row",
//     alignItems: "center",
//     backgroundColor: "#fff",
//     marginHorizontal: 16,
//     marginTop: 8,
//     marginBottom: 16,
//     padding: 20,
//     borderRadius: 16,
//     borderWidth: 1,
//     borderColor: "#e5e5e5",
//   },
//   avatar: {
//     width: 64,
//     height: 64,
//     borderRadius: 32,
//     backgroundColor: "#1a1a2e",
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   avatarText: {
//     color: "#fff",
//     fontSize: 20,
//     fontWeight: "600",
//   },
//   profileInfo: {
//     flex: 1,
//     marginLeft: 16,
//   },
//   userName: {
//     fontSize: 18,
//     fontWeight: "600",
//     color: "#1a1a2e",
//     marginBottom: 4,
//   },
//   userEmail: {
//     fontSize: 14,
//     color: "#666",
//   },
//   editButton: {
//     paddingHorizontal: 20,
//     paddingVertical: 10,
//     borderRadius: 8,
//     borderWidth: 1,
//     borderColor: "#e5e5e5",
//   },
//   editButtonText: {
//     fontSize: 14,
//     fontWeight: "500",
//     color: "#1a1a2e",
//   },
//   section: {
//     backgroundColor: "#fff",
//     marginHorizontal: 16,
//     marginBottom: 16,
//     borderRadius: 16,
//     borderWidth: 1,
//     borderColor: "#e5e5e5",
//     overflow: "hidden",
//   },
//   sectionTitle: {
//     fontSize: 14,
//     fontWeight: "600",
//     color: "#1a1a2e",
//     paddingHorizontal: 20,
//     paddingTop: 16,
//     paddingBottom: 12,
//     backgroundColor: "#f9f9f9",
//   },
//   menuItem: {
//     flexDirection: "row",
//     alignItems: "center",
//     paddingHorizontal: 20,
//     paddingVertical: 16,
//   },
//   menuIconContainer: {
//     width: 40,
//     height: 40,
//     borderRadius: 10,
//     backgroundColor: "#f0f2f5",
//     justifyContent: "center",
//     alignItems: "center",
//     marginRight: 12,
//   },
//   menuItemContent: {
//     flex: 1,
//   },
//   menuItemText: {
//     flex: 1,
//     fontSize: 16,
//     fontWeight: "500",
//     color: "#1a1a2e",
//   },
//   menuItemSubtext: {
//     fontSize: 13,
//     color: "#999",
//     marginTop: 2,
//   },
//   divider: {
//     height: 1,
//     backgroundColor: "#f0f0f0",
//     marginLeft: 72,
//   },
// });

// export default MoreScreen;

import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Switch,
  Alert,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons, Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { MoreStackParamList } from "../navigation/MoreStackNavigator";
import { useDispatch } from "react-redux";
import { logout } from "../redux/Authslice";

type MoreScreenNavigationProp = NativeStackNavigationProp<
  MoreStackParamList,
  "MoreMain"
>;

const MoreScreen = () => {
  const navigation = useNavigation<MoreScreenNavigationProp>();
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [biometricEnabled, setBiometricEnabled] = useState(false);

  const dispatch = useDispatch();

  const handleSignOut = () => {
    Alert.alert("Sign Out", "Are you sure you want to sign out?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Sign Out",
        style: "destructive",
        onPress: () => dispatch(logout()),
      },
    ]);
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Settings</Text>
        <TouchableOpacity
          style={styles.closeButton}
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="close" size={24} color="#1a1a2e" />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Account Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account</Text>

          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => navigation.navigate("Profile")}
          >
            <View style={styles.menuIconContainer}>
              <Feather name="user" size={20} color="#666" />
            </View>
            <Text style={styles.menuItemText}>Profile</Text>
            <Ionicons name="chevron-forward" size={20} color="#999" />
          </TouchableOpacity>

          <View style={styles.divider} />

          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => navigation.navigate("Security")}
          >
            <View style={styles.menuIconContainer}>
              <MaterialCommunityIcons
                name="lock-outline"
                size={20}
                color="#666"
              />
            </View>
            <Text style={styles.menuItemText}>Security</Text>
            <Ionicons name="chevron-forward" size={20} color="#999" />
          </TouchableOpacity>

          <View style={styles.divider} />

          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => navigation.navigate("BankAccounts")}
          >
            <View style={styles.menuIconContainer}>
              <MaterialCommunityIcons
                name="bank-outline"
                size={20}
                color="#666"
              />
            </View>
            <Text style={styles.menuItemText}>Bank Accounts</Text>
            <Ionicons name="chevron-forward" size={20} color="#999" />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => navigation.navigate("kyc")}
          >
            <View style={styles.menuIconContainer}>
              <MaterialCommunityIcons
                name="bank-outline"
                size={20}
                color="#666"
              />
            </View>
            <Text style={styles.menuItemText}>Kyc</Text>
            <Ionicons name="chevron-forward" size={20} color="#999" />
          </TouchableOpacity>
        </View>

        {/* Preferences Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Preferences</Text>

          <View style={styles.menuItem}>
            <View style={styles.menuIconContainer}>
              <Ionicons name="notifications-outline" size={20} color="#666" />
            </View>
            <Text style={styles.menuItemText}>Notifications</Text>
            <Switch
              value={notificationsEnabled}
              onValueChange={setNotificationsEnabled}
              trackColor={{ false: "#e5e5e5", true: "#1a1a2e" }}
              thumbColor="#fff"
            />
          </View>

          <View style={styles.divider} />

          <View style={styles.menuItem}>
            <View style={styles.menuIconContainer}>
              <MaterialCommunityIcons
                name="lock-outline"
                size={20}
                color="#666"
              />
            </View>
            <View style={styles.menuItemContent}>
              <Text style={styles.menuItemText}>Biometric Login</Text>
              <Text style={styles.menuItemSubtext}>Disabled</Text>
            </View>
            <Switch
              value={biometricEnabled}
              onValueChange={setBiometricEnabled}
              trackColor={{ false: "#e5e5e5", true: "#1a1a2e" }}
              thumbColor="#fff"
            />
          </View>
        </View>

        {/* Support Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Support</Text>

          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => navigation.navigate("HelpSupport")}
          >
            <View style={styles.menuIconContainer}>
              <Ionicons name="help-circle-outline" size={20} color="#666" />
            </View>
            <Text style={styles.menuItemText}>Help & Support</Text>
            <Ionicons name="chevron-forward" size={20} color="#999" />
          </TouchableOpacity>

          <View style={styles.divider} />

          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => navigation.navigate("About")}
          >
            <View style={styles.menuIconContainer}>
              <Ionicons
                name="information-circle-outline"
                size={20}
                color="#666"
              />
            </View>
            <Text style={styles.menuItemText}>About</Text>
            <Ionicons name="chevron-forward" size={20} color="#999" />
          </TouchableOpacity>
        </View>

        {/* Sign Out Button */}
        <TouchableOpacity style={styles.signOutButton} onPress={handleSignOut}>
          <Text style={styles.signOutText}>Sign Out</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: "#f5f5f5",
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: "700",
    color: "#1a1a2e",
  },
  closeButton: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  section: {
    backgroundColor: "#fff",
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    overflow: "hidden",
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: "600",
    color: "#1a1a2e",
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
    backgroundColor: "#f9f9f9",
  },
  menuItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  menuIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: "#f0f2f5",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },
  menuItemContent: {
    flex: 1,
  },
  menuItemText: {
    flex: 1,
    fontSize: 16,
    fontWeight: "500",
    color: "#1a1a2e",
  },
  menuItemSubtext: {
    fontSize: 13,
    color: "#999",
    marginTop: 2,
  },
  divider: {
    height: 1,
    backgroundColor: "#f0f0f0",
    marginLeft: 72,
  },
  signOutButton: {
    backgroundColor: "#1a1a2e",
    marginHorizontal: 16,
    marginBottom: 32,
    height: 56,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
  },
  signOutText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
});

export default MoreScreen;
