import React, { useState, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation, useRoute, RouteProp } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import axios from "axios";
import { RootStackParamList } from "../../navigation/Stacknavigator";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../../redux/Authslice";
import { API_CONFIG } from "../../../config/api";

type OtpScreenNavigationProp = NativeStackNavigationProp<
  RootStackParamList,
  "OtpVerification"
>;
type OtpScreenRouteProp = RouteProp<RootStackParamList, "OtpVerification">;

const Otpverificationscreen = () => {
  const navigation = useNavigation<OtpScreenNavigationProp>();
  //   const route = useRoute<OtpScreenRouteProp>();
  //   const { email } = route.params;
  const { user, token, verified, email } = useSelector(
    (state) => state?.authSlice,
  );

  const baseUrl = API_CONFIG.BASE_URL;

  //   const { user, token, verified, email } = useSelector(    (state) => state?.authSlice;

  //   let email: "kaka";

  //   console.log({
  //     tyuu: verified,
  //   });

  const dispatch = useDispatch();

  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [isLoading, setIsLoading] = useState(false);
  const [isResending, setIsResending] = useState(false);

  const inputRefs = useRef<(TextInput | null)[]>([]);

  const handleOtpChange = (value: string, index: number) => {
    // Only allow numbers
    if (value && !/^\d+$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    // Auto-focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyPress = (e: any, index: number) => {
    // Handle backspace - move to previous input
    if (e.nativeEvent.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const isOtpComplete = otp.every((digit) => digit !== "");
  const otpCode = otp.join("");

  const handleVerify = async () => {
    if (!isOtpComplete) {
      Alert.alert("Error", "Please enter the complete OTP code");
      return;
    }

    setIsLoading(true);

    try {
      const response = await axios.get(`${baseUrl}verify/${otpCode}`, {
        headers: {
          Authorization: `Bearer ${token}`, // Pass the token so the server knows who is verifying
        },
      });

      console.log({
        tttt: response.data,
      });

      if (response.status === 200 || response.status === 201) {
        Alert.alert("Success", "Email verified successfully!", [
          { text: "Login Now", onPress: () => dispatch(logout()) },
        ]);
      }
    } catch (error: any) {
      const errorMessage =
        error.response?.data?.message ||
        "Verification failed. Please try again.";
      Alert.alert("Verification Error", errorMessage);
      console.error("OTP verification error:", error.response?.data);
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendOtp = async () => {
    setIsResending(true);

    try {
      //   const response = await axios.post(
      //     "https://payla-s2tt.onrender.com/api/users/resend",
      //     {
      //       email: email,
      //     }
      //   );

      const response = await axios.get(
        `https://payla-s2tt.onrender.com/api/users/resend`,
        {
          headers: {
            Authorization: `Bearer ${token}`, // Pass the token so the server knows who is verifying
          },
        },
      );

      if (response.status === 200 || response.status === 201) {
        Alert.alert("Success", `A new OTP has been sent to your ${email}`);
        setOtp(["", "", "", "", "", ""]);
        inputRefs.current[0]?.focus();
      }
    } catch (error: any) {
      const errorMessage =
        error.response?.data?.message ||
        "Failed to resend OTP. Please try again.";
      Alert.alert("Error", errorMessage);
      console.error("Resend OTP error:", error.response?.data);
    } finally {
      setIsResending(false);
    }
  };

  const handleSignUpAgain = () => {
    dispatch(logout());
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.keyboardView}
      >
        <View style={styles.content}>
          {/* Logo */}
          <View style={styles.logoContainer}>
            <Ionicons name="swap-horizontal" size={28} color="#10b981" />
            <Text style={styles.logoText}>Pay-la</Text>
          </View>

          {/* Title */}
          <Text style={styles.title}>Verify your email</Text>
          <Text style={styles.subtitle}>Enter the OTP sent to </Text>
          <Text style={styles.subtitle}>{email}</Text>

          {/* Card */}
          <View style={styles.card}>
            {/* Warning Banner */}
            <View style={styles.warningBanner}>
              <Text style={styles.warningText}>
                Your email is not verified. Please check your email for the
                verification code and enter it below to continue.
              </Text>
            </View>

            {/* OTP Input */}
            <Text style={styles.label}>OTP Code</Text>
            <View style={styles.otpContainer}>
              {otp.map((digit, index) => (
                <TextInput
                  key={index}
                  ref={(ref) => (inputRefs.current[index] = ref)}
                  style={[styles.otpInput, digit && styles.otpInputFilled]}
                  value={digit}
                  onChangeText={(value) => handleOtpChange(value, index)}
                  onKeyPress={(e) => handleKeyPress(e, index)}
                  keyboardType="numeric"
                  maxLength={1}
                  selectTextOnFocus
                  editable={!isLoading}
                />
              ))}
            </View>
            <Text style={styles.otpHint}>
              We sent a 6-digit code to your email address
            </Text>

            {/* Verify Button */}
            <TouchableOpacity
              style={[
                styles.verifyButton,
                !isOtpComplete && styles.verifyButtonDisabled,
              ]}
              onPress={handleVerify}
              disabled={!isOtpComplete || isLoading}
            >
              {isLoading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text
                  style={[
                    styles.verifyButtonText,
                    !isOtpComplete && styles.verifyButtonTextDisabled,
                  ]}
                >
                  Verify Email
                </Text>
              )}
            </TouchableOpacity>

            {/* Divider */}
            <View style={styles.divider} />

            {/* Resend Section */}
            <Text style={styles.resendLabel}>Didn't receive the code?</Text>
            <TouchableOpacity
              style={[
                styles.resendButton,
                isResending && styles.resendButtonDisabled,
              ]}
              onPress={handleResendOtp}
              disabled={isResending}
            >
              {isResending ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.resendButtonText}>Resend OTP</Text>
              )}
            </TouchableOpacity>

            {/* Sign Up Again */}
            <TouchableOpacity
              style={styles.signUpAgain}
              onPress={handleSignUpAgain}
            >
              <Text style={styles.signUpAgainText}>
                Wrong email?{" "}
                <Text style={styles.signUpAgainLink}>Sign up again</Text>
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  keyboardView: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 20,
  },
  logoContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    marginBottom: 24,
  },
  logoText: {
    fontSize: 20,
    fontWeight: "700",
    color: "#1a1a2e",
  },
  title: {
    fontSize: 28,
    fontWeight: "700",
    color: "#1a1a2e",
    textAlign: "center",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 15,
    color: "#666",
    textAlign: "center",
    marginBottom: 24,
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    padding: 20,
  },
  warningBanner: {
    backgroundColor: "#f0f9ff",
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
  },
  warningText: {
    fontSize: 14,
    color: "#0284c7",
    lineHeight: 20,
    textAlign: "center",
  },
  label: {
    fontSize: 14,
    fontWeight: "500",
    color: "#1a1a2e",
    marginBottom: 12,
  },
  otpContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  otpInput: {
    width: 48,
    height: 56,
    borderWidth: 2,
    borderColor: "#1a1a2e",
    borderRadius: 12,
    fontSize: 24,
    fontWeight: "600",
    color: "#1a1a2e",
    textAlign: "center",
    backgroundColor: "#f9f9f9",
  },
  otpInputFilled: {
    backgroundColor: "#fff",
    borderColor: "#10b981",
  },
  otpHint: {
    fontSize: 13,
    color: "#666",
    textAlign: "center",
    marginBottom: 20,
  },
  verifyButton: {
    backgroundColor: "#10b981",
    height: 56,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
  },
  verifyButtonDisabled: {
    backgroundColor: "#d1d5db",
  },
  verifyButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  verifyButtonTextDisabled: {
    color: "#9ca3af",
  },
  divider: {
    height: 1,
    backgroundColor: "#e5e5e5",
    marginVertical: 20,
  },
  resendLabel: {
    fontSize: 14,
    color: "#666",
    textAlign: "center",
    marginBottom: 12,
  },
  resendButton: {
    backgroundColor: "#1a1a2e",
    height: 56,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 16,
  },
  resendButtonDisabled: {
    opacity: 0.7,
  },
  resendButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  signUpAgain: {
    alignItems: "center",
  },
  signUpAgainText: {
    fontSize: 14,
    color: "#666",
  },
  signUpAgainLink: {
    fontWeight: "600",
    color: "#1a1a2e",
    textDecorationLine: "underline",
  },
});

export default Otpverificationscreen;
