// // import React, { useState } from "react";
// // import {
// //   View,
// //   Text,
// //   StyleSheet,
// //   TextInput,
// //   TouchableOpacity,
// //   ScrollView,
// //   Alert,
// //   ActivityIndicator,
// // } from "react-native";
// // import { SafeAreaView } from "react-native-safe-area-context";
// // import { Ionicons } from "@expo/vector-icons";
// // import { useNavigation } from "@react-navigation/native";
// // import { NativeStackNavigationProp } from "@react-navigation/native-stack";
// // import axios from "axios";
// // import { RootStackParamList } from "../../navigation/Stacknavigator";
// // import { useDispatch } from "react-redux";
// // import { login } from "../../redux/Authslice";

// // type SignUpScreenNavigationProp = NativeStackNavigationProp<
// //   RootStackParamList,
// //   "SignUp"
// // >;

// // const Signupscreen = () => {
// //   const navigation = useNavigation<SignUpScreenNavigationProp>();
// //   const dispatch = useDispatch();

// //   const [firstName, setFirstName] = useState("");
// //   const [lastName, setLastName] = useState("");
// //   const [middleName, setMiddleName] = useState("");
// //   const [email, setEmail] = useState("");
// //   const [phoneNumber, setPhoneNumber] = useState("");
// //   const [pin, setPin] = useState("");
// //   const [confirmPin, setConfirmPin] = useState("");
// //   const [isLoading, setIsLoading] = useState(false);

// //   const handleSignUp = async () => {
// //     // Validation
// //     if (
// //       !firstName ||
// //       !lastName ||
// //       !email ||
// //       !phoneNumber ||
// //       !pin ||
// //       !confirmPin
// //     ) {
// //       Alert.alert("Error", "Please fill in all required fields");
// //       return;
// //     }
// //     if (pin !== confirmPin) {
// //       Alert.alert("Error", "PINs do not match");
// //       return;
// //     }
// //     if (pin.length < 4) {
// //       Alert.alert("Error", "PIN must be at least 4 digits");
// //       return;
// //     }

// //     setIsLoading(true);

// //     try {
// //       const generateTag = () => {
// //         const initials = `${firstName[0] || "u"}${
// //           lastName[0] || "x"
// //         }`.toLowerCase();
// //         const random = Math.random().toString(36).substring(2, 8);
// //         return `${initials}-${random}`;
// //       };

// //       const response = await axios.post(
// //         "https://payla-s2tt.onrender.com/api/users/register",
// //         {
// //           firstName: firstName.trim(),
// //           lastName: lastName.trim(),
// //           middleName: middleName.trim(),
// //           email: email.toLowerCase().trim(),
// //           pin: pin,
// //           phoneNumber: phoneNumber.trim(),
// //           // tags: "user",
// //           tags: generateTag(),
// //         },
// //       );

// //       console.log({
// //         iiiiiii: response.data,
// //       });

// //       const dispatch_data = response.data.data;
// //       dispatch(login(dispatch_data));

// //       // if (response.status === 201 || response.status === 200) {
// //       //   Alert.alert("Success", "Your account has been created!", [
// //       //     { text: "Login Now", onPress: () => navigation.navigate("Login") },
// //       //   ]);
// //       // }
// //     } catch (error: any) {
// //       const errorMessage =
// //         error.response?.data?.message ||
// //         "Registration failed. Please try again.";
// //       Alert.alert("Signup Error", errorMessage);
// //       console.error("Signup error details:", error.response?.data);
// //     } finally {
// //       setIsLoading(false);
// //     }
// //   };

// //   return (
// //     <SafeAreaView style={styles.container}>
// //       {/* Header */}
// //       <View style={styles.header}>
// //         <TouchableOpacity
// //           style={styles.backButton}
// //           onPress={() => navigation.goBack()}
// //         >
// //           <Ionicons name="arrow-back" size={24} color="#1a1a2e" />
// //         </TouchableOpacity>
// //       </View>

// //       <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
// //         {/* Logo */}
// //         <View style={styles.logoContainer}>
// //           <Ionicons name="swap-horizontal" size={32} color="#10b981" />
// //           <Text style={styles.logoText}>Pay-la</Text>
// //         </View>

// //         <Text style={styles.title}>Create Account</Text>
// //         <Text style={styles.subtitle}>Sign up to get started with Pay-la</Text>

// //         {/* Form */}
// //         <View style={styles.form}>
// //           <Text style={styles.label}>First Name</Text>
// //           <TextInput
// //             style={styles.input}
// //             placeholder="Enter your first name"
// //             placeholderTextColor="#999"
// //             value={firstName}
// //             onChangeText={setFirstName}
// //             editable={!isLoading}
// //           />

// //           <Text style={styles.label}>Last Name</Text>
// //           <TextInput
// //             style={styles.input}
// //             placeholder="Enter your last name"
// //             placeholderTextColor="#999"
// //             value={lastName}
// //             onChangeText={setLastName}
// //             editable={!isLoading}
// //           />

// //           <Text style={styles.label}>Middle Name (Optional)</Text>
// //           <TextInput
// //             style={styles.input}
// //             placeholder="Enter your middle name"
// //             placeholderTextColor="#999"
// //             value={middleName}
// //             onChangeText={setMiddleName}
// //             editable={!isLoading}
// //           />

// //           <Text style={styles.label}>Email Address</Text>
// //           <TextInput
// //             style={styles.input}
// //             placeholder="Enter your email"
// //             placeholderTextColor="#999"
// //             keyboardType="email-address"
// //             autoCapitalize="none"
// //             value={email}
// //             onChangeText={setEmail}
// //             editable={!isLoading}
// //           />

// //           <Text style={styles.label}>Phone Number</Text>
// //           <TextInput
// //             style={styles.input}
// //             placeholder="+2348012345678"
// //             placeholderTextColor="#999"
// //             keyboardType="phone-pad"
// //             value={phoneNumber}
// //             onChangeText={setPhoneNumber}
// //             editable={!isLoading}
// //           />

// //           <Text style={styles.label}>Create PIN</Text>
// //           <TextInput
// //             style={styles.input}
// //             placeholder="Enter 4-6 digit PIN"
// //             placeholderTextColor="#999"
// //             secureTextEntry
// //             keyboardType="numeric"
// //             maxLength={6}
// //             value={pin}
// //             onChangeText={setPin}
// //             editable={!isLoading}
// //           />

// //           <Text style={styles.label}>Confirm PIN</Text>
// //           <TextInput
// //             style={styles.input}
// //             placeholder="Confirm your PIN"
// //             placeholderTextColor="#999"
// //             secureTextEntry
// //             keyboardType="numeric"
// //             maxLength={6}
// //             value={confirmPin}
// //             onChangeText={setConfirmPin}
// //             editable={!isLoading}
// //           />

// //           <TouchableOpacity
// //             style={[styles.button, isLoading && styles.buttonDisabled]}
// //             onPress={handleSignUp}
// //             disabled={isLoading}
// //           >
// //             {isLoading ? (
// //               <ActivityIndicator color="#fff" />
// //             ) : (
// //               <Text style={styles.buttonText}>Create Account</Text>
// //             )}
// //           </TouchableOpacity>

// //           <TouchableOpacity
// //             style={styles.loginLink}
// //             onPress={() => navigation.goBack()}
// //             disabled={isLoading}
// //           >
// //             <Text style={styles.loginText}>
// //               Already have an account?{" "}
// //               <Text style={styles.loginBold}>Login</Text>
// //             </Text>
// //           </TouchableOpacity>
// //         </View>
// //       </ScrollView>
// //     </SafeAreaView>
// //   );
// // };

// // const styles = StyleSheet.create({
// //   container: {
// //     flex: 1,
// //     backgroundColor: "#fff",
// //   },
// //   header: {
// //     paddingHorizontal: 20,
// //     paddingVertical: 12,
// //   },
// //   backButton: {
// //     width: 44,
// //     height: 44,
// //     borderRadius: 22,
// //     backgroundColor: "#f5f5f5",
// //     justifyContent: "center",
// //     alignItems: "center",
// //   },
// //   content: {
// //     flex: 1,
// //     paddingHorizontal: 24,
// //   },
// //   logoContainer: {
// //     flexDirection: "row",
// //     alignItems: "center",
// //     gap: 8,
// //     marginBottom: 24,
// //   },
// //   logoText: {
// //     fontSize: 24,
// //     fontWeight: "700",
// //     color: "#1a1a2e",
// //   },
// //   title: {
// //     fontSize: 28,
// //     fontWeight: "700",
// //     color: "#1a1a2e",
// //     marginBottom: 8,
// //   },
// //   subtitle: {
// //     fontSize: 15,
// //     color: "#666",
// //     marginBottom: 32,
// //   },
// //   form: {
// //     paddingBottom: 40,
// //   },
// //   label: {
// //     fontSize: 14,
// //     fontWeight: "500",
// //     color: "#1a1a2e",
// //     marginBottom: 8,
// //   },
// //   input: {
// //     backgroundColor: "#f0f4f8",
// //     borderRadius: 12,
// //     paddingHorizontal: 16,
// //     paddingVertical: 16,
// //     fontSize: 16,
// //     color: "#1a1a2e",
// //     marginBottom: 20,
// //   },
// //   button: {
// //     backgroundColor: "#1a1a2e",
// //     height: 56,
// //     borderRadius: 12,
// //     justifyContent: "center",
// //     alignItems: "center",
// //     marginTop: 8,
// //   },
// //   buttonDisabled: {
// //     opacity: 0.7,
// //   },
// //   buttonText: {
// //     color: "#fff",
// //     fontSize: 16,
// //     fontWeight: "600",
// //   },
// //   loginLink: {
// //     alignItems: "center",
// //     marginTop: 20,
// //   },
// //   loginText: {
// //     fontSize: 14,
// //     color: "#666",
// //   },
// //   loginBold: {
// //     fontWeight: "700",
// //     color: "#1a1a2e",
// //   },
// // });

// // export default Signupscreen;

// import React, { useState } from "react";
// import {
//   View,
//   Text,
//   StyleSheet,
//   TextInput,
//   TouchableOpacity,
//   ScrollView,
//   Alert,
//   ActivityIndicator,
// } from "react-native";
// import { SafeAreaView } from "react-native-safe-area-context";
// import { Ionicons } from "@expo/vector-icons";
// import { useNavigation } from "@react-navigation/native";
// import { NativeStackNavigationProp } from "@react-navigation/native-stack";
// import axios from "axios";
// import { RootStackParamList } from "../../navigation/Stacknavigator";
// import { useDispatch } from "react-redux";
// import { login } from "../../redux/Authslice";
// import { API_CONFIG } from "../../../config/api";

// type SignUpScreenNavigationProp = NativeStackNavigationProp<
//   RootStackParamList,
//   "SignUp"
// >;
// const baseUrl = API_CONFIG.BASE_URL;

// const Signupscreen = () => {
//   const navigation = useNavigation<SignUpScreenNavigationProp>();
//   const dispatch = useDispatch();

//   const [firstName, setFirstName] = useState("");
//   const [lastName, setLastName] = useState("");
//   const [middleName, setMiddleName] = useState("");
//   const [email, setEmail] = useState("");
//   const [phoneNumber, setPhoneNumber] = useState("");
//   const [pin, setPin] = useState("");
//   const [confirmPin, setConfirmPin] = useState("");
//   const [referralCode, setReferralCode] = useState("");
//   const [isLoading, setIsLoading] = useState(false);

//   /**
//    * Converts any Nigerian number format to +234XXXXXXXXXX.
//    * Handles: 0812..., 812..., 234812..., +234812...
//    */
//   const formatToNigerianNumber = (number: string): string => {
//     const cleaned = number.trim().replace(/\s+/g, "");

//     // Already in correct +234 format
//     if (cleaned.startsWith("+234")) return cleaned;

//     // 234XXXXXXXXXX (no leading +)
//     if (cleaned.startsWith("234")) return `+${cleaned}`;

//     // 0XXXXXXXXXX — local format (11 digits starting with 0)
//     if (cleaned.startsWith("0") && cleaned.length === 11) {
//       return `+234${cleaned.substring(1)}`;
//     }

//     // XXXXXXXXXX — 10-digit without leading 0 (e.g. 8012345678)
//     if (!cleaned.startsWith("0") && cleaned.length === 10) {
//       return `+234${cleaned}`;
//     }

//     // Return as-is if format is unrecognised
//     return cleaned;
//   };

//   const handleSignUp = async () => {
//     // Validation
//     if (
//       !firstName ||
//       !lastName ||
//       !email ||
//       !phoneNumber ||
//       !pin ||
//       !confirmPin
//     ) {
//       Alert.alert("Error", "Please fill in all required fields");
//       return;
//     }
//     if (pin !== confirmPin) {
//       Alert.alert("Error", "PINs do not match");
//       return;
//     }
//     if (pin.length < 4) {
//       Alert.alert("Error", "PIN must be at least 4 digits");
//       return;
//     }

//     setIsLoading(true);

//     try {
//       const formattedPhone = formatToNigerianNumber(phoneNumber);

//       const response = await axios.post(`${baseUrl}register`, {
//         firstName: firstName.trim(),
//         lastName: lastName.trim(),
//         middleName: middleName.trim(),
//         email: email.toLowerCase().trim(),
//         pin: pin,
//         phoneNumber: formattedPhone,
//         tags: "user-tag",
//         referralCode: referralCode.trim() || "REF123",
//       });

//       console.log({ response: response.data });

//       const dispatch_data = response.data.data;
//       dispatch(login(dispatch_data));
//     } catch (error: any) {
//       const errorMessage =
//         error.response?.data?.message ||
//         "Registration failed. Please try again.";
//       Alert.alert("Signup Error", errorMessage);
//       console.error("Signup error details:", error.response?.data);
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   return (
//     <SafeAreaView style={styles.container}>
//       {/* Header */}
//       <View style={styles.header}>
//         <TouchableOpacity
//           style={styles.backButton}
//           onPress={() => navigation.goBack()}
//         >
//           <Ionicons name="arrow-back" size={24} color="#1a1a2e" />
//         </TouchableOpacity>
//       </View>

//       <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
//         {/* Logo */}
//         <View style={styles.logoContainer}>
//           <Ionicons name="swap-horizontal" size={32} color="#10b981" />
//           <Text style={styles.logoText}>Pay-la</Text>
//         </View>

//         <Text style={styles.title}>Create Account</Text>
//         <Text style={styles.subtitle}>Sign up to get started with Pay-la</Text>

//         {/* Form */}
//         <View style={styles.form}>
//           <Text style={styles.label}>First Name</Text>
//           <TextInput
//             style={styles.input}
//             placeholder="Enter your first name"
//             placeholderTextColor="#999"
//             value={firstName}
//             onChangeText={setFirstName}
//             editable={!isLoading}
//           />

//           <Text style={styles.label}>Last Name</Text>
//           <TextInput
//             style={styles.input}
//             placeholder="Enter your last name"
//             placeholderTextColor="#999"
//             value={lastName}
//             onChangeText={setLastName}
//             editable={!isLoading}
//           />

//           <Text style={styles.label}>Middle Name (Optional)</Text>
//           <TextInput
//             style={styles.input}
//             placeholder="Enter your middle name"
//             placeholderTextColor="#999"
//             value={middleName}
//             onChangeText={setMiddleName}
//             editable={!isLoading}
//           />

//           <Text style={styles.label}>Email Address</Text>
//           <TextInput
//             style={styles.input}
//             placeholder="Enter your email"
//             placeholderTextColor="#999"
//             keyboardType="email-address"
//             autoCapitalize="none"
//             value={email}
//             onChangeText={setEmail}
//             editable={!isLoading}
//           />

//           <Text style={styles.label}>Phone Number</Text>
//           <TextInput
//             style={styles.input}
//             placeholder="e.g. 08012345678 or +2348012345678"
//             placeholderTextColor="#999"
//             keyboardType="phone-pad"
//             value={phoneNumber}
//             onChangeText={setPhoneNumber}
//             editable={!isLoading}
//           />

//           <Text style={styles.label}>Create PIN</Text>
//           <TextInput
//             style={styles.input}
//             placeholder="Enter 4-6 digit PIN"
//             placeholderTextColor="#999"
//             secureTextEntry
//             keyboardType="numeric"
//             maxLength={6}
//             value={pin}
//             onChangeText={setPin}
//             editable={!isLoading}
//           />

//           <Text style={styles.label}>Confirm PIN</Text>
//           <TextInput
//             style={styles.input}
//             placeholder="Confirm your PIN"
//             placeholderTextColor="#999"
//             secureTextEntry
//             keyboardType="numeric"
//             maxLength={6}
//             value={confirmPin}
//             onChangeText={setConfirmPin}
//             editable={!isLoading}
//           />

//           <Text style={styles.label}>Referral Code (Optional)</Text>
//           <TextInput
//             style={styles.input}
//             placeholder="Enter referral code"
//             placeholderTextColor="#999"
//             autoCapitalize="characters"
//             value={referralCode}
//             onChangeText={setReferralCode}
//             editable={!isLoading}
//           />

//           <TouchableOpacity
//             style={[styles.button, isLoading && styles.buttonDisabled]}
//             onPress={handleSignUp}
//             disabled={isLoading}
//           >
//             {isLoading ? (
//               <ActivityIndicator color="#fff" />
//             ) : (
//               <Text style={styles.buttonText}>Create Account</Text>
//             )}
//           </TouchableOpacity>

//           <TouchableOpacity
//             style={styles.loginLink}
//             onPress={() => navigation.goBack()}
//             disabled={isLoading}
//           >
//             <Text style={styles.loginText}>
//               Already have an account?
//               <Text style={styles.loginBold}>Login</Text>
//             </Text>
//           </TouchableOpacity>
//         </View>
//       </ScrollView>
//     </SafeAreaView>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "#fff",
//   },
//   header: {
//     paddingHorizontal: 20,
//     paddingVertical: 12,
//   },
//   backButton: {
//     width: 44,
//     height: 44,
//     borderRadius: 22,
//     backgroundColor: "#f5f5f5",
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   content: {
//     flex: 1,
//     paddingHorizontal: 24,
//   },
//   logoContainer: {
//     flexDirection: "row",
//     alignItems: "center",
//     gap: 8,
//     marginBottom: 24,
//   },
//   logoText: {
//     fontSize: 24,
//     fontWeight: "700",
//     color: "#1a1a2e",
//   },
//   title: {
//     fontSize: 28,
//     fontWeight: "700",
//     color: "#1a1a2e",
//     marginBottom: 8,
//   },
//   subtitle: {
//     fontSize: 15,
//     color: "#666",
//     marginBottom: 32,
//   },
//   form: {
//     paddingBottom: 40,
//   },
//   label: {
//     fontSize: 14,
//     fontWeight: "500",
//     color: "#1a1a2e",
//     marginBottom: 8,
//   },
//   input: {
//     backgroundColor: "#f0f4f8",
//     borderRadius: 12,
//     paddingHorizontal: 16,
//     paddingVertical: 16,
//     fontSize: 16,
//     color: "#1a1a2e",
//     marginBottom: 20,
//   },
//   button: {
//     backgroundColor: "#1a1a2e",
//     height: 56,
//     borderRadius: 12,
//     justifyContent: "center",
//     alignItems: "center",
//     marginTop: 8,
//   },
//   buttonDisabled: {
//     opacity: 0.7,
//   },
//   buttonText: {
//     color: "#fff",
//     fontSize: 16,
//     fontWeight: "600",
//   },
//   loginLink: {
//     alignItems: "center",
//     marginTop: 20,
//   },
//   loginText: {
//     fontSize: 14,
//     color: "#666",
//   },
//   loginBold: {
//     fontWeight: "700",
//     color: "#1a1a2e",
//   },
// });

// export default Signupscreen;

import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import axios from "axios";
import { useDispatch } from "react-redux";
import { login } from "../../redux/Authslice";
import { API_CONFIG } from "../../../config/api";

const baseUrl = API_CONFIG.BASE_URL;

// ✅ Accept onShowLogin prop instead of using useNavigation
interface SignupscreenProps {
  onShowLogin: () => void;
}

const Signupscreen = ({ onShowLogin }: SignupscreenProps) => {
  const dispatch = useDispatch();

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [middleName, setMiddleName] = useState("");
  const [email, setEmail] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [pin, setPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [referralCode, setReferralCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  /**
   * Converts any Nigerian number format to +234XXXXXXXXXX.
   * Handles: 0812..., 812..., 234812..., +234812...
   */
  const formatToNigerianNumber = (number: string): string => {
    const cleaned = number.trim().replace(/\s+/g, "");

    if (cleaned.startsWith("+234")) return cleaned;
    if (cleaned.startsWith("234")) return `+${cleaned}`;
    if (cleaned.startsWith("0") && cleaned.length === 11) {
      return `+234${cleaned.substring(1)}`;
    }
    if (!cleaned.startsWith("0") && cleaned.length === 10) {
      return `+234${cleaned}`;
    }

    return cleaned;
  };

  const handleSignUp = async () => {
    if (
      !firstName ||
      !lastName ||
      !email ||
      !phoneNumber ||
      !pin ||
      !confirmPin
    ) {
      Alert.alert("Error", "Please fill in all required fields");
      return;
    }
    if (pin !== confirmPin) {
      Alert.alert("Error", "PINs do not match");
      return;
    }
    if (pin.length < 4) {
      Alert.alert("Error", "PIN must be at least 4 digits");
      return;
    }

    setIsLoading(true);

    try {
      const formattedPhone = formatToNigerianNumber(phoneNumber);

      const response = await axios.post(`${baseUrl}register`, {
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        middleName: middleName.trim(),
        email: email.toLowerCase().trim(),
        pin: pin,
        phoneNumber: formattedPhone,
        tags: "user-tag",
        referralCode: referralCode.trim() || "REF123",
      });

      console.log({ response: response.data });

      const dispatch_data = response.data.data;
      dispatch(login(dispatch_data));
    } catch (error: any) {
      const errorMessage =
        error.response?.data?.message ||
        "Registration failed. Please try again.";
      Alert.alert("Signup Error", errorMessage);
      console.error("Signup error details:", error.response?.data);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        {/* ✅ onShowLogin replaces navigation.goBack() */}
        <TouchableOpacity
          style={styles.backButton}
          onPress={onShowLogin}
          disabled={isLoading}
        >
          <Ionicons name="arrow-back" size={24} color="#1a1a2e" />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
        {/* Logo */}
        <View style={styles.logoContainer}>
          <Ionicons name="swap-horizontal" size={32} color="#10b981" />
          <Text style={styles.logoText}>Pay-la</Text>
        </View>

        <Text style={styles.title}>Create Account</Text>
        <Text style={styles.subtitle}>Sign up to get started with Pay-la</Text>

        {/* Form */}
        <View style={styles.form}>
          <Text style={styles.label}>First Name</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your first name"
            placeholderTextColor="#999"
            value={firstName}
            onChangeText={setFirstName}
            editable={!isLoading}
          />

          <Text style={styles.label}>Last Name</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your last name"
            placeholderTextColor="#999"
            value={lastName}
            onChangeText={setLastName}
            editable={!isLoading}
          />

          <Text style={styles.label}>Middle Name (Optional)</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your middle name"
            placeholderTextColor="#999"
            value={middleName}
            onChangeText={setMiddleName}
            editable={!isLoading}
          />

          <Text style={styles.label}>Email Address</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your email"
            placeholderTextColor="#999"
            keyboardType="email-address"
            autoCapitalize="none"
            value={email}
            onChangeText={setEmail}
            editable={!isLoading}
          />

          <Text style={styles.label}>Phone Number</Text>
          <TextInput
            style={styles.input}
            placeholder="e.g. 08012345678 or +2348012345678"
            placeholderTextColor="#999"
            keyboardType="phone-pad"
            value={phoneNumber}
            onChangeText={setPhoneNumber}
            editable={!isLoading}
          />

          <Text style={styles.label}>Create PIN</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter 4-6 digit PIN"
            placeholderTextColor="#999"
            secureTextEntry
            keyboardType="numeric"
            maxLength={6}
            value={pin}
            onChangeText={setPin}
            editable={!isLoading}
          />

          <Text style={styles.label}>Confirm PIN</Text>
          <TextInput
            style={styles.input}
            placeholder="Confirm your PIN"
            placeholderTextColor="#999"
            secureTextEntry
            keyboardType="numeric"
            maxLength={6}
            value={confirmPin}
            onChangeText={setConfirmPin}
            editable={!isLoading}
          />

          <Text style={styles.label}>Referral Code (Optional)</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter referral code"
            placeholderTextColor="#999"
            autoCapitalize="characters"
            value={referralCode}
            onChangeText={setReferralCode}
            editable={!isLoading}
          />

          <TouchableOpacity
            style={[styles.button, isLoading && styles.buttonDisabled]}
            onPress={handleSignUp}
            disabled={isLoading}
          >
            {isLoading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>Create Account</Text>
            )}
          </TouchableOpacity>

          {/* ✅ onShowLogin replaces navigation.goBack() */}
          <TouchableOpacity
            style={styles.loginLink}
            onPress={onShowLogin}
            disabled={isLoading}
          >
            <Text style={styles.loginText}>
              Already have an account?{" "}
              <Text style={styles.loginBold}>Login</Text>
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: "#f5f5f5",
    justifyContent: "center",
    alignItems: "center",
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
  },
  logoContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginBottom: 24,
  },
  logoText: {
    fontSize: 24,
    fontWeight: "700",
    color: "#1a1a2e",
  },
  title: {
    fontSize: 28,
    fontWeight: "700",
    color: "#1a1a2e",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 15,
    color: "#666",
    marginBottom: 32,
  },
  form: {
    paddingBottom: 40,
  },
  label: {
    fontSize: 14,
    fontWeight: "500",
    color: "#1a1a2e",
    marginBottom: 8,
  },
  input: {
    backgroundColor: "#f0f4f8",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 16,
    fontSize: 16,
    color: "#1a1a2e",
    marginBottom: 20,
  },
  button: {
    backgroundColor: "#1a1a2e",
    height: 56,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 8,
  },
  buttonDisabled: {
    opacity: 0.7,
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  loginLink: {
    alignItems: "center",
    marginTop: 20,
  },
  loginText: {
    fontSize: 14,
    color: "#666",
  },
  loginBold: {
    fontWeight: "700",
    color: "#1a1a2e",
  },
});

export default Signupscreen;
