import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  ScrollView,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import axios from "axios";
import { API_CONFIG } from "../../../config/api";

interface ResetPinProps {
  email: string;
  onShowLogin: () => void;
  onBack: () => void;
}

const baseUrl = API_CONFIG.BASE_URL;

const Resetpinscreen = ({ email, onShowLogin, onBack }: ResetPinProps) => {
  const [otp, setOtp] = useState("");
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(true);

  const handleResetPin = async () => {
    if (!otp) {
      Alert.alert("Error", "Please enter the OTP");
      return;
    }
    if (!newPin || newPin.length < 4) {
      Alert.alert("Error", "PIN must be at least 4 digits");
      return;
    }
    if (newPin !== confirmPin) {
      Alert.alert("Error", "PINs do not match");
      return;
    }

    setIsLoading(true);

    try {
      const response = await axios.post(`${baseUrl}reset`, {
        email: email,
        otp: otp,
        newPin: newPin,
      });

      if (response.status === 200 || response.status === 201) {
        Alert.alert("Success", "Your PIN has been reset successfully!", [
          { text: "Sign In", onPress: onShowLogin },
        ]);
      }
    } catch (error: any) {
      const errorMessage =
        error.response?.data?.message ||
        "Failed to reset PIN. Please try again.";
      Alert.alert("Error", errorMessage);
      console.error("Reset PIN error:", error.response?.data);
    } finally {
      setIsLoading(false);
    }
  };

  const isFormValid =
    otp.length > 0 && newPin.length >= 4 && newPin === confirmPin;

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={styles.content}>
          {/* Logo */}
          <View style={styles.logoContainer}>
            <Ionicons name="swap-horizontal" size={28} color="#10b981" />
            <Text style={styles.logoText}>Pay-la</Text>
          </View>

          {/* Title */}
          <Text style={styles.title}>Reset PIN</Text>
          <Text style={styles.subtitle}>
            Enter the OTP sent to your email and your new PIN.
          </Text>

          {/* Card */}
          <View style={styles.card}>
            {/* Email (readonly) */}
            <Text style={styles.label}>Email Address</Text>
            <TextInput
              style={[styles.input, styles.inputDisabled]}
              value={email}
              editable={false}
            />

            {/* OTP */}
            <Text style={styles.label}>OTP</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter OTP"
              placeholderTextColor="#999"
              keyboardType="numeric"
              maxLength={6}
              value={otp}
              onChangeText={setOtp}
              editable={!isLoading}
            />

            {/* New PIN */}
            <Text style={styles.label}>New PIN</Text>
            <TextInput
              style={styles.input}
              placeholder="1234"
              placeholderTextColor="#999"
              secureTextEntry
              keyboardType="numeric"
              maxLength={6}
              value={newPin}
              onChangeText={setNewPin}
              editable={!isLoading}
            />

            {/* Confirm New PIN */}
            <Text style={styles.label}>Confirm New PIN</Text>
            <TextInput
              style={styles.input}
              placeholder="1234"
              placeholderTextColor="#999"
              secureTextEntry
              keyboardType="numeric"
              maxLength={6}
              value={confirmPin}
              onChangeText={setConfirmPin}
              editable={!isLoading}
            />

            {/* Success Banner */}
            {otpSent && (
              <View style={styles.successBanner}>
                <Text style={styles.successText}>Password reset OTP sent</Text>
              </View>
            )}

            {/* Reset Button */}
            <TouchableOpacity
              style={[
                styles.resetButton,
                !isFormValid && styles.resetButtonDisabled,
              ]}
              onPress={handleResetPin}
              disabled={!isFormValid || isLoading}
            >
              {isLoading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text
                  style={[
                    styles.resetButtonText,
                    !isFormValid && styles.resetButtonTextDisabled,
                  ]}
                >
                  Reset PIN
                </Text>
              )}
            </TouchableOpacity>

            {/* Footer Links */}
            <View style={styles.footer}>
              <TouchableOpacity onPress={onBack}>
                <Text style={styles.backText}>← Back</Text>
              </TouchableOpacity>

              <TouchableOpacity onPress={onShowLogin}>
                <Text style={styles.signInBold}>Sign in</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  scrollContent: {
    flexGrow: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 40,
    paddingBottom: 24,
  },
  logoContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    marginBottom: 32,
  },
  logoText: {
    fontSize: 20,
    fontWeight: "700",
    color: "#1a1a2e",
  },
  title: {
    fontSize: 32,
    fontWeight: "700",
    color: "#1a1a2e",
    textAlign: "center",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 15,
    color: "#666",
    textAlign: "center",
    marginBottom: 32,
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    padding: 24,
  },
  label: {
    fontSize: 14,
    fontWeight: "500",
    color: "#1a1a2e",
    marginBottom: 8,
  },
  input: {
    backgroundColor: "#f9f9f9",
    borderWidth: 1,
    borderColor: "#e5e5e5",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 16,
    fontSize: 16,
    color: "#1a1a2e",
    marginBottom: 20,
  },
  inputDisabled: {
    backgroundColor: "#f0f0f0",
    color: "#666",
  },
  successBanner: {
    backgroundColor: "#d1fae5",
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  successText: {
    fontSize: 14,
    color: "#10b981",
    fontWeight: "500",
    textAlign: "center",
  },
  resetButton: {
    backgroundColor: "#10b981",
    height: 56,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 20,
  },
  resetButtonDisabled: {
    backgroundColor: "#d1d5db",
  },
  resetButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  resetButtonTextDisabled: {
    color: "#9ca3af",
  },
  footer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  backText: {
    fontSize: 14,
    fontWeight: "500",
    color: "#1a1a2e",
  },
  signInBold: {
    fontSize: 14,
    fontWeight: "700",
    color: "#1a1a2e",
  },
});

export default Resetpinscreen;
