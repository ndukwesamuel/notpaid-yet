import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import axios from "axios";
import { API_CONFIG } from "../../../config/api";

interface ForgotPinProps {
  onShowLogin: () => void;
  onShowReset: (email: string) => void;
}

const baseUrl = API_CONFIG.BASE_URL;

const Forgotpinscreen = ({ onShowLogin, onShowReset }: ForgotPinProps) => {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSendOtp = async () => {
    if (!email) {
      Alert.alert("Error", "Please enter your email address");
      return;
    }

    setIsLoading(true);

    try {
      const response = await axios.get(
        `${baseUrl}reset/${email.toLowerCase().trim()}`,
      );

      if (response.status === 200 || response.status === 201) {
        // Navigate to Reset PIN screen with email
        onShowReset(email.toLowerCase().trim());
      }
    } catch (error: any) {
      const errorMessage =
        error.response?.data?.message ||
        "Failed to send OTP. Please try again.";
      Alert.alert("Error", errorMessage);
      console.error("Forgot PIN error:", error.response?.data);
    } finally {
      setIsLoading(false);
    }
  };

  const isEmailValid = email.length > 0;

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.keyboardView}
      >
        <View style={styles.content}>
          {/* Logo */}
          <View style={styles.logoContainer}>
            <Ionicons name="swap-horizontal" size={28} color="#10b981" />
            <Text style={styles.logoText}>Pay-la</Text>
          </View>

          {/* Title */}
          <Text style={styles.title}>Forgot PIN</Text>
          <Text style={styles.subtitle}>
            Enter your email to receive an OTP.
          </Text>

          {/* Card */}
          <View style={styles.card}>
            <Text style={styles.label}>Email Address</Text>
            <TextInput
              style={styles.input}
              placeholder="you@example.com"
              placeholderTextColor="#999"
              keyboardType="email-address"
              autoCapitalize="none"
              value={email}
              onChangeText={setEmail}
              editable={!isLoading}
            />

            <TouchableOpacity
              style={[
                styles.sendButton,
                !isEmailValid && styles.sendButtonDisabled,
              ]}
              onPress={handleSendOtp}
              disabled={!isEmailValid || isLoading}
            >
              {isLoading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text
                  style={[
                    styles.sendButtonText,
                    !isEmailValid && styles.sendButtonTextDisabled,
                  ]}
                >
                  Send OTP
                </Text>
              )}
            </TouchableOpacity>

            {/* Sign In Link */}
            <TouchableOpacity style={styles.signInLink} onPress={onShowLogin}>
              <Text style={styles.signInText}>
                Remember your PIN?{" "}
                <Text style={styles.signInBold}>Sign in</Text>
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  keyboardView: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 40,
  },
  logoContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    marginBottom: 32,
  },
  logoText: {
    fontSize: 20,
    fontWeight: "700",
    color: "#1a1a2e",
  },
  title: {
    fontSize: 32,
    fontWeight: "700",
    color: "#1a1a2e",
    textAlign: "center",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 15,
    color: "#666",
    textAlign: "center",
    marginBottom: 32,
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    padding: 24,
  },
  label: {
    fontSize: 14,
    fontWeight: "500",
    color: "#1a1a2e",
    marginBottom: 12,
  },
  input: {
    backgroundColor: "#f9f9f9",
    borderWidth: 1,
    borderColor: "#e5e5e5",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 16,
    fontSize: 16,
    color: "#1a1a2e",
    marginBottom: 24,
  },
  sendButton: {
    backgroundColor: "#10b981",
    height: 56,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 20,
  },
  sendButtonDisabled: {
    backgroundColor: "#d1d5db",
  },
  sendButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  sendButtonTextDisabled: {
    color: "#9ca3af",
  },
  signInLink: {
    alignItems: "center",
  },
  signInText: {
    fontSize: 14,
    color: "#666",
  },
  signInBold: {
    fontWeight: "700",
    color: "#1a1a2e",
  },
});

export default Forgotpinscreen;
