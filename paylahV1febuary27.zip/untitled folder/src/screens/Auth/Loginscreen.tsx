import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ImageBackground,
  KeyboardAvoidingView,
  Platform,
  Alert,
  Dimensions,
  ActivityIndicator,
} from "react-native";
import axios from "axios";
import { Ionicons } from "@expo/vector-icons";
import { API_CONFIG } from "../../../config/api";
import { useDispatch } from "react-redux";
import { emailData, login } from "../../redux/Authslice";

const { height } = Dimensions.get("window");

// Define the interface for props passed from AuthNavigation
interface LoginProps {
  onShowSignup: () => void;
  onShowForgot: () => void;
}

const baseUrl = API_CONFIG.BASE_URL;

const Loginscreen = ({ onShowSignup, onShowForgot }: LoginProps) => {
  const [email, setEmail] = useState("");
  const [pin, setPin] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [activeSlide] = useState(0);

  const dispatch = useDispatch();

  const handleLogin = async () => {
    if (!email || !pin) {
      Alert.alert("Error", "Please fill in all fields");
      return;
    }

    setIsLoading(true);

    try {
      // API Call
      const response = await axios.post(`${baseUrl}login`, {
        email: email.toLowerCase().trim(),
        pin: pin,
      });

      if (response.status === 200 || response.status === 201) {
        const dispatch_data = response.data.data;
        console.log("Login Success:", dispatch_data);

        // Update Redux Store
        dispatch(emailData(email.toLowerCase().trim()));
        dispatch(login(dispatch_data));

        Alert.alert("Success", "Welcome back!");
      }
    } catch (error: any) {
      console.log({
        yyyy: error.response.data,
      });

      const errorMessage =
        error.response?.data?.message ||
        "Something went wrong. Please try again.";
      Alert.alert("Login Failed", errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <ImageBackground
        source={{
          uri: "https://images.unsplash.com/photo-1553877522-43269d4ea984?w=800",
        }}
        style={styles.backgroundImage}
        resizeMode="cover"
      >
        <View style={styles.overlay}>
          {/* Carousel Dots */}
          <View style={styles.dotsContainer}>
            {[0, 1, 2].map((i) => (
              <View
                key={i}
                style={[
                  styles.dot,
                  activeSlide === i ? styles.activeDot : styles.inactiveDot,
                ]}
              />
            ))}
          </View>

          {/* Hero Content */}
          <View style={styles.heroContent}>
            <Text style={styles.heroText}>
              Open an{"\n"}international bank{"\n"}account
            </Text>
            {/* CORRECTED: Changed div to View */}
            <View style={styles.logoContainer}>
              <Ionicons name="swap-horizontal" size={20} color="#10b981" />
              <Text style={styles.logoText}>Pay-la</Text>
            </View>
          </View>
        </View>
      </ImageBackground>

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.formContainer}
      >
        <View style={styles.formCard}>
          <Text style={styles.label}>Email Address</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your email"
            placeholderTextColor="#999"
            keyboardType="email-address"
            autoCapitalize="none"
            value={email}
            onChangeText={setEmail}
            editable={!isLoading}
          />

          <Text style={styles.label}>PIN</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your PIN"
            placeholderTextColor="#999"
            secureTextEntry
            keyboardType="numeric"
            maxLength={6}
            value={pin}
            onChangeText={setPin}
            editable={!isLoading}
          />

          <TouchableOpacity
            style={[styles.button, isLoading && { opacity: 0.7 }]}
            onPress={handleLogin}
            disabled={isLoading}
          >
            {isLoading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>Get started</Text>
            )}
          </TouchableOpacity>

          <View style={styles.footer}>
            <TouchableOpacity onPress={onShowForgot}>
              <Text style={styles.forgotText}>Forgot PIN?</Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={onShowSignup}>
              <Text style={styles.signUpText}>
                Don't have an account?{" "}
                <Text style={styles.signUpBold}>Sign up</Text>
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#1a1a2e" },
  backgroundImage: { height: height * 0.45 },
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    paddingHorizontal: 24,
    paddingTop: 60,
  },
  dotsContainer: { flexDirection: "row", gap: 8 },
  dot: { height: 4, borderRadius: 2 },
  activeDot: { width: 32, backgroundColor: "#fff" },
  inactiveDot: { width: 16, backgroundColor: "rgba(255, 255, 255, 0.4)" },
  heroContent: { flex: 1, justifyContent: "center" },
  heroText: {
    fontSize: 36,
    fontWeight: "700",
    color: "#fff",
    lineHeight: 44,
    marginBottom: 24,
  },
  logoContainer: { flexDirection: "row", alignItems: "center", gap: 6 },
  logoText: { fontSize: 18, fontWeight: "600", color: "#10b981" },
  formContainer: { flex: 1, marginTop: -40 },
  formCard: {
    flex: 1,
    backgroundColor: "#fff",
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    paddingHorizontal: 24,
    paddingTop: 32,
  },
  label: { fontSize: 14, fontWeight: "500", color: "#1a1a2e", marginBottom: 8 },
  input: {
    backgroundColor: "#f0f4f8",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 16,
    fontSize: 16,
    color: "#1a1a2e",
    marginBottom: 20,
  },
  button: {
    backgroundColor: "#1a1a2e",
    height: 56,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 8,
  },
  buttonText: { color: "#fff", fontSize: 16, fontWeight: "600" },
  footer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 20,
  },
  forgotText: { fontSize: 14, fontWeight: "500", color: "#1a1a2e" },
  signUpText: { fontSize: 14, color: "#666" },
  signUpBold: { fontWeight: "700", color: "#1a1a2e" },
});

export default Loginscreen;
