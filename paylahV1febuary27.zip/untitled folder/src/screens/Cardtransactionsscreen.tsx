import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  RefreshControl,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { useFetchData_v2 } from "../hooks/Requestv2";
// import { useFetchData_v2 } from "../hooks/Requestv2";

// ─── Types ────────────────────────────────────────────────────────
interface CardTransaction {
  id: string;
  type: string;
  amount: number;
  currency: string;
  status: string;
  description: string;
  merchantName?: string;
  merchantCategory?: string;
  createdAt: string;
  reference?: string;
}

// ─── Helpers ──────────────────────────────────────────────────────
const getTransactionIcon = (type: string): any => {
  const t = type?.toUpperCase();
  if (t?.includes("FUND") || t?.includes("CREDIT") || t?.includes("TOPUP"))
    return "arrow-down-circle";
  if (t?.includes("DEBIT") || t?.includes("PURCHASE") || t?.includes("PAYMENT"))
    return "arrow-up-circle";
  if (t?.includes("REFUND")) return "refresh-circle";
  if (t?.includes("REVERSAL")) return "return-up-back";
  return "swap-horizontal";
};

const getTransactionColor = (type: string, status: string) => {
  if (status?.toUpperCase() === "FAILED") return "#ef4444";
  const t = type?.toUpperCase();
  if (t?.includes("FUND") || t?.includes("CREDIT") || t?.includes("TOPUP"))
    return "#10b981";
  return "#1a1a2e";
};

const getStatusStyle = (status: string) => {
  switch (status?.toUpperCase()) {
    case "SUCCESSFUL":
    case "SUCCESS":
    case "COMPLETED":
      return { bg: "#f0fdf7", text: "#059669" };
    case "PENDING":
      return { bg: "#fff8e1", text: "#f57f17" };
    case "FAILED":
      return { bg: "#fff0f0", text: "#dc2626" };
    case "REVERSED":
      return { bg: "#f5f5f5", text: "#666" };
    default:
      return { bg: "#f5f5f5", text: "#888" };
  }
};

const isCredit = (type: string) => {
  const t = type?.toUpperCase();
  return (
    t?.includes("FUND") ||
    t?.includes("CREDIT") ||
    t?.includes("TOPUP") ||
    t?.includes("REFUND")
  );
};

const formatDate = (dateStr: string) => {
  const date = new Date(dateStr);
  return date.toLocaleDateString("en-NG", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
};

const formatTime = (dateStr: string) => {
  const date = new Date(dateStr);
  return date.toLocaleTimeString("en-NG", {
    hour: "2-digit",
    minute: "2-digit",
  });
};

const groupByDate = (transactions: CardTransaction[]) => {
  const groups: { [key: string]: CardTransaction[] } = {};
  transactions.forEach((tx) => {
    const key = formatDate(tx.createdAt);
    if (!groups[key]) groups[key] = [];
    groups[key].push(tx);
  });
  return Object.entries(groups).map(([date, data]) => ({ date, data }));
};

// ─── Transaction Item ─────────────────────────────────────────────
const TransactionItem = ({ item }: { item: CardTransaction }) => {
  const [expanded, setExpanded] = useState(false);
  const credit = isCredit(item.type);
  const amountColor = getTransactionColor(item.type, item.status);
  const statusStyle = getStatusStyle(item.status);
  const icon = getTransactionIcon(item.type);

  return (
    <TouchableOpacity
      style={styles.txItem}
      onPress={() => setExpanded((prev) => !prev)}
      activeOpacity={0.7}
    >
      <View style={styles.txMain}>
        {/* Icon */}
        <View
          style={[
            styles.txIconWrap,
            { backgroundColor: credit ? "#f0fdf7" : "#f5f7fa" },
          ]}
        >
          <Ionicons name={icon} size={22} color={amountColor} />
        </View>

        {/* Info */}
        <View style={styles.txInfo}>
          <Text style={styles.txTitle} numberOfLines={1}>
            {item.merchantName || item.description || item.type}
          </Text>
          <Text style={styles.txMeta}>
            {formatTime(item.createdAt)}
            {item.merchantCategory ? `  ·  ${item.merchantCategory}` : ""}
          </Text>
        </View>

        {/* Amount + Status */}
        <View style={styles.txRight}>
          <Text style={[styles.txAmount, { color: amountColor }]}>
            {credit ? "+" : "-"}$
            {Math.abs(item.amount).toLocaleString("en-NG", {
              minimumFractionDigits: 2,
            })}
          </Text>
          <View
            style={[styles.txStatusBadge, { backgroundColor: statusStyle.bg }]}
          >
            <Text style={[styles.txStatusText, { color: statusStyle.text }]}>
              {item.status}
            </Text>
          </View>
        </View>
      </View>

      {/* Expanded Details */}
      {expanded && (
        <View style={styles.txDetails}>
          <View style={styles.txDetailDivider} />
          {item.reference && (
            <DetailLine label="Reference" value={item.reference} />
          )}
          <DetailLine label="Type" value={item.type} />
          <DetailLine label="Currency" value={item.currency || "USD"} />
          <DetailLine label="Date" value={formatDate(item.createdAt)} />
          {item.description && (
            <DetailLine label="Description" value={item.description} />
          )}
        </View>
      )}
    </TouchableOpacity>
  );
};

const DetailLine = ({ label, value }: { label: string; value: string }) => (
  <View style={styles.detailLine}>
    <Text style={styles.detailLineLabel}>{label}</Text>
    <Text style={styles.detailLineValue}>{value}</Text>
  </View>
);

// ─── Main Screen ──────────────────────────────────────────────────
const CardTransactionsScreen = () => {
  const navigation = useNavigation();
  const [refreshing, setRefreshing] = useState(false);

  const { data, isLoading, isError, refetch } = useFetchData_v2(
    "account/getCardTransactions",
    "cardTransactions",
  );

  const rawTransactions: CardTransaction[] =
    data?.data?.data || data?.data || [];
  const grouped = groupByDate(rawTransactions);

  const onRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  // ─── Loading ────────────────────────────────────────────────
  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <Header onBack={() => navigation.goBack()} />
        <View style={styles.centeredState}>
          <ActivityIndicator size="large" color="#1a1a2e" />
          <Text style={styles.stateText}>Loading transactions...</Text>
        </View>
      </SafeAreaView>
    );
  }

  // ─── Error ──────────────────────────────────────────────────
  if (isError) {
    return (
      <SafeAreaView style={styles.container}>
        <Header onBack={() => navigation.goBack()} />
        <View style={styles.centeredState}>
          <Ionicons name="alert-circle-outline" size={52} color="#ef4444" />
          <Text style={styles.stateTitle}>Failed to load</Text>
          <Text style={styles.stateText}>
            Could not fetch your card transactions
          </Text>
          <TouchableOpacity
            style={styles.retryButton}
            onPress={() => refetch()}
          >
            <Text style={styles.retryText}>Try Again</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // ─── Empty ──────────────────────────────────────────────────
  if (rawTransactions.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <Header onBack={() => navigation.goBack()} />
        <View style={styles.centeredState}>
          <View style={styles.emptyIconWrap}>
            <Ionicons name="receipt-outline" size={40} color="#1a1a2e" />
          </View>
          <Text style={styles.stateTitle}>No transactions yet</Text>
          <Text style={styles.stateText}>
            Your USD card transactions will appear here
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  // ─── Summary Stats ───────────────────────────────────────────
  const totalSpent = rawTransactions
    .filter((tx) => !isCredit(tx.type) && tx.status?.toUpperCase() !== "FAILED")
    .reduce((sum, tx) => sum + Math.abs(tx.amount), 0);

  const totalFunded = rawTransactions
    .filter((tx) => isCredit(tx.type) && tx.status?.toUpperCase() !== "FAILED")
    .reduce((sum, tx) => sum + Math.abs(tx.amount), 0);

  return (
    <SafeAreaView style={styles.container}>
      <Header onBack={() => navigation.goBack()} />

      <FlatList
        data={grouped}
        keyExtractor={(item) => item.date}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#1a1a2e"
          />
        }
        ListHeaderComponent={() => (
          <>
            {/* ── Summary Card ── */}
            <View style={styles.summaryCard}>
              <View style={styles.summaryItem}>
                <View style={styles.summaryIconWrap}>
                  <Ionicons name="arrow-up-circle" size={20} color="#ef4444" />
                </View>
                <Text style={styles.summaryLabel}>Total Spent</Text>
                <Text style={styles.summaryValue}>
                  $
                  {totalSpent.toLocaleString("en-NG", {
                    minimumFractionDigits: 2,
                  })}
                </Text>
              </View>
              <View style={styles.summaryDivider} />
              <View style={styles.summaryItem}>
                <View
                  style={[
                    styles.summaryIconWrap,
                    { backgroundColor: "#f0fdf7" },
                  ]}
                >
                  <Ionicons
                    name="arrow-down-circle"
                    size={20}
                    color="#10b981"
                  />
                </View>
                <Text style={styles.summaryLabel}>Total Funded</Text>
                <Text style={[styles.summaryValue, { color: "#10b981" }]}>
                  $
                  {totalFunded.toLocaleString("en-NG", {
                    minimumFractionDigits: 2,
                  })}
                </Text>
              </View>
              <View style={styles.summaryDivider} />
              <View style={styles.summaryItem}>
                <View
                  style={[
                    styles.summaryIconWrap,
                    { backgroundColor: "#f0f4ff" },
                  ]}
                >
                  <Ionicons name="layers-outline" size={20} color="#6366f1" />
                </View>
                <Text style={styles.summaryLabel}>Transactions</Text>
                <Text style={[styles.summaryValue, { color: "#6366f1" }]}>
                  {rawTransactions.length}
                </Text>
              </View>
            </View>

            <Text style={styles.tapHint}>Tap a transaction to see details</Text>
          </>
        )}
        renderItem={({ item: group }) => (
          <View style={styles.group}>
            {/* Date header */}
            <View style={styles.dateHeader}>
              <Text style={styles.dateHeaderText}>{group.date}</Text>
              <View style={styles.dateHeaderLine} />
            </View>

            {/* Transactions in this group */}
            <View style={styles.txCard}>
              {group.data.map((tx, index) => (
                <View key={tx.id || index}>
                  <TransactionItem item={tx} />
                  {index < group.data.length - 1 && (
                    <View style={styles.txDivider} />
                  )}
                </View>
              ))}
            </View>
          </View>
        )}
        ListFooterComponent={() => <View style={{ height: 40 }} />}
      />
    </SafeAreaView>
  );
};

// ─── Header ───────────────────────────────────────────────────────
const Header = ({ onBack }: { onBack: () => void }) => (
  <View style={styles.header}>
    <TouchableOpacity style={styles.backButton} onPress={onBack}>
      <Ionicons name="arrow-back" size={24} color="#1a1a2e" />
    </TouchableOpacity>
    <Text style={styles.headerTitle}>Card Transactions</Text>
    <View style={{ width: 40 }} />
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f5f5f5" },

  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e5e5",
    backgroundColor: "#fff",
  },
  headerTitle: { fontSize: 18, fontWeight: "700", color: "#1a1a2e" },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },

  centeredState: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    gap: 12,
    paddingHorizontal: 32,
  },
  stateTitle: { fontSize: 17, fontWeight: "700", color: "#1a1a2e" },
  stateText: {
    fontSize: 14,
    color: "#888",
    textAlign: "center",
    lineHeight: 20,
  },
  retryButton: {
    backgroundColor: "#1a1a2e",
    paddingHorizontal: 28,
    paddingVertical: 12,
    borderRadius: 10,
    marginTop: 4,
  },
  retryText: { color: "#fff", fontWeight: "600", fontSize: 14 },
  emptyIconWrap: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: "#f0f4f8",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 8,
  },

  listContent: { padding: 16 },

  // ── Summary ──────────────────────────────────────────────────
  summaryCard: {
    flexDirection: "row",
    backgroundColor: "#fff",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    marginBottom: 8,
    overflow: "hidden",
  },
  summaryItem: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 16,
    paddingHorizontal: 8,
    gap: 4,
  },
  summaryIconWrap: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "#fff0f0",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 4,
  },
  summaryDivider: { width: 1, backgroundColor: "#f0f0f0" },
  summaryLabel: {
    fontSize: 10,
    fontWeight: "600",
    color: "#999",
    textTransform: "uppercase",
    letterSpacing: 0.4,
  },
  summaryValue: {
    fontSize: 14,
    fontWeight: "700",
    color: "#ef4444",
  },

  tapHint: {
    fontSize: 12,
    color: "#bbb",
    textAlign: "center",
    marginBottom: 16,
    marginTop: 4,
  },

  // ── Group ────────────────────────────────────────────────────
  group: { marginBottom: 20 },
  dateHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginBottom: 10,
  },
  dateHeaderText: {
    fontSize: 12,
    fontWeight: "700",
    color: "#888",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  dateHeaderLine: { flex: 1, height: 1, backgroundColor: "#e5e5e5" },

  // ── Transaction Card ─────────────────────────────────────────
  txCard: {
    backgroundColor: "#fff",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#e5e5e5",
    overflow: "hidden",
  },
  txDivider: { height: 1, backgroundColor: "#f5f5f5", marginLeft: 68 },

  txItem: { paddingHorizontal: 16, paddingVertical: 14 },
  txMain: { flexDirection: "row", alignItems: "center", gap: 12 },
  txIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: "center",
    alignItems: "center",
  },
  txInfo: { flex: 1 },
  txTitle: {
    fontSize: 14,
    fontWeight: "600",
    color: "#1a1a2e",
    marginBottom: 3,
  },
  txMeta: { fontSize: 12, color: "#999" },
  txRight: { alignItems: "flex-end", gap: 4 },
  txAmount: { fontSize: 15, fontWeight: "700" },
  txStatusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
  },
  txStatusText: { fontSize: 10, fontWeight: "700", textTransform: "uppercase" },

  // ── Expanded Details ─────────────────────────────────────────
  txDetails: { marginTop: 8 },
  txDetailDivider: {
    height: 1,
    backgroundColor: "#f0f0f0",
    marginBottom: 12,
  },
  detailLine: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 8,
    paddingLeft: 56,
  },
  detailLineLabel: { fontSize: 12, color: "#999", fontWeight: "600" },
  detailLineValue: {
    fontSize: 12,
    color: "#1a1a2e",
    fontWeight: "500",
    maxWidth: "60%",
    textAlign: "right",
  },
});

export default CardTransactionsScreen;
