import React, { useState } from "react";
import Loginscreen from "../screens/Auth/Loginscreen";
import Signupscreen from "../screens/Auth/Signupscreen";
import Forgotpinscreen from "../screens/Auth/Forgotpinscreen";
import Resetpinscreen from "../screens/Auth/Resetpinscreen";

// Define the available views for the Auth flow
// type AuthView = "login" | "signup" | "forgot";

type AuthView = "login" | "signup" | "forgot" | "reset";

export default function AuthNavigation() {
  const [currentView, setCurrentView] = useState<AuthView>("login");
  const [resetEmail, setResetEmail] = useState("");
  // Navigation function to switch between views
  const navigateTo = (view: AuthView) => {
    setCurrentView(view);
  };

  return (
    <>
      {currentView === "login" && (
        <Loginscreen
          onShowSignup={() => navigateTo("signup")}
          onShowForgot={() => navigateTo("forgot")}
        />
      )}

      {currentView === "signup" && (
        <Signupscreen onShowLogin={() => navigateTo("login")} />
      )}

      {currentView === "forgot" && (
        <Forgotpinscreen
          onShowLogin={() => navigateTo("login")}
          onShowReset={(email) => {
            setResetEmail(email);
            navigateTo("reset");
          }}
        />
      )}

      {currentView === "reset" && (
        <Resetpinscreen
          email={resetEmail}
          onShowLogin={() => navigateTo("login")}
          onBack={() => navigateTo("forgot")}
        />
      )}
    </>
  );
}
