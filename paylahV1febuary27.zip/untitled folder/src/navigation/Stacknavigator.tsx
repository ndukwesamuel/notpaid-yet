import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import BottomTabNavigator from "./Bottomtabnavigator";
import ProfileScreen from "../screens/settings/ProfileScreen";
import SecurityScreen from "../screens/settings/Securityscreen";
import BankAccountsScreen from "../screens/settings/Bankaccountsscreen";
import HelpSupportScreen from "../screens/settings/Helpsupportscreen";
import AboutScreen from "../screens/settings/Aboutscreen";
import KycScreen from "../screens/settings/Kycscreen";
import AccountDetails from "../screens/settings/AccountDetails";
import CardTransactionsScreen from "../screens/Cardtransactionsscreen";

export type RootStackParamList = {
  MainTabs: undefined;
  Profile: undefined;
  Security: undefined;
  BankAccounts: undefined;
  HelpSupport: undefined;
  About: undefined;
  kyc: undefined;
  AccountDetails: undefined;
  CardTransactions: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

const StackNavigator = () => {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="MainTabs" component={BottomTabNavigator} />
      <Stack.Screen name="Profile" component={ProfileScreen} />
      <Stack.Screen name="Security" component={SecurityScreen} />
      <Stack.Screen name="BankAccounts" component={BankAccountsScreen} />
      <Stack.Screen name="HelpSupport" component={HelpSupportScreen} />
      <Stack.Screen name="About" component={AboutScreen} />
      <Stack.Screen name="kyc" component={KycScreen} />
      <Stack.Screen name="AccountDetails" component={AccountDetails} />
      <Stack.Screen
        name="CardTransactions"
        component={CardTransactionsScreen}
      />
    </Stack.Navigator>
  );
};

export default StackNavigator;
