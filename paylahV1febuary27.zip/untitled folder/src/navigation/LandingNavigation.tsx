import { View, Text } from "react-native";
import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { StatusBar } from "expo-status-bar";
import StackNavigator from "./Stacknavigator";

export default function LandingNavigation() {
  return (
    <NavigationContainer>
      <StatusBar style="dark" />
      <StackNavigator />
    </NavigationContainer>
  );
}

const SwitchScreen = () => {
  return (
    <View>
      <Text>LandingNavigation</Text>
    </View>
  );
};
