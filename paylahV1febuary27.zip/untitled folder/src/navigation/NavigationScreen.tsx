import { NavigationContainer } from "@react-navigation/native";
import { Text, View } from "react-native";
import AuthNavigation from "./AuthNavigation";
import StackNavigator from "./Stacknavigator";
import { useSelector } from "react-redux";
import Otpverificationscreen from "../screens/Auth/Otpverificationscreen";

// export const NavigationScreen = () => {
//   const { user, token, verified } = useSelector((state) => state?.authSlice);
//   console.log({
//     jaja: user,
//     ccc: verified,
//   });

//   return (
//     <NavigationContainer>

//       <Otpverificationscreen />
//       <>{token ? <StackNavigator /> : <AuthNavigation />}</>
//     </NavigationContainer>
//   );
// };

// export const NavigationScreen = () => {
//   const { user, token, verified } = useSelector((state) => state?.authSlice);

//   console.log({
//     oooo: verified,
//   });

//   return (
//     <NavigationContainer>
//       {/* 1. First, check if the user is NOT verified */}
//       {verified === false ? (
//         <Otpverificationscreen />
//       ) : (
//         /* 2. If verified, then check for the token to decide between Main App or Auth */
//         <>{token ? <StackNavigator /> : <AuthNavigation />}</>
//       )}
//     </NavigationContainer>
//   );
// };

export const NavigationScreen = () => {
  const { user, token, verified, email } = useSelector(
    (state) => state?.authSlice,
  );

  return (
    <NavigationContainer>
      {token ? (
        // IF TOKEN EXISTS: Check verification status
        verified === false || user.user.verified === false ? (
          <Otpverificationscreen />
        ) : (
          <StackNavigator />
        )
      ) : (
        // IF NO TOKEN: Show Auth (Login/Signup)
        <AuthNavigation />
      )}
    </NavigationContainer>
  );
};
