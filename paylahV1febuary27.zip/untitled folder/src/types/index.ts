export type RootTabParamList = {
  Home: undefined;
  Cards: undefined;
  History: undefined;
  More: undefined;
};
