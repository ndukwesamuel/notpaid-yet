import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Modal,
  Alert,
  KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
} from "react-native";

interface SendMoneyModalProps {
  visible: boolean;
  onClose: () => void;
}

const SendMoneyModal = ({ visible, onClose }: SendMoneyModalProps) => {
  const [email, setEmail] = useState("");
  const [amount, setAmount] = useState("");

  const handleSendMoney = () => {
    if (!email) {
      Alert.alert("Error", "Please enter recipient email");
      return;
    }
    if (!amount || parseFloat(amount) <= 0) {
      Alert.alert("Error", "Please enter a valid amount");
      return;
    }

    Alert.alert(
      "Success",
      `₦${parseFloat(amount).toLocaleString()} has been sent to ${email}`,
      [
        {
          text: "OK",
          onPress: () => {
            setEmail("");
            setAmount("");
            onClose();
          },
        },
      ]
    );
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent
      onRequestClose={onClose}
    >
      <TouchableWithoutFeedback onPress={onClose}>
        <View style={styles.overlay}>
          <TouchableWithoutFeedback>
            <KeyboardAvoidingView
              behavior={Platform.OS === "ios" ? "padding" : "height"}
              style={styles.sheetContainer}
            >
              <View style={styles.sheet}>
                <View style={styles.handle} />
                <Text style={styles.title}>Send Money</Text>
                <Text style={styles.subtitle}>
                  Transfer money to another account
                </Text>

                <Text style={styles.label}>Recipient Email</Text>
                <View style={styles.inputContainer}>
                  <TextInput
                    style={styles.inputFull}
                    placeholder="recipient@example.com"
                    placeholderTextColor="#999"
                    keyboardType="email-address"
                    autoCapitalize="none"
                    value={email}
                    onChangeText={setEmail}
                  />
                </View>

                <Text style={styles.label}>Amount</Text>
                <View style={styles.inputContainer}>
                  <Text style={styles.currencySymbol}>₦</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="10000"
                    placeholderTextColor="#999"
                    keyboardType="numeric"
                    value={amount}
                    onChangeText={setAmount}
                  />
                </View>

                <TouchableOpacity
                  style={styles.button}
                  onPress={handleSendMoney}
                >
                  <Text style={styles.buttonText}>Send Money</Text>
                </TouchableOpacity>
              </View>
            </KeyboardAvoidingView>
          </TouchableWithoutFeedback>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "flex-end",
  },
  sheetContainer: {
    justifyContent: "flex-end",
  },
  sheet: {
    backgroundColor: "#fff",
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 24,
    paddingTop: 12,
    paddingBottom: 40,
  },
  handle: {
    width: 40,
    height: 4,
    backgroundColor: "#e0e0e0",
    borderRadius: 2,
    alignSelf: "center",
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "700",
    color: "#1a1a2e",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: "#666",
    marginBottom: 24,
  },
  label: {
    fontSize: 14,
    fontWeight: "500",
    color: "#1a1a2e",
    marginBottom: 8,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#e5e5e5",
    borderRadius: 12,
    paddingHorizontal: 16,
    height: 56,
    marginBottom: 16,
  },
  currencySymbol: {
    fontSize: 18,
    color: "#999",
    marginRight: 8,
  },
  input: {
    flex: 1,
    fontSize: 18,
    color: "#1a1a2e",
  },
  inputFull: {
    flex: 1,
    fontSize: 16,
    color: "#1a1a2e",
  },
  button: {
    backgroundColor: "#1a1a2e",
    height: 56,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 8,
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
});

export default SendMoneyModal;
