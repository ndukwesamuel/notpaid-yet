export const API_CONFIG = {
  BASE_URL: "https://payla-7jlo.onrender.com/api/users/",
  TIMEOUT: 30000,
  ENV: "UAT",
};

export const API_CONFIG_main = {
  BASE_URL: "https://payla-7jlo.onrender.com/api/",
  TIMEOUT: 30000,
  ENV: "UAT",
};
